package com.gendigital.exoplanet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.gendigital.exoplanet.service.ExoplanetService;

@SpringBootApplication
public class ExoplanetServiceApplication implements CommandLineRunner {
	
	@Autowired
	ExoplanetService service; 

	public static void main(String[] args) {
		SpringApplication.run(ExoplanetServiceApplication.class, args);		
	}

	@Override
	public void run(String... args) throws Exception {
		service.printAllPlanetsInfo();
	}

}
