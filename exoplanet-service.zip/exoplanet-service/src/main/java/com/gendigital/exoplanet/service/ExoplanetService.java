package com.gendigital.exoplanet.service;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gendigital.exoplanet.model.Planets;
import com.gendigital.exoplanet.util.CatalogUtil;

@Service
public class ExoplanetService {
	
	@Autowired
	private CatalogUtil catalogs;
	
	public void printAllPlanetsInfo() {
		List<Planets> planetCatalog = catalogs.getCatalog();
		
		//need clarity on no star
		long noStarCount = planetCatalog.stream().filter(e -> e.getTypeFlag() != 0).count();
		System.out.println("the count of no star : "+ noStarCount);
		
		//hottest star - need clarity in orbiting star
		Planets hottestPlanet = planetCatalog.stream().max(Comparator.comparing(Planets::getHostStarTempK)).get();
		System.out.println("the name of hottest planet : "+ hottestPlanet.getPlanetIdentifier());
		
		//find year wise planets discovered
		Planets jupitarPlanet = planetCatalog.stream().filter(e -> "Jupitar".equalsIgnoreCase(e.getPlanetIdentifier())).findFirst().get();
		Map<String, List<Planets>> byDiscoveredYear = planetCatalog.stream().collect(Collectors.groupingBy(Planets::getDiscoveryYear));
		
		
		for(Map.Entry<String, List<Planets>> ent : byDiscoveredYear.entrySet()) {
			long small = ent.getValue().stream().filter(pla -> pla.getTypeFlag() == 0).filter(pla -> pla.getRadiusJpt() < jupitarPlanet.getRadiusJpt()).count();
			long medium = ent.getValue().stream().filter(pla -> pla.getTypeFlag() == 0).filter(pla -> (pla.getRadiusJpt() < jupitarPlanet.getRadiusJpt()) && (pla.getRadiusJpt() < jupitarPlanet.getRadiusJpt()*2)).count();
			long large = ent.getValue().stream().filter(pla -> pla.getTypeFlag() == 0).filter(pla -> pla.getRadiusJpt() > jupitarPlanet.getRadiusJpt()*2).count();
			
			System.out.println("In the year "+ ent.getKey()+ ", "+small+ "small planets"+medium+" medium planets"+large+" large planets");
		}
		
		
		
		
		
	}
	
	
	
	

}
