package com.gendigital.exoplanet.util;

import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gendigital.exoplanet.model.Planets;

@Component
public class CatalogUtil {
	
	public static final String URL_CATALOG = "http://gist.githubusercontent.com/joelbirchler/66cf8045fcbb6515557347c05d789b4a/raw/9a196385b44d4288431eef74896c0512bad3defe/exoplanets";

	public List<Planets> getCatalog() {

		ObjectMapper mapper = new ObjectMapper();
		List<Planets> planets = new ArrayList<>();
		try {
			URL url = new URL(URL_CATALOG);
			planets = mapper.readValue(url, new TypeReference<List<Planets>>(){});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		planets.forEach(System.out::println);
		
		return planets;

	}

}
