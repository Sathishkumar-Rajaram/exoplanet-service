package com.gendigital.exoplanet.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Planets {

	@JsonProperty("PlanetIdentifier")
	private String planetIdentifier;
	@JsonProperty("TypeFlag")
	private Integer typeFlag;
	@JsonProperty("PlanetaryMassJpt")
	private String planetaryMassJpt;
	@JsonProperty("RadiusJpt")
	private Double radiusJpt;
	@JsonProperty("PeriodDays")
	private Double periodDays;
	@JsonProperty("SemiMajorAxisAU")
	private Double semiMajorAxisAU;
	@JsonProperty("Eccentricity")
	private String eccentricity;
	@JsonProperty("PeriastronDeg")
	private String periastronDeg;
	@JsonProperty("LongitudeDeg")
	private String longitudeDeg;
	@JsonProperty("AscendingNodeDeg")
	private String ascendingNodeDeg;
	@JsonProperty("InclinationDeg")
	private Double inclinationDeg;
	@JsonProperty("SurfaceTempK")
	private String surfaceTempK;
	@JsonProperty("AgeGyr")
	private String ageGyr;
	@JsonProperty("DiscoveryMethod")
	private String discoveryMethod;
	@JsonProperty("DiscoveryYear")
	private String discoveryYear;
	@JsonProperty("LastUpdated")
	private String lastUpdated;
	@JsonProperty("RightAscension")
	private String rightAscension;
	@JsonProperty("Declination")
	private String declination;
	@JsonProperty("DistFromSunParsec")
	private String distFromSunParsec;
	@JsonProperty("HostStarMassSlrMass")
	private Double hostStarMassSlrMass;
	@JsonProperty("HostStarRadiusSlrRad")
	private Double hostStarRadiusSlrRad;
	@JsonProperty("HostStarMetallicity")
	private Integer hostStarMetallicity;
	@JsonProperty("HostStarTempK")
	private Integer hostStarTempK;
	@JsonProperty("HostStarAgeGyr")
	private String hostStarAgeGyr;
}
