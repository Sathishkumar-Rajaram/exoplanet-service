package com.digitalrealty.gapi.account.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.account.TestConfiguration;
import com.digitalrealty.gapi.account.configuration.AccountConfig;
import com.digitalrealty.gapi.account.mapper.AccountMapper;
import com.digitalrealty.gapi.account.model.GetAccountsResponse;
import com.digitalrealty.gapi.account.model.IAccountsResponse;
import com.digitalrealty.gapi.account.model.UserAccountResponse;

@ExtendWith(MockitoExtension.class)
class AccountServiceTest {

	@Mock
	AccountDBService accountDBService;

	@Mock
	UserService userService;

	@Mock
	AccountConfig accountConfig;

	@Mock
	AccountMapper accountMapper;

	@InjectMocks
	AccountService accountService;

	@Test
	public void getAccountStatusTest() {
		when(accountConfig.getActiveStatus()).thenReturn(new ArrayList<String>());
		when(accountDBService.getAccountStatus(TestConfiguration.legalEntityKey)).thenReturn(TestConfiguration.accountStatus);

		accountService.getAccountStatus(TestConfiguration.legalEntityKey);

		verify(accountDBService, times(1)).getAccountStatus(TestConfiguration.legalEntityKey);
	}

	@Test
	public void isAccountInternalTest() {
		when(accountDBService.isAccountInternal(TestConfiguration.globalAccountKey)).thenReturn(true);
		accountService.isAccountInternal(TestConfiguration.globalAccountKey);
		verify(accountDBService, times(1)).isAccountInternal(TestConfiguration.globalAccountKey);
	}

	@Test
	public void getCompanyNameTest() {
		accountService.getCompanyName(TestConfiguration.legalEntityKey);
		verify(accountDBService, times(1)).getCompanyName(TestConfiguration.legalEntityKey);
	}

	@Test
	public void getAccountsTest() {
		when(userService.getUserAccounts()).thenReturn(TestConfiguration.getUserAccountResponse());
		when(accountMapper.mapIAccountsResponseToGetAccountsResponse(Mockito.any(IAccountsResponse.class))).thenReturn(TestConfiguration.getAccountsResponse());
		when(accountDBService.getAccountsByLegalEntityKeys(Stream.of(TestConfiguration.legalEntityKey).collect(Collectors.toSet()))).thenReturn(Stream.of(TestConfiguration.getIAccountsResponse()).collect(Collectors.toList()));

		List<GetAccountsResponse> accountList = accountService.getAccounts(TestConfiguration.defaultAccount);

		assertThat(accountList.get(0).getGlobalUltimateKey()).isEqualTo(TestConfiguration.getAccountsResponse().getGlobalUltimateKey());
		assertThat(accountList.get(0).getGlobalUltimateName()).isEqualTo(TestConfiguration.getAccountsResponse().getGlobalUltimateName());
		assertThat(accountList.get(0).getInternalCompanyFlag()).isEqualTo(TestConfiguration.getAccountsResponse().getInternalCompanyFlag());
		assertThat(accountList.get(0).getLegalEntityKey()).isEqualTo(TestConfiguration.getAccountsResponse().getLegalEntityKey());
		assertThat(accountList.get(0).getLegalEntityName()).isEqualTo(TestConfiguration.getAccountsResponse().getLegalEntityName());

		verify(accountDBService, times(1)).getAccountsByLegalEntityKeys(Mockito.anySet());
	}

	@Test
	public void getSuperUserAccountsTest() {
		UserAccountResponse userAccountResponse = TestConfiguration.getUserAccountResponse();
		userAccountResponse.setSuperUser(true);

		when(userService.getUserAccounts()).thenReturn(userAccountResponse);
		when(accountMapper.mapIAccountsResponseToGetAccountsResponse(Mockito.any(IAccountsResponse.class))).thenReturn(TestConfiguration.getAccountsResponse());
		when(accountDBService.getAllAccounts()).thenReturn(Stream.of(TestConfiguration.getIAccountsResponse()).collect(Collectors.toList()));

		List<GetAccountsResponse> accountList = accountService.getAccounts(!TestConfiguration.defaultAccount);

		assertThat(accountList.get(0).getGlobalUltimateKey()).isEqualTo(TestConfiguration.getAccountsResponse().getGlobalUltimateKey());
		assertThat(accountList.get(0).getGlobalUltimateName()).isEqualTo(TestConfiguration.getAccountsResponse().getGlobalUltimateName());
		assertThat(accountList.get(0).getInternalCompanyFlag()).isEqualTo(TestConfiguration.getAccountsResponse().getInternalCompanyFlag());
		assertThat(accountList.get(0).getLegalEntityKey()).isEqualTo(TestConfiguration.getAccountsResponse().getLegalEntityKey());
		assertThat(accountList.get(0).getLegalEntityName()).isEqualTo(TestConfiguration.getAccountsResponse().getLegalEntityName());

		verify(accountDBService, times(1)).getAllAccounts();
	}

}
