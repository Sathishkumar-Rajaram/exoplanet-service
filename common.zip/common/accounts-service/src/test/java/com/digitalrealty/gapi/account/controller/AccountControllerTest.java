package com.digitalrealty.gapi.account.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.account.TestConfiguration;
import com.digitalrealty.gapi.account.configuration.ActionsConfig;
import com.digitalrealty.gapi.account.service.AccountService;
import com.digitalrealty.gapi.common.context.PermissionService;

@ExtendWith(MockitoExtension.class)
class AccountControllerTest {

	@Mock
	AccountService accountService;

	@Mock
	PermissionService permissionService;

	@InjectMocks
	AccountController accountController;

	@Mock
	ActionsConfig actionsConfig;

	@Test
	void getAccountStatusTest() throws Exception {
		when(accountService.getAccountStatus(TestConfiguration.legalEntityKey)).thenReturn(true);

		accountController.getAccountStatus(TestConfiguration.legalEntityKey);

		verify(accountService, times(1)).getAccountStatus(TestConfiguration.legalEntityKey);
	}

	@Test
	void isAccountInternalTest() throws Exception {
		when(accountService.isAccountInternal(TestConfiguration.globalAccountKey)).thenReturn(true);

		accountController.isAccountInternal(TestConfiguration.globalAccountKey);

		verify(accountService, times(1)).isAccountInternal(TestConfiguration.globalAccountKey);
	}

	@Test
	void getCompanyNameTest() throws Exception {
		when(accountService.getCompanyName(TestConfiguration.legalEntityKey)).thenReturn(TestConfiguration.accountName);

		accountController.getCompanyName(TestConfiguration.legalEntityKey);

		verify(accountService, times(1)).getCompanyName(TestConfiguration.legalEntityKey);
	}

	@Test
	void getAccountsTest() throws Exception {
		when(accountService.getAccounts(TestConfiguration.defaultAccount)).thenReturn(Stream.of(TestConfiguration.getAccountsResponse()).collect(Collectors.toList()));

		accountController.getAccounts(TestConfiguration.defaultAccount);

		verify(accountService, times(1)).getAccounts(TestConfiguration.defaultAccount);
	}

	@Test
	void getAccountNamesTest() throws Exception {
		Map<String, String> accountNames = new HashMap<String, String>() {
			private static final long serialVersionUID = 1L;
			{
				put(TestConfiguration.legalEntityKey, TestConfiguration.accountName);
			}
		};

		when(accountService.getAccountNames(Stream.of(TestConfiguration.legalEntityKey).collect(Collectors.toList()))).thenReturn(accountNames);

		accountController.getAccountNames(Stream.of(TestConfiguration.legalEntityKey).collect(Collectors.toList()));

		verify(accountService, times(1)).getAccountNames(Stream.of(TestConfiguration.legalEntityKey).collect(Collectors.toList()));
	}

	@Test
	void validateAccountsTest() throws Exception {
		accountController.validateAccounts(TestConfiguration.globalAccountKey, TestConfiguration.getValidateAccountsRequest());

		verify(accountService, times(1)).validateAccounts(TestConfiguration.globalAccountKey, TestConfiguration.getValidateAccountsRequest().getLegalEntityKeys());
	}
}