package com.digitalrealty.gapi.account.controller;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.digitalrealty.gapi.account.TestConfiguration;
import com.digitalrealty.gapi.account.configuration.ActionsConfig;
import com.digitalrealty.gapi.account.model.ValidateAccountsRequest;
import com.digitalrealty.gapi.account.service.AccountService;
import com.digitalrealty.gapi.common.context.PermissionService;

@ExtendWith(MockitoExtension.class)
class AccountControllerMvcTest {

	MockMvc mockMvc;
	@Mock
	AccountService accountService;

	@Mock
	PermissionService permissionService;

	@InjectMocks
	AccountController accountController;

	@Mock
	ActionsConfig actionsConfig;

	@BeforeEach
	void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(accountController).build();
	}

	@Test
	void getAccountStatusTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/accounts/" + TestConfiguration.legalEntityKey + "/status")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void isAccountInternalTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/accounts/" + TestConfiguration.globalAccountKey + "/internal")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void getCompanyNameTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/accounts/" + TestConfiguration.legalEntityKey + "/name")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void getAccountsTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/accounts?defaultAccount="+ TestConfiguration.defaultAccount)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void getAccountNamesTest() throws Exception {
		List<String> request = Stream.of(TestConfiguration.legalEntityKey).collect(Collectors.toList());
		mockMvc.perform(MockMvcRequestBuilders.post("/accounts/names")
				.content(TestConfiguration.asJsonString(request)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void validateAccountsTest() throws Exception {
		ValidateAccountsRequest request = TestConfiguration.getValidateAccountsRequest();
		mockMvc.perform(MockMvcRequestBuilders.post("/accounts/" + TestConfiguration.globalAccountKey + "/validate")
				.content(TestConfiguration.asJsonString(request)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

}