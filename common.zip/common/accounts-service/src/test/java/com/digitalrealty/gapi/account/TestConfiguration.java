package com.digitalrealty.gapi.account;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.digitalrealty.gapi.account.mapper.AccountObjectMapper;
import com.digitalrealty.gapi.account.model.GetAccountsResponse;
import com.digitalrealty.gapi.account.model.IAccountsResponse;
import com.digitalrealty.gapi.account.model.UserAccountResponse;
import com.digitalrealty.gapi.account.model.ValidateAccountsRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestConfiguration {

	public static ObjectMapper accountObjectMapper = new AccountObjectMapper();

	public static final String accountStatus = "Active";

	public static final String accountName = "Legal Entity Name";

	public static final String legalEntityKey = "Legal Entity Key";

	public static final String globalAccountKey = "globalAccountId";

	public static final boolean defaultAccount = true;

	public static UserAccountResponse getUserAccountResponse() {
		Map<String, Boolean> userAccounts = new HashMap<String, Boolean>() {
			private static final long serialVersionUID = 1L;
			{
				put(legalEntityKey, true);
			}
		};
		return UserAccountResponse.builder().superUser(false).anyAccount(false).userAccounts(userAccounts).build();
	}

	public static ValidateAccountsRequest getValidateAccountsRequest() {
		return ValidateAccountsRequest.builder().legalEntityKeys(Stream.of(legalEntityKey).collect(Collectors.toList())).build();
	}

	public static GetAccountsResponse getAccountsResponse() {
		return GetAccountsResponse.builder().globalUltimateKey(globalAccountKey).globalUltimateName("Global acc name").internalCompanyFlag(true).legalEntityKey(legalEntityKey).legalEntityName("Legal Entity Name").build();
	}

	public static class GetIAccountsResponseModel implements IAccountsResponse {

		@Override
		public String getGlobalUltimateKey() {
			return globalAccountKey;
		}

		@Override
		public String getGlobalUltimateName() {
			return "Global acc name";
		}

		@Override
		public Boolean getInternalCompanyFlag() {
			return true;
		}

		@Override
		public String getLegalEntityKey() {
			return "Legal Entity Key";
		}

		@Override
		public String getLegalEntityName() {
			return "Legal Entity Name";
		}

		@Override
		public Instant getCreateTimestamp() {
			return Instant.MIN;
		}

		@Override
		public Instant getStatusUpdateTimestamp() {
			return Instant.MIN;
		}

		@Override
		public String getStatus() {
			return "Active";
		}
	}

	// ********************************************************************************
	public static String asJsonString(final Object obj) {
		try {
			return accountObjectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static GetIAccountsResponseModel getIAccountsResponse() {
		return new GetIAccountsResponseModel();
	}
}
