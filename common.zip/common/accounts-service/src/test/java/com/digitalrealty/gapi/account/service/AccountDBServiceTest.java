package com.digitalrealty.gapi.account.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.account.TestConfiguration;
import com.digitalrealty.gapi.account.model.IAccountsResponse;
import com.digitalrealty.gapi.account.repository.GlobalUltimateRepository;
import com.digitalrealty.gapi.account.repository.LegalRepository;

@ExtendWith(MockitoExtension.class)
class AccountDBServiceTest {

	@Mock
	LegalRepository legalRepository;

	@Mock
	GlobalUltimateRepository globalRepository;

	@InjectMocks
	AccountDBService accountDBService;

	@Test
	public void getAccountStatusTest() {
		accountDBService.getAccountStatus(TestConfiguration.legalEntityKey);
		verify(legalRepository, times(1)).findStatusByLegalEntityKey(TestConfiguration.legalEntityKey);
	}

	@Test
	public void isAccountInternalTest() {
		accountDBService.isAccountInternal(TestConfiguration.globalAccountKey);
		verify(globalRepository, times(1)).findInternalCompanyFlagByGlobalUltimateKey(TestConfiguration.globalAccountKey);
	}

	@Test
	public void getCompanyNameTest() {
		accountDBService.getCompanyName(TestConfiguration.legalEntityKey);
		verify(legalRepository, times(1)).findNameByLegalEntityKey(TestConfiguration.legalEntityKey);
	}

	@Test
	void getAllAccountsTest() {
		when(globalRepository.findAllAccounts()).thenReturn(Stream.of(TestConfiguration.getIAccountsResponse()).collect(Collectors.toList()));

		List<IAccountsResponse> accountList = accountDBService.getAllAccounts();

		assertThat(accountList.get(0).getGlobalUltimateKey()).isEqualTo(TestConfiguration.getIAccountsResponse().getGlobalUltimateKey());
		verify(globalRepository, times(1)).findAllAccounts();
	}

	@Test
	void getAccountsByIdsTest() {
		Set<String> accountIds = Stream.of(TestConfiguration.legalEntityKey).collect(Collectors.toSet());
		when(globalRepository.findByLegalEntityKeyIn(accountIds)).thenReturn(Stream.of(TestConfiguration.getIAccountsResponse()).collect(Collectors.toList()));

		List<IAccountsResponse> accountList = accountDBService.getAccountsByLegalEntityKeys(accountIds);

		assertThat(accountList.get(0).getGlobalUltimateKey()).isEqualTo(TestConfiguration.getAccountsResponse().getGlobalUltimateKey());
		verify(globalRepository, times(1)).findByLegalEntityKeyIn(accountIds);
	}

	@Test
	void getAccountNamesByIdsTest() {
		List<String> accountIds = Stream.of(TestConfiguration.legalEntityKey).collect(Collectors.toList());
		List<Object[]> accountList = new ArrayList<Object[]>();
		accountList.add(Stream.of((Object) TestConfiguration.legalEntityKey, (Object) TestConfiguration.accountName).collect(Collectors.toList()).toArray());

		when(globalRepository.findAllAccountNamesByIds(accountIds)).thenReturn(accountList);

		Map<String, String> accountNames = accountDBService.getAccountNamesByIds(accountIds);

		assertThat(accountNames.get(TestConfiguration.legalEntityKey)).isEqualTo(TestConfiguration.accountName);
		verify(globalRepository, times(1)).findAllAccountNamesByIds(accountIds);
	}
}
