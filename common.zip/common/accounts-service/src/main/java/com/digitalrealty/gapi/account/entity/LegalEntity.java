package com.digitalrealty.gapi.account.entity;

import java.io.Serializable;
import java.time.Instant;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Data
@Table(name = "legal_entity")
public class LegalEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String legalEntityKey;

	private String legalEntityCode;

	private String legalEntityName;

	private String status;

	private Boolean internalCompanyFlag;

	private Instant createTimestamp;

	private Instant statusUpdateTimestamp;

	private Instant modifiedTimestamp;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "global_ultimate_key", nullable = false)
	private GlobalUltimateEntity globalUltimate;

}
