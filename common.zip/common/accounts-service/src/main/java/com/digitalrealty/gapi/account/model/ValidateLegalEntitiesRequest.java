package com.digitalrealty.gapi.account.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
public class ValidateLegalEntitiesRequest {

	@NotEmpty
	public List<String> legalEntityKeys;
}
