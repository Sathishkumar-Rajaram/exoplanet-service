package com.digitalrealty.gapi.account.model;

import java.time.Instant;

public interface LegalAccountResponse {

	String getLegalEntityKey();

	String getLegalEntityCode();

	String getLegalEntityName();

	String getStatus();

	Boolean getInternalCompanyFlag();

	Instant getCreateTimestamp();

	Instant getStatusUpdateTimestamp();

	Instant getModifiedTimestamp();

}
