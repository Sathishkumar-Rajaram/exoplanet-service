package com.digitalrealty.gapi.account.entity;

import java.io.Serializable;
import java.time.Instant;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Data
@Table(name = "global_ultimate")
public class GlobalUltimateEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String globalUltimateKey;

	private String globalUltimateName;

	private Instant createTimestamp;

	private Instant statusUpdateTimestamp;

	private Instant modifiedTimestamp;

	private String status;

	private Boolean internalCompanyFlag;

	@OneToMany(mappedBy = "globalUltimate", orphanRemoval = true, cascade = CascadeType.ALL)
	private Set<LegalEntity> legalEntity;

}
