package com.digitalrealty.gapi.account.mapper;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.account.model.GetAccountsResponse;
import com.digitalrealty.gapi.account.model.IAccountsResponse;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true))
public interface AccountMapper {

	GetAccountsResponse mapIAccountsResponseToGetAccountsResponse(IAccountsResponse account);

}
