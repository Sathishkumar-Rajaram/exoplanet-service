package com.digitalrealty.gapi.account.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.digitalrealty.gapi.account.entity.GlobalUltimateEntity;
import com.digitalrealty.gapi.account.model.IAccountsResponse;

public interface GlobalUltimateRepository extends CrudRepository<GlobalUltimateEntity, String> {

	@Query(value = "SELECT gu.global_ultimate_key as globalUltimateKey, gu.global_ultimate_name as globalUltimateName, gu.internal_company_flag as internalCompanyFlag, le.legal_entity_key as legalEntityKey, le.legal_entity_name as legalEntityName FROM account_gapi.global_ultimate gu, account_gapi.legal_entity le WHERE le.global_ultimate_key = gu.global_ultimate_key AND gu.status = 'Active' AND le.status = 'Active' order by le.legal_entity_name", nativeQuery = true)
	List<IAccountsResponse> findAllAccounts();

	@Query(value = "SELECT gu.global_ultimate_key as globalUltimateKey, gu.global_ultimate_name as globalUltimateName, gu.internal_company_flag as internalCompanyFlag, le.legal_entity_key as legalEntityKey, le.legal_entity_name as legalEntityName, le.status, le.create_timestamp as createTimestamp, le.status_update_timestamp as statusUpdateTimestamp FROM account_gapi.global_ultimate gu, account_gapi.legal_entity le WHERE le.global_ultimate_key = gu.global_ultimate_key AND gu.status = 'Active' AND le.status = 'Active' AND le.legal_entity_key in :legalEntityKeys order by le.legal_entity_name", nativeQuery = true)
	List<IAccountsResponse> findByLegalEntityKeyIn(Set<String> legalEntityKeys);

	@Query(value = "SELECT legal_entity_key, legal_entity_name FROM account_gapi.legal_entity WHERE legal_entity_key in :ids", nativeQuery = true)
	List<Object[]> findAllAccountNamesByIds(List<String> ids);

	@Query(value = "SELECT internal_company_flag FROM account_gapi.global_ultimate ag WHERE global_ultimate_key = :globalUltimateKey", nativeQuery = true)
	Boolean findInternalCompanyFlagByGlobalUltimateKey(String globalUltimateKey);
}
