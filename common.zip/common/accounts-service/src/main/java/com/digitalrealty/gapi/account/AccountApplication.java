package com.digitalrealty.gapi.account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;

import com.digitalrealty.gapi.common.context.EnableCommonContext;
import com.digitalrealty.gapi.common.exceptions.EnableCommonExceptions;

@EnableCommonExceptions
@EnableCommonContext
@SpringBootApplication
@ComponentScan({ "com.digitalrealty.gapi.account", "com.digitalrealty.gapi.common.context", "com.digitalrealty.gapi.common.exceptions", "com.digitalrealty.gapi.common.jwt" })
@EnableEurekaClient
@RefreshScope
@EnableCaching
public class AccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountApplication.class, args);
	}

}
