package com.digitalrealty.gapi.account.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalrealty.gapi.account.model.GetAccountsResponse;
import com.digitalrealty.gapi.account.model.ValidateAccountsRequest;
import com.digitalrealty.gapi.account.model.ValidateLegalEntitiesRequest;
import com.digitalrealty.gapi.account.model.ValidateLegalEntitiesResponse;
import com.digitalrealty.gapi.account.service.AccountService;
import com.digitalrealty.gapi.common.context.ContextUtility;

import lombok.RequiredArgsConstructor;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequiredArgsConstructor
@CrossOrigin
public class AccountController {

	private final AccountService accountService;

	@GetMapping(value = "/accounts", produces = { "application/json" })
	public List<GetAccountsResponse> getAccounts(@RequestParam(required = false) boolean defaultAccount) {
		return accountService.getAccounts(defaultAccount);
	}

	@ApiIgnore
	@PostMapping(value = "/accounts", produces = { "application/json" })
	public List<GetAccountsResponse> getAccounts(@NotEmpty @RequestBody List<String> legalEntityKeys) {
		return accountService.getAccountsByLegalEntityKeys(legalEntityKeys);
	}

	@ApiIgnore
	@PostMapping(value = "/accounts/names", produces = { "application/json" }, consumes = { "application/json" })
	public Map<String, String> getAccountNames(@NotEmpty @RequestBody List<String> legalEntityKeys) {
		return accountService.getAccountNames(legalEntityKeys);
	}

	@ApiIgnore
	@GetMapping(value = "/accounts/{accountId}/status", produces = { "application/json" })
	public Boolean getAccountStatus(@NotBlank @PathVariable("accountId") String accountId) {
		return accountService.getAccountStatus(accountId);
	}

	@ApiIgnore
	@GetMapping(value = "/accounts/{globalId}/internal", produces = { "application/json" })
	public Boolean isAccountInternal(@NotBlank @PathVariable("globalId") String globalId) {
		return accountService.isAccountInternal(globalId);
	}

	@ApiIgnore
	@GetMapping(value = "/accounts/{accountId}/name", produces = { "application/json" })
	public String getCompanyName(@NotBlank @PathVariable("accountId") String accountId) {
		return accountService.getCompanyName(accountId);
	}

	@ApiIgnore
	@PostMapping(value = "/accounts/{globalId}/validate", produces = { "application/json" })
	public HttpStatus validateAccounts(@NotBlank @PathVariable("globalId") String globalAccountKeys, @Valid @RequestBody ValidateAccountsRequest validateAccountsRequest) {
		accountService.validateAccounts(globalAccountKeys, validateAccountsRequest.getLegalEntityKeys());
		return HttpStatus.OK;
	}

	@ApiIgnore
	@PostMapping(value = "/accounts/validate", produces = { "application/json" })
	public ResponseEntity<ValidateLegalEntitiesResponse> validateLegalEntities(@Valid @RequestBody ValidateLegalEntitiesRequest validateLegalEntitiesRequest) {
		return new ResponseEntity<>(accountService.validateLegalEntities(validateLegalEntitiesRequest), HttpStatus.OK);
	}

	@ApiIgnore
	@GetMapping(value = "/accounts/legal-entities", produces = { "application/json" })
	public List<String> getLegalEntitiesForGlobalUltimate() {
		return accountService.getLegalEntitiesForGlobalUltimate(ContextUtility.getGlobalUltimate());
	}
}
