package com.digitalrealty.gapi.account.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.BooleanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.digitalrealty.gapi.account.configuration.AccountConfig;
import com.digitalrealty.gapi.account.mapper.AccountMapper;
import com.digitalrealty.gapi.account.model.GetAccountsResponse;
import com.digitalrealty.gapi.account.model.UserAccountResponse;
import com.digitalrealty.gapi.account.model.ValidateLegalEntitiesRequest;
import com.digitalrealty.gapi.account.model.ValidateLegalEntitiesResponse;
import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class AccountService {

	private final AccountDBService accountDBService;

	private final UserService userService;

	private final AccountConfig accountConfig;

	private final AccountMapper accountMapper;

	public Boolean getAccountStatus(String accountId) {
		return accountConfig.getActiveStatus().contains(accountDBService.getAccountStatus(accountId).toLowerCase());
	}

	public Boolean isAccountInternal(String globalUltimateKey) {
		return accountDBService.isAccountInternal(globalUltimateKey);
	}

	public String getCompanyName(String accountId) {
		return accountDBService.getCompanyName(accountId);
	}

	public List<GetAccountsResponse> getAccounts(boolean defaultAccount) {
		List<GetAccountsResponse> userAccountList = null;
		UserAccountResponse userAccounts = userService.getUserAccounts();

		if (BooleanUtils.isTrue(userAccounts.getSuperUser()) || BooleanUtils.isTrue(userAccounts.getAnyAccount())) {

			userAccountList = accountDBService.getAllAccounts().stream().map(accountMapper::mapIAccountsResponseToGetAccountsResponse).collect(Collectors.toList());

		} else if (!CollectionUtils.isEmpty(userAccounts.getUserAccounts())) {

			userAccountList = accountDBService.getAccountsByLegalEntityKeys(userAccounts.getUserAccounts().keySet()).stream().map(account -> {
				GetAccountsResponse responseAccount = accountMapper.mapIAccountsResponseToGetAccountsResponse(account);
				responseAccount.setIsDefault(userAccounts.getUserAccounts().get(account.getLegalEntityKey()));
				return responseAccount;
			}).collect(Collectors.toList());

		}

		if (!CollectionUtils.isEmpty(userAccountList) && defaultAccount) {
			if (BooleanUtils.isTrue(userAccounts.getSuperUser()) ||
					BooleanUtils.isTrue(userAccounts.getAnyAccount())) {
				userAccountList = List.of(userAccountList.get(0));
			} else {
				userAccountList = userAccountList.stream().filter(userAccount -> (BooleanUtils.isTrue(userAccount.getIsDefault()))).collect(Collectors.toList());
			}
		}
		return userAccountList;
	}

	public List<GetAccountsResponse> getAccountsByLegalEntityKeys(List<String> legalEntityKeys) {
		return accountDBService.getAccountsByLegalEntityKeys(new HashSet<>(legalEntityKeys)).stream().map(account -> {
			return accountMapper.mapIAccountsResponseToGetAccountsResponse(account);
		}).collect(Collectors.toList());
	}

	public Map<String, String> getAccountNames(List<String> legalEntityKeys) {
		return accountDBService.getAccountNamesByIds(legalEntityKeys);
	}

	public void validateAccounts(String globalAccountKeys, List<String> legalEntityKeys) {
		List<String> legalEntityKeyList = accountDBService.getAccountsByStatus(accountConfig.getActiveStatus(), globalAccountKeys, legalEntityKeys);
		List<String> notMatched = legalEntityKeys.stream().filter(element -> !legalEntityKeyList.contains(element)).collect(Collectors.toList());

		if (notMatched.size() > 0) {
			throw new CommonException(ErrorCode.BAD_REQUEST, new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("Missing accounts", notMatched.toString());
				}
			});
		}
	}

	public ValidateLegalEntitiesResponse validateLegalEntities(ValidateLegalEntitiesRequest validateLegalEntitiesRequest) {
		List<String> legalEntityKeyList = accountDBService.getAccountsByStatus(accountConfig.getActiveStatus(), ContextUtility.getGlobalUltimate(), validateLegalEntitiesRequest.getLegalEntityKeys());
		return ValidateLegalEntitiesResponse.builder().erroredLegalEntityKeys(validateLegalEntitiesRequest.getLegalEntityKeys().stream().filter(legalEntityKey -> !legalEntityKeyList.contains(legalEntityKey)).collect(Collectors.toList())).build();
	}

	public List<String> getLegalEntitiesForGlobalUltimate(String globalId) {
		return accountDBService.getLegalEntitiesForGlobalUltimate(globalId);
	}
}