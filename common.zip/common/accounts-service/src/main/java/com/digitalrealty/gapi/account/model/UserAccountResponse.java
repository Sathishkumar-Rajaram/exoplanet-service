package com.digitalrealty.gapi.account.model;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserAccountResponse {

	private Boolean superUser;

	private Boolean anyAccount;

	private Map<String, Boolean> userAccounts;

}
