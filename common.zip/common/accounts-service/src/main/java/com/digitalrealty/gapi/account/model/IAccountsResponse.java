package com.digitalrealty.gapi.account.model;

import java.time.Instant;

public interface IAccountsResponse {

	String getGlobalUltimateKey();

	String getGlobalUltimateName();

	Boolean getInternalCompanyFlag();

	String getLegalEntityKey();

	String getLegalEntityName();

	Instant getCreateTimestamp();

	Instant getStatusUpdateTimestamp();

	String getStatus();

}
