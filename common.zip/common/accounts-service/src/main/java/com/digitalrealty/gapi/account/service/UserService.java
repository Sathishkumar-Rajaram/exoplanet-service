package com.digitalrealty.gapi.account.service;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.account.configuration.UrlConfig;
import com.digitalrealty.gapi.account.model.UserAccountResponse;
import com.digitalrealty.gapi.common.context.ContextHeaders;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.CommonExceptionUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserService {

	private final WebClient webClient;

	private final UrlConfig permissionConfig;
	private final RedisCacheService redisCacheService;
	private final JwtConfig jwtConfig;

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public UserAccountResponse getUserAccounts() {
		return webClient.get()
				.uri(permissionConfig.getUserServiceURL() + "/users/accountIds")
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(UserAccountResponse.class)
				.doOnError(throwable -> {
					CommonException ce = CommonExceptionUtil.processOtherGapiServiceException(throwable);
					log.error("GET request to User MC has failed", ce);
					throw ce;
				})
				.block();
	}
}
