package com.digitalrealty.gapi.account.service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.account.model.IAccountsResponse;
import com.digitalrealty.gapi.account.model.LegalAccountResponse;
import com.digitalrealty.gapi.account.repository.GlobalUltimateRepository;
import com.digitalrealty.gapi.account.repository.LegalRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class AccountDBService {

	private final GlobalUltimateRepository globalRepository;

	private final LegalRepository legalRepository;

	public List<IAccountsResponse> getAllAccounts() {
		return globalRepository.findAllAccounts();
	}

	public String getAccountStatus(String accountId) {
		return legalRepository.findStatusByLegalEntityKey(accountId);
	}

	public Boolean isAccountInternal(String globalUltimateKey) {
		return globalRepository.findInternalCompanyFlagByGlobalUltimateKey(globalUltimateKey);
	}

	public String getCompanyName(String accountId) {
		return legalRepository.findNameByLegalEntityKey(accountId);
	}

	public List<IAccountsResponse> getAccountsByLegalEntityKeys(Set<String> legalEntityKeys) {
		return globalRepository.findByLegalEntityKeyIn(legalEntityKeys);
	}

	public Map<String, String> getAccountNamesByIds(List<String> accountList) {
		return globalRepository.findAllAccountNamesByIds(accountList).stream().collect(Collectors.toMap(t -> (String) t[0], t -> (String) t[1]));
	}

	public List<String> getAccountsByStatus(List<String> status, String globalAccountKeys, List<String> legalEntityKeys) {
		return legalRepository.findByStatusAndGlobalUltimateKeyAndLegalEntityKeyIn(status, globalAccountKeys, legalEntityKeys);
	}

	public List<LegalAccountResponse> findByLegalEntityKeyIn(List<String> legalEntityKeys) {
		return legalRepository.findByLegalEntityKeyIn(legalEntityKeys);
	}

	public List<String> getLegalEntitiesForGlobalUltimate(String globalId) {
		return legalRepository.findLegalEntityKeysByGlobalUltimateKey(globalId);
	}
}
