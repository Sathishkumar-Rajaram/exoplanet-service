package com.digitalrealty.gapi.account.configuration;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.NoArgsConstructor;

@Configuration
@NoArgsConstructor
@Data
@ConfigurationProperties(prefix = "actions")
public class ActionsConfig {
	private List<String> getAccounts;
}
