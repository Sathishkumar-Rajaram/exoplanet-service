package com.digitalrealty.gapi.account.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.NoArgsConstructor;

@Validated
@Configuration
@ConfigurationProperties(prefix = "urls")
@NoArgsConstructor
@Data
public class UrlConfig {

	private String userServiceURL;

}
