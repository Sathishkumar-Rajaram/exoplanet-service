package com.digitalrealty.gapi.account.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.digitalrealty.gapi.account.entity.LegalEntity;
import com.digitalrealty.gapi.account.model.LegalAccountResponse;

@Repository
public interface LegalRepository extends CrudRepository<LegalEntity, String> {

	@Query(value = "SELECT legal_entity_key FROM account_gapi.legal_entity ae WHERE status in :status and global_ultimate_key = :globalUltimateKey and legal_entity_key in :legalEntityKeys", nativeQuery = true)
	List<String> findByStatusAndGlobalUltimateKeyAndLegalEntityKeyIn(List<String> status, String globalUltimateKey, List<String> legalEntityKeys);

	@Query(value = "SELECT status FROM account_gapi.legal_entity ae WHERE legal_entity_key = :legalEntityKey", nativeQuery = true)
	String findStatusByLegalEntityKey(String legalEntityKey);

	@Query(value = "SELECT legal_entity_name FROM account_gapi.legal_entity ae WHERE legal_entity_key = :legalEntityKey", nativeQuery = true)
	String findNameByLegalEntityKey(String legalEntityKey);

	List<LegalAccountResponse> findByLegalEntityKeyIn(List<String> legalEntityKeys);

	@Query(value = "SELECT legal_entity_key FROM account_gapi.legal_entity ae WHERE global_ultimate_key = :globalUltimateKey", nativeQuery = true)
	List<String> findLegalEntityKeysByGlobalUltimateKey(String globalUltimateKey);
}
