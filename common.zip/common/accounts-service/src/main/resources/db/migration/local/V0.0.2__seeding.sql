INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 1', 'Global entity name 1','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 2', 'Global entity name 2','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 3', 'Global entity name 3','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 4', 'Global entity name 4','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 5', 'Global entity name 5','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 6', 'Global entity name 6','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 7', 'Global entity name 7','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 8', 'Global entity name 8','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 9', 'Global entity name 9','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
INSERT INTO "account_gapi"."global_ultimate" (global_ultimate_key, global_ultimate_name, create_timestamp, status_update_timestamp, modified_timestamp, status, internal_company_flag ) 
    VALUES('Global entity key 10', 'Global entity name 10','2012-09-17 18:47:52.069','2012-09-18 18:47:52.069','2012-09-20 18:47:52.069','Active',1);
    
    
    
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 1', 'legal entity code 1','Legal entity name 1','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 1' );
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 2', 'legal entity code 2','Legal entity name 2','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 2' );
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 3', 'legal entity code 3','Legal entity name 3','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 3' );
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 4', 'legal entity code 4','Legal entity name 4','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 4' );
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 5', 'legal entity code 5','Legal entity name 5','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 5' );
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 6', 'legal entity code 6','Legal entity name 6','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 6' );
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 7', 'legal entity code 7','Legal entity name 7','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 7' );
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 8', 'legal entity code 8','Legal entity name 8','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 8' );
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 9', 'legal entity code 9','Legal entity name 9','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 9' );
INSERT INTO "account_gapi"."legal_entity" (legal_entity_key, legal_entity_code, legal_entity_name, status, internal_company_flag, create_timestamp, status_update_timestamp, modified_timestamp, global_ultimate_key ) 
    VALUES('Legal entity key 10', 'legal entity code 10','Legal entity name 10','Active', 1, '2012-09-17 18:47:52.069', '2012-09-18 18:47:52.069', '2012-09-20 18:47:52.069', 'Global entity key 10' );
