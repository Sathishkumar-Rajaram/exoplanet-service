CREATE TABLE "account_gapi"."global_ultimate" (
	"global_ultimate_key" nvarchar(255) NOT NULL,
	"global_ultimate_name" nvarchar(255) NULL,
	"create_timestamp" datetime NULL,
	"status_update_timestamp" datetime NULL,
	"modified_timestamp" datetime NULL,
	"status" nvarchar(255) NULL,
	"internal_company_flag" bit NULL,
	PRIMARY KEY (global_ultimate_key ASC)
);


CREATE TABLE "account_gapi"."legal_entity" (
	"legal_entity_key" nvarchar(255) NOT NULL,
	"legal_entity_code" nvarchar(255) NULL,
	"legal_entity_name" nvarchar(255) NOT NULL,
	"status" nvarchar(255) NULL,
	"global_ultimate_key" nvarchar(255) NOT NULL,
	"internal_company_flag" bit NULL,
	"create_timestamp" datetime NULL,
	"status_update_timestamp" datetime NULL,
	"modified_timestamp" datetime NULL,
	PRIMARY KEY (legal_entity_key ASC),
	CONSTRAINT FK_GlobalLegal FOREIGN KEY (global_ultimate_key) REFERENCES  "account_gapi"."global_ultimate" (global_ultimate_key)
);