package java.com.digitalrealty.gapi.messaging;

import com.digitalrealty.gapi.common.context.ContextUtility;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
public class BaseReceiverTest {

    /*@InjectMocks
    ContextUtility contextUtility;*/

    MockedStatic<ContextUtility> contextUtilityMockedStatic;

    @BeforeEach
    void setUp() {
        contextUtilityMockedStatic = Mockito.mockStatic(ContextUtility.class);
    }

    @Test
    void initializeContext(){
        contextUtilityMockedStatic.when(ContextUtility::getUserEmail).thenReturn("testEmail");
        contextUtilityMockedStatic.when(ContextUtility::getLegalEntity).thenReturn("accountId");
        contextUtilityMockedStatic.when(ContextUtility::getGlobalUltimate).thenReturn("masterAccountId");
        contextUtilityMockedStatic.when(ContextUtility::getCorrelationId).thenReturn("correlationId");

        assertThat(ContextUtility.getUserEmail()).isEqualTo("testEmail");
        assertThat(ContextUtility.getLegalEntity()).isEqualTo("accountId");
        assertThat(ContextUtility.getGlobalUltimate()).isEqualTo("masterAccountId");
        assertThat(ContextUtility.getCorrelationId()).isEqualTo("correlationId");
    }

    @AfterEach
    void tearDown() {
        contextUtilityMockedStatic.close();
    }
}
