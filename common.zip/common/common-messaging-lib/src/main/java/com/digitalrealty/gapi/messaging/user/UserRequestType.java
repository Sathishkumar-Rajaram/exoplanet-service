package com.digitalrealty.gapi.messaging.user;

public enum UserRequestType {
    CREATED,
    UPDATED;
}
