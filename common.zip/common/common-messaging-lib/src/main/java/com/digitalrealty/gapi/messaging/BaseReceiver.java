package com.digitalrealty.gapi.messaging;

import com.digitalrealty.gapi.common.context.ContextUtility;
import lombok.extern.slf4j.Slf4j;

/*
An abstract receiver class that will be extended by other receivers
* */
@Slf4j
public abstract class BaseReceiver {

    public void initializeContext(BaseMessage baseMessage) {
        log.debug("Initializing the context and MDC with values from base message");
        ContextUtility.setUserEmail(baseMessage.getEmail());
        ContextUtility.setGlobalUltimate(baseMessage.getMasterAccountId());
        ContextUtility.setLegalEntity(baseMessage.getAccountId());
        ContextUtility.setCorrelationId(baseMessage.getCorrelationId());
        log.debug("Exiting method initializeContext()");
    }
}
