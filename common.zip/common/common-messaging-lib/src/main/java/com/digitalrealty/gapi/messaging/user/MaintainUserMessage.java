package com.digitalrealty.gapi.messaging.user;

import java.util.UUID;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.messaging.BaseMessage;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MaintainUserMessage extends BaseMessage {
	private UUID userId;
	private UserRequestType userRequestType;

	public MaintainUserMessage(UUID userId, UserRequestType userRequestType) {
		super(ContextUtility.getUserEmail(), ContextUtility.getCorrelationId(), ContextUtility.getLegalEntity(), ContextUtility.getGlobalUltimate());

		this.userId = userId;
		this.userRequestType = userRequestType;
	}
}
