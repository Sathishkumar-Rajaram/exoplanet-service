package com.digitalrealty.gapi.messaging.email;

public enum EmailType {
    NEW_ACCOUNT_ASSIGNED,
    NEW_ACCOUNT_REJECTED;
}
