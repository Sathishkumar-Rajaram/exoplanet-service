package com.digitalrealty.gapi.messaging.email;

import java.util.Map;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.messaging.BaseMessage;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SendEmailMessage extends BaseMessage {

	private Map<String, String> sendTo;
	private EmailType emailTemplateType;

	public SendEmailMessage(Map<String, String> sendTo, EmailType emailTemplateType) {
		super(ContextUtility.getUserEmail(), ContextUtility.getCorrelationId(), ContextUtility.getLegalEntity(), ContextUtility.getGlobalUltimate());

		this.sendTo = sendTo;
		this.emailTemplateType = emailTemplateType;
	}
}
