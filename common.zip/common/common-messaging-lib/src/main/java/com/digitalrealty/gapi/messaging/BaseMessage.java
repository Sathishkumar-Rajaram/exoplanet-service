package com.digitalrealty.gapi.messaging;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class BaseMessage implements Serializable {
	private static final long serialVersionUID = 1L;
	private String email;
	private String correlationId;
	private String accountId;
	private String masterAccountId;

}
