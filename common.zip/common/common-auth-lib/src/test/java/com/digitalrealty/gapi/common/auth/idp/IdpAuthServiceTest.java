package com.digitalrealty.gapi.common.auth.idp;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.auth.TestConfiguration;
import com.digitalrealty.gapi.common.auth.config.IdpAccessTokenConfig;
import com.digitalrealty.gapi.common.auth.model.IdpAuthServiceTokenResponse;
import com.digitalrealty.gapi.common.auth.service.IdpAuthService;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class IdpAuthServiceTest {

	@Mock
	private WebClient webClient;

	@Mock
	private JwtConfig jwtConfig;

	@Mock
	private RedisCacheService<String> redisCacheService;

	@Mock
	WebClient.RequestBodyUriSpec requestBodyUriSpecMock;

	@Mock
	WebClient.RequestBodySpec requestBodySpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;

	@Mock
	WebClient.ResponseSpec responseSpecMock;


	@Mock
	private IdpAccessTokenConfig idpAccessTokenConfig;

	@InjectMocks
	private IdpAuthService idpService;

	@SuppressWarnings("unchecked")
	@Test
	public void getAccessTokenTest() {
		when(jwtConfig.getIdpKeyName()).thenReturn(TestConfiguration.idpKeyName);
		when(redisCacheService.getObjectFromCache(TestConfiguration.idpKeyName))
				.thenReturn(TestConfiguration.getIdpAuthServiceTokenResponse().getAccessToken());
		when(idpAccessTokenConfig.getIdpClientId()).thenReturn(TestConfiguration.clientId);
		when(idpAccessTokenConfig.getIdpClientSecret()).thenReturn(TestConfiguration.clientSecret);
		when(idpAccessTokenConfig.getIdpGrantType()).thenReturn(TestConfiguration.grantType);
		when(idpAccessTokenConfig.getEndpointUrl()).thenReturn(TestConfiguration.localhost);
		when(webClient.post()).thenReturn(requestBodyUriSpecMock);
		when(requestBodyUriSpecMock.uri(Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.contentType(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.body(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
		when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(IdpAuthServiceTokenResponse.class)).thenReturn(Mono.just(TestConfiguration.getIdpAuthServiceTokenResponse()));
		
		idpService.getAccessToken(true);
		verify(webClient, times(1)).post();

	}
}
