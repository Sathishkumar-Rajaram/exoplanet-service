package com.digitalrealty.gapi.common.auth;

import com.digitalrealty.gapi.common.auth.model.IdpAuthServiceTokenResponse;



public class TestConfiguration {

	public static final String clientId = "dummy_client_id";

	public static final String clientSecret = "dummy_client_secret";

	public static final String grantType = "dummy_grant_type";

	public static final String localhost = "http://localhost:8080";

	public static final String idpKeyName = "dummy_idp_key";


	public static IdpAuthServiceTokenResponse getIdpAuthServiceTokenResponse() {
		return IdpAuthServiceTokenResponse.builder().accessToken("dummy_token").expiresIn(3600).build();
	}

}