package com.digitalrealty.gapi.common.auth.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Configuration
@ConfigurationProperties(prefix = "auth.idp")
@RequiredArgsConstructor
@Data
public class IdpAccessTokenConfig {

    private String idpClientId;
    private String idpClientSecret;
    private String idpGrantType;
    private String endpointUrl;
}
