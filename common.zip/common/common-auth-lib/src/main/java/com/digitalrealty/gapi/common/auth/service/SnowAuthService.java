package com.digitalrealty.gapi.common.auth.service;

import com.digitalrealty.gapi.common.auth.config.SnowAuthAccessTokenConfig;
import com.digitalrealty.gapi.common.auth.model.SnowAuthServiceTokenResponse;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.CommonExceptionUtil;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Objects;

@Service
@Slf4j
@RequiredArgsConstructor
public class SnowAuthService {
	
	private final WebClient webClient;
	private final SnowAuthAccessTokenConfig snowAuthAccessTokenConfig;
	private final JwtConfig jwtConfig;
	private final RedisCacheService<String> redisCacheService;

	@Retryable(value = CommonException.class)
	public String getAccessToken() {
		return getAccessToken(false);
	}
	
	@Retryable(value = CommonException.class)
	public String getAccessToken(boolean forced) {
		if (forced) {
			log.debug("Token expired generating the new one");
			redisCacheService.deleteObjectFromCache(jwtConfig.getSnowKeyName());
			SnowAuthServiceTokenResponse tokenResponse = generateNewToken();
			redisCacheService.putObjectIntoCache(jwtConfig.getSnowKeyName(), tokenResponse.getAccessToken());
			log.debug("Generated Token...");
		}
		return redisCacheService.getObjectFromCache(jwtConfig.getSnowKeyName());
	}

	private SnowAuthServiceTokenResponse generateNewToken() {
		log.debug("generating the access token");
		MultiValueMap<String, String> clientData = new LinkedMultiValueMap<>();
		clientData.add("client_id", snowAuthAccessTokenConfig.getSnowClientId());
		clientData.add("client_secret", snowAuthAccessTokenConfig.getSnowClientSecret());
		clientData.add("grant_type", snowAuthAccessTokenConfig.getSnowGrantType());
		clientData.add("username", snowAuthAccessTokenConfig.getSnowUsername());
		clientData.add("password", snowAuthAccessTokenConfig.getSnowPassword());

		return Objects.requireNonNull(
				webClient.post()
						.uri(snowAuthAccessTokenConfig.getEndpointUrl())
						.contentType(MediaType.APPLICATION_FORM_URLENCODED)
						.accept(MediaType.APPLICATION_JSON)
						.body(BodyInserters.fromFormData(clientData))
						.retrieve()
						.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
						.bodyToMono(SnowAuthServiceTokenResponse.class)
						.block());
	}

}
