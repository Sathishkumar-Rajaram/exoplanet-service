package com.digitalrealty.gapi.common.auth.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Configuration
@ConfigurationProperties(prefix = "auth.aws" )
@RequiredArgsConstructor
@Data
public class AwsS3ClientConfig {

	private String accessKey;
	private String secretKey;
	private String region;
	private String bucketName;

}
