package com.digitalrealty.gapi.common.auth.config;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "auth.snow")
@NoArgsConstructor
@Data
public class SnowAuthAccessTokenConfig {
    private String snowClientId;
    private String snowClientSecret;
    private String snowGrantType;
    private String snowUsername;
    private String snowPassword;
    private String endpointUrl;
}
