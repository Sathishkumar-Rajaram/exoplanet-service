package com.digitalrealty.gapi.common.auth.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.springframework.stereotype.Service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.digitalrealty.gapi.common.auth.config.AwsS3ClientConfig;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class AwsS3BucketStorageService {

	private final AwsS3ClientConfig awsS3ClientConfig;

	/**
	 * Downloads file using amazon S3 client from S3 bucket
	 *
	 * @param pathName
	 * @param fileName
	 * @return ByteArrayOutputStream
	 */
	public ByteArrayOutputStream downloadFile(String pathName, String fileName) {
		try {
			log.trace("bucket name is : " + awsS3ClientConfig.getBucketName() + " and file is at : " + pathName
					+ fileName);
			AmazonS3 amazonS3Client = AmazonS3ClientBuilder.standard().withRegion(Regions.fromName(awsS3ClientConfig.getRegion()))
					.withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(awsS3ClientConfig.getAccessKey(), awsS3ClientConfig.getSecretKey()))).build();
			S3Object s3object = amazonS3Client
					.getObject(new GetObjectRequest(awsS3ClientConfig.getBucketName(), pathName + fileName));
			InputStream is = s3object.getObjectContent();
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			int len;
			byte[] buffer = new byte[4096];
			while ((len = is.read(buffer, 0, buffer.length)) != -1) {
				outputStream.write(buffer, 0, len);
			}

			return outputStream;
		} catch (IOException ioException) {
			log.error("IOException: " + ioException.getMessage());
			throw new CommonException(ErrorCode.RESOURCE_ACCESS, ioException);
		} catch (AmazonServiceException serviceException) {
			log.info("AmazonServiceException Message:    " + serviceException.getMessage());
			throw new CommonException(ErrorCode.SYSTEM, serviceException);
		} catch (AmazonClientException clientException) {
			log.info("AmazonClientException Message: " + clientException.getMessage());
			throw new CommonException(ErrorCode.SYSTEM, clientException);
		}
	}
}
