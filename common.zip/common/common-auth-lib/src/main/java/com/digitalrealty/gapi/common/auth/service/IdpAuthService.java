package com.digitalrealty.gapi.common.auth.service;


import com.digitalrealty.gapi.common.auth.config.IdpAccessTokenConfig;
import com.digitalrealty.gapi.common.auth.model.IdpAuthServiceTokenResponse;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.CommonExceptionUtil;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Objects;

@Service
@Slf4j
@RequiredArgsConstructor
public class IdpAuthService {

	private final JwtConfig jwtConfig;
	private final RedisCacheService<String> redisCacheService;
	private final IdpAccessTokenConfig idpAccessTokenConfig;
	private final WebClient webClient;

	@Retryable(value = CommonException.class)
	public String getAccessToken() {
		return getAccessToken(false);
	}
	
	@Retryable(value = CommonException.class)
	public String getAccessToken(boolean forced) {
		if (forced) {
			log.debug("Token expired generating the new one");
			redisCacheService.deleteObjectFromCache(jwtConfig.getIdpKeyName());
			IdpAuthServiceTokenResponse tokenResponse = generateNewToken();
			redisCacheService.putObjectIntoCache(jwtConfig.getIdpKeyName(), tokenResponse.getAccessToken());
			log.debug("Generated Token... ");
		}
		return redisCacheService.getObjectFromCache(jwtConfig.getIdpKeyName());
	}
	
	private IdpAuthServiceTokenResponse generateNewToken() {
		log.debug("generating the access token");
		MultiValueMap<String, String> clientData = new LinkedMultiValueMap<>();
		
		  clientData.add("client_id", idpAccessTokenConfig.getIdpClientId());
		  clientData.add("client_secret", idpAccessTokenConfig.getIdpClientSecret());
		  clientData.add("grant_type", idpAccessTokenConfig.getIdpGrantType());

		
		return Objects.requireNonNull(webClient.post()
				.uri(idpAccessTokenConfig.getEndpointUrl() + "/connect/token")
				.contentType(MediaType.APPLICATION_FORM_URLENCODED)
				.accept(MediaType.APPLICATION_JSON)
				.body(BodyInserters.fromFormData(clientData))
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(IdpAuthServiceTokenResponse.class)
				.block());
	}
	

}
