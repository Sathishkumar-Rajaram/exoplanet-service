package com.digitalrealty.gapi.common.jwt.exception;

public class TestConfiguration {

	public static final String clientId = "dummy_client_id";

	public static final String clientSecret = "dummy_client_secret";

	public static final String grantType = "dummy_grant_type";

	public static final String localhost = "http://localhost:8080";

}