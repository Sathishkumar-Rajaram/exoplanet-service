package com.digitalrealty.gapi.common.jwt.configuration;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
@Data
@ConfigurationProperties(prefix = "jwt")
public class JwtConfig {
    private boolean enableTokenValidation;
    private String keyPrefix;
    private String idpKeyName;
    private String snowKeyName;
    private String jwksUrl;
    private String publicKey;
}
