package com.digitalrealty.gapi.common.jwt.security;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.context.configuration.HeaderConfig;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.exception.AuthErrorCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Objects;

@Component
@RequiredArgsConstructor
@Slf4j
public class JwtAuthenticationInterceptor implements HandlerInterceptor {
    private final JwtTokenUtility jwtTokenUtility;
    private final JwtConfig jwtConfig;
    private final RedisCacheService<String> redisCacheService;
    private final ObjectMapper tokenObjectMapper;
    private final HeaderConfig headerConfig;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (!headerConfig.getRequiredRoutes().stream().anyMatch(keyword -> request.getRequestURL().toString().contains(keyword))) {
            return true;
        }
        if(BooleanUtils.isFalse(jwtConfig.isEnableTokenValidation())){
            return true;
        }
        String bearer = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (Objects.isNull(bearer) || bearer.isEmpty() || !bearer.startsWith("Bearer ")) {
            throw new CommonException(AuthErrorCode.ACCESS_TOKEN_MISSING);
        }
        String token = bearer.split(" ")[1].trim();
        DecodedJWT decodedJWT = jwtTokenUtility.decodeJwtToken(token);
        JwtPayload jwtPayload = tokenObjectMapper.readValue(jwtTokenUtility.decode(decodedJWT.getPayload()), JwtPayload.class);
        return verifyTokenForOtherService(jwtPayload, token);
    }

    private boolean verifyTokenForOtherService(JwtPayload jwtPayload, String token){
        log.debug("Calling verifyTokenForGatewayService from interceptor");
        String userEmail = jwtPayload.getUserEmail();
        if (StringUtils.isEmpty(userEmail)) {
            throw new CommonException(AuthErrorCode.MISSING_EMAIL);
        }
        log.debug("user-email:{}",userEmail);
        String tokenFromCache = redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(),userEmail));
        if(Objects.isNull(tokenFromCache)){
            throw new CommonException(AuthErrorCode.ACCESS_TOKEN_NOT_FOUND_IN_CACHE);
        }else if(!token.equals(tokenFromCache)){
            throw new CommonException(AuthErrorCode.ACCESS_TOKEN_INVALID);
        }
        return true;
    }
}
