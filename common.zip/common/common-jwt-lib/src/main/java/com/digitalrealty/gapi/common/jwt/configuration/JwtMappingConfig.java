package com.digitalrealty.gapi.common.jwt.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class JwtMappingConfig {

    @Bean
    @Primary
    public ObjectMapper tokenObjectMapper(){
        return new JwtTokenObjectMapper();
    }
}
