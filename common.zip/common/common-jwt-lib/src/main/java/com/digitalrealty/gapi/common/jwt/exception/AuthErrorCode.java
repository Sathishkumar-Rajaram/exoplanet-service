package com.digitalrealty.gapi.common.jwt.exception;

import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class AuthErrorCode {
	public static final ErrorCode ACCESS_TOKEN_MISSING = new ErrorCode("UNAUTHORIZED", "Authorization error. Missing Bearer token.", 401, false);
	public static final ErrorCode ACCESS_TOKEN_EXPIRED = new ErrorCode("UNAUTHORIZED", "Authorization error. Access token expired", 401, false);
	public static final ErrorCode ACCESS_TOKEN_INVALID = new ErrorCode("UNAUTHORIZED", "Authorization error. Invalid access token", 401, false);

	public static final ErrorCode MISSING_EMAIL = new ErrorCode("UNAUTHORIZED", "Authorization error. Missing user_email in token", 401, false);
	public static final ErrorCode ACCESS_TOKEN_NOT_FOUND_IN_CACHE = new ErrorCode("UNAUTHORIZED", "Authorization error. Missing Bearer token in cache.", 401, false);
	public static final ErrorCode MISSING_EMAIL_IN_HEADER = new ErrorCode("UNAUTHORIZED", "Authorization error. Missing user-email in header", 401, false);
}
