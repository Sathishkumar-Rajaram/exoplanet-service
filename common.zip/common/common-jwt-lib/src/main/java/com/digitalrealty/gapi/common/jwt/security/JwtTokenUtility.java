package com.digitalrealty.gapi.common.jwt.security;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.UrlJwkProvider;
import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

@Component
@Data
@RequiredArgsConstructor
public class JwtTokenUtility {

    private final JwtConfig jwtConfig;
    @Cacheable("jwtPublicKeys")
    public RSAPublicKey getPublicKey(String kid) throws JwkException, MalformedURLException {
        JwkProvider provider = new UrlJwkProvider(new URL(jwtConfig.getJwksUrl()));
        Jwk jwk = provider.get(kid);
        return (RSAPublicKey) jwk.getPublicKey();
    }

    public PublicKey getPublicKey() throws InvalidKeySpecException, NoSuchAlgorithmException {
        String rsaPublicKey = jwtConfig.getPublicKey();
        rsaPublicKey = rsaPublicKey.replace("-----BEGIN PUBLIC KEY-----", "");
        rsaPublicKey = rsaPublicKey.replace("-----END PUBLIC KEY-----", "");
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(rsaPublicKey));
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PublicKey publicKey = kf.generatePublic(keySpec);
        return publicKey;
    }
    public String decode(String encodedString) {
        return new String(Base64.getUrlDecoder().decode(encodedString));
    }
    public DecodedJWT decodeJwtToken(String token){
        return JWT.decode(token);
    }
}
