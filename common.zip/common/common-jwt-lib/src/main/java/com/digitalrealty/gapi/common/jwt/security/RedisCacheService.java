package com.digitalrealty.gapi.common.jwt.security;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class RedisCacheService<V> {

    private final RedisTemplate<String, V> template;
    public void putObjectIntoCache(String key, V value){
        log.debug("Adding token to cache with key:{}", key);
        if(key.contains("access.token")){
            keepDefaultSerializer();
        }else{
            setSerializer();
        }
        ValueOperations<String, V> ops = template.opsForValue();
        ops.set(key, value);
    }

    public V getObjectFromCache(String key){
        log.debug("Getting token from cache with key:{}", key);
        if(key.contains("access.token")){
            keepDefaultSerializer();
        }else{
            setSerializer();
        }
        ValueOperations<String, V> ops = template.opsForValue();
        return ops.get(key);
    }

    public void deleteObjectFromCache(String key){
        log.debug("Deleting token from cache with key:{}", key);
        template.delete(key);
    }

    public void setSerializer(){
        template.setKeySerializer(RedisSerializer.string());
        template.setValueSerializer(RedisSerializer.java());
    }

    public void keepDefaultSerializer(){
        template.setKeySerializer(RedisSerializer.string());
        template.setValueSerializer(RedisSerializer.string());
    }
}
