package com.digitalrealty.gapi.common.jwt.configuration;

import com.digitalrealty.gapi.common.context.configuration.HeaderConfig;
import com.digitalrealty.gapi.common.jwt.security.JwtAuthenticationInterceptor;
import com.digitalrealty.gapi.common.jwt.security.JwtTokenUtility;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class JwtAuthenticationInterceptorConfiguration implements WebMvcConfigurer {

    private final JwtTokenUtility jwtTokenUtility;
    private final JwtConfig jwtConfig;
    private final RedisCacheService<String> redisCacheService;
    private final ObjectMapper tokenObjectMapper;
    private final HeaderConfig headerConfig;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        log.debug("adding jwt interceptor");
        registry.addInterceptor(new JwtAuthenticationInterceptor(jwtTokenUtility, jwtConfig, redisCacheService, tokenObjectMapper, headerConfig));
    }
}
