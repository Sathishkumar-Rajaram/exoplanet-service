package com.digitalrealty.gapi.common.jwt.security;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class JwtPayload {

	private String sub;

	@JsonAlias({"user_email", "https://api.digitalrealty.com/user_email", "email"})
	private String userEmail;

	@JsonProperty("account_name")
	private String accountName;

	private String iss;

	private int exp;

	private int iat;

	@JsonProperty("client_id")
	private String clientId;

	private String jti;

}