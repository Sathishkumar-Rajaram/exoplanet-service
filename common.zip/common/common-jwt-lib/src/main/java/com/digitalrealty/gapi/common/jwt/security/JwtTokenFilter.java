package com.digitalrealty.gapi.common.jwt.security;

import com.auth0.jwk.JwkException;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.exception.AuthErrorCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.net.MalformedURLException;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.util.Calendar;
import java.util.Objects;

@Component
@RequiredArgsConstructor
@Slf4j
public class JwtTokenFilter implements WebFilter {

    private final JwtTokenUtility jwtTokenUtility;
    private final JwtConfig jwtConfig;
    private final RedisCacheService<String> redisCacheService;
    private final ObjectMapper tokenObjectMapper;

    @SneakyThrows
    @Override
    public Mono<Void> filter(ServerWebExchange serverWebExchange, WebFilterChain webFilterChain) {
        log.debug("calling filter...");
        if(BooleanUtils.isFalse(jwtConfig.isEnableTokenValidation())){
            return webFilterChain.filter(serverWebExchange);
        }
        String bearer = serverWebExchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        if (Objects.isNull(bearer) || bearer.isEmpty() || !bearer.startsWith("Bearer ")) {
            throw new ResponseStatusException(AuthErrorCode.ACCESS_TOKEN_MISSING.getHttpStatusCode(),
                    AuthErrorCode.ACCESS_TOKEN_MISSING.getErrorText(), new CommonException(AuthErrorCode.ACCESS_TOKEN_MISSING));
        }
        String token = bearer.split(" ")[1].trim();
        DecodedJWT decodedJWT = jwtTokenUtility.decodeJwtToken(token);
        JwtPayload jwtPayload = tokenObjectMapper.readValue(jwtTokenUtility.decode(decodedJWT.getPayload()), JwtPayload.class);
        serverWebExchange.mutate().request(verifyTokenForGatewayService(serverWebExchange.getRequest(), decodedJWT, jwtPayload, token));
        return webFilterChain.filter(serverWebExchange)
                .doFinally(subscription ->  redisCacheService.deleteObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(),jwtPayload.getUserEmail())));
    }
    private ServerHttpRequest verifyTokenForGatewayService(ServerHttpRequest request, DecodedJWT decodedJWT, JwtPayload jwtPayload, String token) throws JwkException, MalformedURLException, InvalidKeySpecException, NoSuchAlgorithmException {
        log.debug("Calling verifyTokenForGatewayService from filter");
        Algorithm algorithm = null;
        if(Objects.isNull(decodedJWT.getKeyId())){
            log.debug("Apigee service getting public key from vault directly.");
            algorithm = Algorithm.RSA256((RSAPublicKey) jwtTokenUtility.getPublicKey(), null);
        }else{
            algorithm = Algorithm.RSA256(jwtTokenUtility.getPublicKey(decodedJWT.getKeyId()), null);
        }
        algorithm.verify(decodedJWT);

        if (decodedJWT.getExpiresAt().before(Calendar.getInstance().getTime())) {
            throw new ResponseStatusException(AuthErrorCode.ACCESS_TOKEN_EXPIRED.getHttpStatusCode(),
                    AuthErrorCode.ACCESS_TOKEN_EXPIRED.getErrorText(), new CommonException(AuthErrorCode.ACCESS_TOKEN_EXPIRED));
        }
        String userEmail = jwtPayload.getUserEmail();
        if (StringUtils.isEmpty(userEmail)) {
            throw new ResponseStatusException(AuthErrorCode.MISSING_EMAIL.getHttpStatusCode(),
                    AuthErrorCode.MISSING_EMAIL.getErrorText(), new CommonException(AuthErrorCode.MISSING_EMAIL));
        }
        redisCacheService.putObjectIntoCache(StringUtils.join(jwtConfig.getKeyPrefix(), userEmail), token);
        return request.mutate().header("User-Email", userEmail).build();
    }
}
