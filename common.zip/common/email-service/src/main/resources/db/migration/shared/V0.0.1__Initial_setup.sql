CREATE TABLE email_gapi.failed_email (
  id VARCHAR(255) NOT NULL PRIMARY KEY,
  send_email_message VARCHAR(max) NOT NULL,
  version INTEGER NOT NULL,
  execution_id VARCHAR(255),
  last_modified_date_time DATETIME
);
CREATE INDEX failed_execution_id ON email_gapi.failed_email (execution_id);
