package com.digitalrealty.gapi.email.controller;

import com.digitalrealty.gapi.email.service.EmailService;
import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequiredArgsConstructor
public class EmailController {

	private final EmailService emailService;

	@PostMapping(value = { "/emails/send-emails" }, consumes = { "application/json" })
	public void sendEmail(@Valid  @RequestBody SendEmailMessage sendEmailMessage) {
		emailService.sendEmail(sendEmailMessage, null);
	}
}
