package com.digitalrealty.gapi.email;

import com.digitalrealty.gapi.common.context.EnableCommonContext;
import com.digitalrealty.gapi.common.exceptions.EnableCommonExceptions;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.retry.annotation.EnableRetry;

@SpringBootApplication
@EnableCommonExceptions
@EnableCommonContext
@EnableRetry
@EnableEurekaClient
@RefreshScope
@EnableCaching
@ComponentScan({ "com.digitalrealty.gapi.email", "com.digitalrealty.gapi.common.context", "com.digitalrealty.gapi.common.exceptions", "com.digitalrealty.gapi.common.auth", "com.digitalrealty.gapi.common.jwt" })
public class EmailServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(EmailServiceApplication.class, args);
	}
}
