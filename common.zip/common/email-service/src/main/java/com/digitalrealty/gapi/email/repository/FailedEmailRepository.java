package com.digitalrealty.gapi.email.repository;

import com.digitalrealty.gapi.email.entity.FailedEmailEntity;
import com.digitalrealty.gapi.email.model.IFailedEmail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface FailedEmailRepository extends JpaRepository<FailedEmailEntity, UUID> {

    @Modifying
    // ************* H2 syntax - use only locally - !!!!!!!! NEVER CHECK IN
    // !!!!!!!!!!
    // @Query(value = "update email_gapi.failed_email set execution_id = ?1 WHERE
    // execution_id is null limit ?2", nativeQuery = true)
    // ********************************************************************************
    @Query(value = "update top(?2) email_gapi.failed_email set execution_id = ?1 where execution_id is null", nativeQuery = true)
    void updateExecutionId(String executionId, int batchExecutionIdsSize);

    @Query(value = "select * from email_gapi.failed_email WHERE execution_id = ?1", nativeQuery = true)
    List<IFailedEmail> findByExecutionId(String executionId);

    @Modifying
    @Query(value = "update email_gapi.failed_email set execution_id = null WHERE execution_id = ?1", nativeQuery = true)
    void updateExecutionIdAsNull(String executionId);

    @Modifying
    @Query(value = "update email_gapi.failed_email set execution_id=null where (EXTRACT (EPOCH FROM (CURRENT_TIMESTAMP()-last_modified_date))) > ?1 and execution_id is not null;", nativeQuery = true)
    void resetExecutionIds(long resetExecutionIdsTimeWindowSec);

}