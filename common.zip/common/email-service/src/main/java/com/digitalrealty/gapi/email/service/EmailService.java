package com.digitalrealty.gapi.email.service;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.email.exception.EmailServiceErrorCode;
import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

@RequiredArgsConstructor
@Service
@Slf4j
public class EmailService {

    private final MailgunApiService mailgunApiService;
	private final FailedEmailDBService failedEmailDBService;


    public void sendEmail(SendEmailMessage sendEmailMessage, UUID id) {
        try {
            mailgunApiService.sendEmail(sendEmailMessage, id);
			if (id != null) {
				failedEmailDBService.deleteById(id);
			}
        } catch (Exception mailSendException) {
            log.error("Sending email has failed", new CommonException(EmailServiceErrorCode.EMAIL_SENDING_ERROR, mailSendException));
            failedEmailDBService.saveFailedEmail(sendEmailMessage, id);
        }
    }

}
