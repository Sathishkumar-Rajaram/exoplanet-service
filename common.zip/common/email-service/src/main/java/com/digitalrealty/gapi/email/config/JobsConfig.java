package com.digitalrealty.gapi.email.config;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

@Validated
@Configuration
@ConfigurationProperties(prefix = "jobs")
@NoArgsConstructor
@Data
public class JobsConfig {

	private String manageExecutionIdSchedule;
	private String resetExecutionIdSchedule;
	private String removeSuspendedSchedule;
	private int manageExecutionIdsBatchSize;
	private int resetExecutionIdsTimeWindowSec;

}