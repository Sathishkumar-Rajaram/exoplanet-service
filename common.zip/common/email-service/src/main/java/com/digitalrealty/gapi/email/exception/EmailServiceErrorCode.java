package com.digitalrealty.gapi.email.exception;


import com.digitalrealty.gapi.common.exceptions.ErrorCode;

public class EmailServiceErrorCode {
	public static final ErrorCode EMAIL_SENDING_ERROR = new ErrorCode("EMAIL_SENDING_ERROR", "Email sending error", 500, false);
	public static final ErrorCode RESEND_EMAIL_ERROR = new ErrorCode("RESEND_EMAIL_ERROR", "Resend email error", 500, false);

}
