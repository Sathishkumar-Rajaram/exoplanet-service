package com.digitalrealty.gapi.email.service;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.email.config.MailgunConfig;
import com.digitalrealty.gapi.email.exception.EmailServiceErrorCode;
import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;
import org.thymeleaf.spring5.SpringTemplateEngine;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Objects;
import java.util.UUID;

@Service
@Slf4j
@RequiredArgsConstructor
public class MailgunApiService {

    private final WebClient webClient;
    private final MailgunConfig mailgunConfig;
    private final SpringTemplateEngine springTemplateEngine;

    @Retryable(value = CommonException.class, maxAttempts = 3)
    public void sendEmail(SendEmailMessage sendEmailMessage, UUID id) {
        final String[] sendTo = {""};
        sendEmailMessage.getSendTo().forEach((k, v) -> {
            sendTo[0] = Objects.nonNull(mailgunConfig.getSendTo()) ? mailgunConfig.getSendTo() : k ;
            String templateName = sendEmailMessage.getEmailTemplateType().toString().equalsIgnoreCase("NEW_ACCOUNT_ASSIGNED") ? "new-account-association" : "new-account-rejection";
            String subject = sendEmailMessage.getEmailTemplateType().toString().equalsIgnoreCase("NEW_ACCOUNT_ASSIGNED") ? "Digital Realty Global Portal new account access" : "Digital Realty Global Portal new account access has been rejected";
            UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(mailgunConfig.getMailgunUrl());
            uriComponentsBuilder.path(mailgunConfig.getMailgunPath());
            MultipartBodyBuilder builder = new MultipartBodyBuilder();
            builder.part("template", templateName);
            builder.part("subject", subject);
            builder.part("from", mailgunConfig.getSendFrom());
            builder.part("to", sendTo[0]);
            builder.part("h:X-Mailgun-Variables", "{\"userName\": \""+v+"\"}");
            String responseString = webClient.post()
                    .uri(uriComponentsBuilder.build().toUriString())
                    .headers(headers -> headers.setBasicAuth(mailgunConfig.getUsername(), mailgunConfig.getPassword()))
                    .contentType(MediaType.MULTIPART_FORM_DATA)
                    .body(BodyInserters.fromMultipartData(builder.build()))
                    .retrieve()
                    .onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(EmailServiceErrorCode.EMAIL_SENDING_ERROR)))
                    .bodyToMono(String.class)
                    .block();

            log.info(responseString);
        });
    }

}
