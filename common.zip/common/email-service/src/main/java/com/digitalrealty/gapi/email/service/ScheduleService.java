package com.digitalrealty.gapi.email.service;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.email.config.JobsConfig;
import com.digitalrealty.gapi.email.exception.EmailServiceErrorCode;
import com.digitalrealty.gapi.email.model.IFailedEmail;
import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import com.google.gson.Gson;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class ScheduleService {

	private final JobsConfig jobsConfig;
	private final FailedEmailDBService failedEmailDBService;
	private final EmailService emailService;

	@Scheduled(cron = "${jobs.resetExecutionIdSchedule:-}")
	public void resetExecutionIds() {
		try {
			failedEmailDBService.resetExecutionIds(jobsConfig.getResetExecutionIdsTimeWindowSec());
		} catch (CommonException e) {
			log.error("Reset execution ids as null on timewindow has failed", e);
		} catch (Exception e) {
			log.error("Reset execution ids as null on timewindow has failed", new CommonException(ErrorCode.SYSTEM, e));
		}
	}

	@Scheduled(cron = "${jobs.manageExecutionIdSchedule:-}")
	public void manageExecutionId() {
		String executionId = UUID.randomUUID().toString();
		try {
			failedEmailDBService.updateExecutionId(executionId, jobsConfig.getManageExecutionIdsBatchSize());
			List<IFailedEmail> failedEmails = failedEmailDBService.getFailedEmailsByExecutionId(executionId);
			Gson gson = new Gson();
			failedEmails.forEach(failedEmail -> emailService.sendEmail(gson.fromJson(failedEmail.getSendEmailMessage(), SendEmailMessage.class), failedEmail.getId()));
		} catch (Exception e) {
			log.error("Retry email has failed", new CommonException(EmailServiceErrorCode.RESEND_EMAIL_ERROR, e));
		} finally {
			try {
				failedEmailDBService.updateExecutionIdAsNull(executionId);
			} catch (Exception e) {
				log.error("Update execution id as null has failed", new CommonException(ErrorCode.SYSTEM, e));
			}
		}
	}
}
