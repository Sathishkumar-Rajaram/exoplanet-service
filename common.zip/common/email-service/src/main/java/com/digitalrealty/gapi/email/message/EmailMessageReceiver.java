package com.digitalrealty.gapi.email.message;

import com.digitalrealty.gapi.email.service.EmailService;
import com.digitalrealty.gapi.messaging.BaseReceiver;
import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor
public class EmailMessageReceiver extends BaseReceiver {

    private final EmailService emailService;


    @JmsListener(destination = "${messaging.sendEmailQueue}", containerFactory = "jmsListenerContainerFactory")
    public void receiveMessage(SendEmailMessage sendEmailMessage) {
            emailService.sendEmail(sendEmailMessage, null);
    }
}