package com.digitalrealty.gapi.email.service;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.email.entity.FailedEmailEntity;
import com.digitalrealty.gapi.email.mapper.FailedEmailResponseMapper;
import com.digitalrealty.gapi.email.model.IFailedEmail;
import com.digitalrealty.gapi.email.repository.FailedEmailRepository;
import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@RequiredArgsConstructor
@Service
@Slf4j
public class FailedEmailDBService {

	private final FailedEmailRepository failedEmailRepository;
	private final FailedEmailResponseMapper failedEmailResponseMapper;

	private String getJsonString(SendEmailMessage sendEmailMessage) {
		String sendEmailMessageJsonStr = null;
		try {
			sendEmailMessageJsonStr = new ObjectMapper().writeValueAsString(sendEmailMessage);
		} catch (JsonProcessingException e) {
			log.error("Json parsing error..!", new CommonException(ErrorCode.OBJECT_TO_JSON, e));
		}
		return sendEmailMessageJsonStr;
	}

	public void updateExecutionId(String executionId, int batchExecutionIdsSize) {
		failedEmailRepository.updateExecutionId(executionId, batchExecutionIdsSize);
	}
	public void resetExecutionIds(long resetExecutionIdsTimeWindowSec) {
		failedEmailRepository.resetExecutionIds(resetExecutionIdsTimeWindowSec);
	}

	public List<IFailedEmail> getFailedEmailsByExecutionId(String executionId) {
		return failedEmailRepository.findByExecutionId(executionId);
	}

	public void updateExecutionIdAsNull(String executionId) {
		failedEmailRepository.updateExecutionIdAsNull(executionId);
	}

	public void deleteById(UUID id) {
		failedEmailRepository.deleteById(id);
	}

	public void saveFailedEmail(SendEmailMessage sendEmailMessage, UUID id) {
		String sendEmailMessageJsonStr = getJsonString(sendEmailMessage);
		FailedEmailEntity failedEmailEntity = FailedEmailEntity.builder().sendEmailMessage(sendEmailMessageJsonStr).lastModifiedDateTime(Instant.now()).build();
		if (id != null) {
			failedEmailEntity = failedEmailRepository.getById(id);
		}
		failedEmailRepository.save(failedEmailEntity);
	}
}
