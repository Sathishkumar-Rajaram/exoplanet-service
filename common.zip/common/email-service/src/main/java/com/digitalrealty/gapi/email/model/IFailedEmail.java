package com.digitalrealty.gapi.email.model;

import java.time.Instant;
import java.util.UUID;

public interface IFailedEmail {

	UUID getId();
	String getSendEmailMessage();
	int getVersion();
	UUID getExecutionId();
	Instant getLastModifiedDateTime();
}
