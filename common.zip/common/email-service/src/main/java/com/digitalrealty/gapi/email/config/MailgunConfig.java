package com.digitalrealty.gapi.email.config;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "spring.mail")
@NoArgsConstructor
@Data
public class MailgunConfig {
	private String username;
	private String password;
	private String mailgunUrl;
	private String mailgunPath;
	private String sendFrom;
	private String sendTo;

}