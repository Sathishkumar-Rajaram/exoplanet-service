package com.digitalrealty.gapi.email.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "failed_email")
public class FailedEmailEntity {
	@Id
	@Type(type = "uuid-char")
	@GeneratedValue(generator = "uuid2")
	private UUID id;

	@Column(columnDefinition = "CLOB")
	@Lob
	private String sendEmailMessage;

	@Version
	private int version;

	private UUID executionId;

	@LastModifiedDate
	private Instant lastModifiedDateTime;
}
