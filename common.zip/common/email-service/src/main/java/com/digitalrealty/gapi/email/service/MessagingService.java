package com.digitalrealty.gapi.email.service;

import com.digitalrealty.gapi.email.config.MessagingConfig;
import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MessagingService {

	private final JmsTemplate jmsTemplate;

	private final MessagingConfig messagingConfig;

	public void sendMessage(SendEmailMessage message) {
		jmsTemplate.convertAndSend(messagingConfig.getSendEmailQueue(), message);
	}
}
