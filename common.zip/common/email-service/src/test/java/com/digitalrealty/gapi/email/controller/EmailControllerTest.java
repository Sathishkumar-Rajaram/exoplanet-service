package com.digitalrealty.gapi.email.controller;

import com.digitalrealty.gapi.email.service.EmailService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EmailControllerTest {

    @Mock
    EmailService emailService;

    @InjectMocks
    EmailController emailController;

    @Test
    void sendEmail() throws Exception {
    }
}
