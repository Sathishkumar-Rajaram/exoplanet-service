package com.digitalrealty.gapi.email;

public class TestConfiguration {

}