package com.digitalrealty.gapi.common.context;

import com.digitalrealty.gapi.common.exceptions.ErrorCode;

public final class CommonErrorCode {
	public static final ErrorCode HEADER_EMAIL_MISSING = new ErrorCode("HEADER_EMAIL_MISSING", "Required header User-Email is missing.", 400, false);
	public static final ErrorCode HEADER_GLOBAL_ULTIMATE_MISSING = new ErrorCode("HEADER_GLOBAL_ULTIMATE_MISSING", "Required header Master-Account-Id is missing.", 400, false);
	public static final ErrorCode HEADER_LEGAL_ENTITY_MISSSING = new ErrorCode("HEADER_LEGAL_ENTITY_MISSSING", "Required header Account-Id is missing.", 400, false);
}
