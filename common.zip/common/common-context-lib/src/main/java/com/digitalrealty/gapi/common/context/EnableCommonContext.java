package com.digitalrealty.gapi.common.context;

import org.springframework.context.annotation.Import;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Any Spring webmvc application that adds this annotation to its main application class (or any @Configuration class)
 * will have the {@link ContextFilter} added to its {@link javax.servlet.Filter Filter} list, and will have the {@link
 * ContextInterceptor} added to its list of Spring {@link org.springframework.web.servlet.HandlerInterceptor
 * HandlerInterceptor}s. These components are designed to work in a completely application-agnostic way.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Import(CommonContextConfiguration.class)
public @interface EnableCommonContext {
}
