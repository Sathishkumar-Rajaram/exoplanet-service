package com.digitalrealty.gapi.common.context;

import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.context.configuration.ContextConfig;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class PermissionService {

	private final WebClient webClient;

	private final ContextConfig contextConfig;

	private final RedisCacheService redisCacheService;

	private final JwtConfig jwtConfig;

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public ActionValidationResponse validateAction(ActionValidationRequest actionValidationRequest) {
		return webClient.post()
				.uri(contextConfig.getUserServiceURL() + "/users/validate-action")
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(actionValidationRequest), ActionValidationRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.SYSTEM)))
				.bodyToMono(ActionValidationResponse.class)
				.block();
	}

}
