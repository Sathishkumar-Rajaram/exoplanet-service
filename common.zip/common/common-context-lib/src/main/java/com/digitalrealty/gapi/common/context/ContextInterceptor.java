package com.digitalrealty.gapi.common.context;

import java.util.Collections;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.ModelAndView;

import com.digitalrealty.gapi.common.context.configuration.HeaderConfig;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * This {@link HandlerInterceptor} exists simply to populate
 * {@link ContextFields#OPERATION} in {@link MDC}.
 */

@Component
@Slf4j
@RequiredArgsConstructor
public class ContextInterceptor implements HandlerInterceptor {

	private final HeaderConfig headerConfig;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		if (!headerConfig.getRequiredRoutes().stream().anyMatch(keyword -> request.getRequestURL().toString().contains(keyword))) {
			return true;
		}

		if (handler instanceof HandlerMethod) {
			extractContextPathVariables(request, ((HandlerMethod) handler).getMethodParameters());
		}
		ContextUtility.add(ContextFields.OPERATION, this.getHandlerDescription(handler));
		ContextUtility.add(ContextFields.METHOD, request.getMethod());

		ContextHeaders.setContext(request);
		response.setHeader(ContextHeaders.HEADER_NAME_CORRELATION_ID, ContextUtility.getCorrelationId());
		return true;
	}

	@Override
	public void postHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler, final ModelAndView modelAndView) {
		MDC.clear();
	}

	@SuppressWarnings({ "rawtypes" })
	private void extractContextPathVariables(HttpServletRequest request, MethodParameter[] methodParameters) {
		Map pathVariables = extractVariables(request);
		if (methodParameters != null && !pathVariables.isEmpty()) {
			for (MethodParameter methodParameter : methodParameters) {
				if (methodParameter.hasParameterAnnotation(ContextField.class) && methodParameter.hasParameterAnnotation(PathVariable.class)) {
					ContextUtility.add(methodParameter.getParameter().getName(), pathVariables.get(methodParameter.getParameterAnnotation(PathVariable.class).name()));
				}
			}
		}
	}

	@SuppressWarnings("rawtypes")
	private Map extractVariables(HttpServletRequest request) {
		Object obj = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
		if (obj != null) {
			return (Map) obj;
		}
		return Collections.emptyMap();
	}

	private String getHandlerDescription(Object handler) {
		try {
			String description = ((HandlerMethod) handler).getShortLogMessage();
			return StringUtils.isNotBlank(description) ? description : handler.getClass().getSimpleName();
		} catch (NullPointerException e) {
			return "unknown";
		} catch (RuntimeException e) {
			return handler.getClass().getSimpleName();
		}
	}

}
