package com.digitalrealty.gapi.common.context;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;

import lombok.Data;

@Data
public class AuditorAwareImpl implements AuditorAware<String> {

	@Override
	public Optional<String> getCurrentAuditor() {
		return Optional.of(ContextUtility.getUserEmail());
	}

}