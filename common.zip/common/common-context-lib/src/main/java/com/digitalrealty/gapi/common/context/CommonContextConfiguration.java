package com.digitalrealty.gapi.common.context;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.digitalrealty.gapi.common.context.configuration.HeaderConfig;

import lombok.RequiredArgsConstructor;

@Configuration
@ComponentScan
@RequiredArgsConstructor
class CommonContextConfiguration implements WebMvcConfigurer {

	private final HeaderConfig headerConfig;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new ContextInterceptor(headerConfig));
	}

}
