package com.digitalrealty.gapi.common.context;

/**
 * The Components in this package will add these fields to the SLF4J MDC for
 * logging and other context-related purposes.
 *
 */
public final class ContextFields {

	/**
	 * set via {@link ContextInterceptor}
	 */
	public static final String OPERATION = "operation";

	/**
	 * set via {@link ContextInterceptor}
	 */
	public static final String METHOD = "method";

	/**
	 * set to value passed via a header: <br/>
	 * {@link ContextHeaders#HEADER_GLOBAL_ULTIMATE}
	 */
	public static final String GLOBALULTIMATE = "Master-Account-Id";

	/**
	 * set to value passed via a header: <br/>
	 * {@link ContextHeaders#HEADER_LEGAL_ENTITY}
	 */
	public static final String LEGALENTITY = "Account-Id";

	/**
	 * set to value passed via a header: <br/>
	 * {@link ContextHeaders#HEADER_EMAIL_LOGGED_IN_USER}
	 */
	public static final String USEREMAIL = "User-Email";

	/**
	 * set to value received in header
	 * {@link ContextHeaders#HEADER_NAME_CORRELATION_ID}
	 */
	public static final String CORRELATIONID = "Correlation-Id";

	ContextFields() {
	}
}
