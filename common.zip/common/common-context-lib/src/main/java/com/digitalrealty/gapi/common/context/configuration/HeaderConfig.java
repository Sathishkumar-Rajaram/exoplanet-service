package com.digitalrealty.gapi.common.context.configuration;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.NoArgsConstructor;

@Validated
@Configuration
@ConfigurationProperties(prefix = "headers")
@NoArgsConstructor
@Data
public class HeaderConfig {

	private List<String> requiredRoutes;

}
