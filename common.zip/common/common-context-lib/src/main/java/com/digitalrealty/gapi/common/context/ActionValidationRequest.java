package com.digitalrealty.gapi.common.context;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ActionValidationRequest {

	private String method;

	private List<String> actions;

	private List<AssetModel> assetIds;

	public ActionValidationRequest(String method, List<String> actions) {
		this.method = method;
		this.actions = actions;
	}

}
