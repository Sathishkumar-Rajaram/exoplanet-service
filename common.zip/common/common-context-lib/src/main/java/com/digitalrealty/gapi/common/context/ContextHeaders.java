package com.digitalrealty.gapi.common.context;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;

import com.digitalrealty.gapi.common.exceptions.CommonException;

public class ContextHeaders {

	public static final String HEADER_NAME_CORRELATION_ID = "Correlation-Id";

	public static final String HEADER_NAME_USER_EMAIL = "User-Email";

	public static final String HEADER_GLOBAL_ULTIMATE = "Master-Account-Id";

	public static final String HEADER_LEGAL_ENTITY = "Account-Id";

	private ContextHeaders() {
	}

	/**
	 * This method returns a map of headers to be used for downstream API calls.
	 * <p>
	 * If the current context contains a {@link ContextFields#CORRELATIONID}, then
	 * return that value with key {@link #HEADER_NAME_CORRELATION_ID}. *
	 *
	 * @return {@link Map} MAY be empty, but NEVER <code>null</code>
	 */
	public static Map<String, String> getMap() {
		Map<String, String> headers = new HashMap<>();
		addIfNotBlank(HEADER_NAME_USER_EMAIL, MDC.get(ContextFields.USEREMAIL), headers);
		addIfNotBlank(HEADER_NAME_CORRELATION_ID, MDC.get(ContextFields.CORRELATIONID), headers);
		addIfNotBlank(HEADER_GLOBAL_ULTIMATE, MDC.get(ContextFields.GLOBALULTIMATE), headers);
		addIfNotBlank(HEADER_LEGAL_ENTITY, MDC.get(ContextFields.LEGALENTITY), headers);
		return headers;
	}

	/**
	 * Webclient packed headers
	 */
	public static Consumer<HttpHeaders> getHeaderConsumer() {
		return httpHeaders -> ContextHeaders.getMap().forEach((headerName, headerValue) -> {
			httpHeaders.add(headerName, headerValue);
		});
	}

	/**
	 * This method is used to specify an internal user for
	 * {@link ContextFields#USERID}.
	 * <p>
	 * Assuming that the userId passed is not <code>null</code>, then this method
	 * also sets {@link ContextFields#CHANNEL} to
	 * {@link ContextFields#CHANNEL_EXTERNAL}
	 *
	 * @param userId {@link String}
	 */
	static void setGlobalUltimate(String globalUltimateKey) {
		if (StringUtils.isBlank(globalUltimateKey)) {
			throw new CommonException(CommonErrorCode.HEADER_GLOBAL_ULTIMATE_MISSING);
		}
		MDC.put(ContextFields.GLOBALULTIMATE, globalUltimateKey);
	}

	/**
	 * This method is used to specify an internal user for
	 * {@link ContextFields#USERID}.
	 * <p>
	 * Assuming that the userId passed is not <code>null</code>, then this method
	 * also sets {@link ContextFields#CHANNEL} to
	 * {@link ContextFields#CHANNEL_EXTERNAL}
	 *
	 * @param userId {@link String}
	 */
	static void setLegalEntity(String legalEntityKey) {
		if (StringUtils.isBlank(legalEntityKey)) {
			throw new CommonException(CommonErrorCode.HEADER_LEGAL_ENTITY_MISSSING);
		}
		MDC.put(ContextFields.LEGALENTITY, legalEntityKey);
	}

	/**
	 * This method is used to specify an internal user for
	 * {@link ContextFields#USERID}.
	 * <p>
	 * Assuming that the userId passed is not <code>null</code>, then this method
	 * also sets {@link ContextFields#CHANNEL} to
	 * {@link ContextFields#CHANNEL_EXTERNAL}
	 *
	 * @param userId {@link String}
	 */
	static void setUserEmail(String email) {
		if (StringUtils.isBlank(email)) {
			throw new CommonException(CommonErrorCode.HEADER_EMAIL_MISSING);
		}
		MDC.put(ContextFields.USEREMAIL, email);
	}

	static void setContext(HttpServletRequest request) {
		ContextUtility.setGlobalUltimate(request.getHeader(HEADER_GLOBAL_ULTIMATE));
		ContextUtility.setLegalEntity(request.getHeader(HEADER_LEGAL_ENTITY));
		ContextUtility.setUserEmail(request.getHeader(HEADER_NAME_USER_EMAIL));
		ContextUtility.setMdcCorrelationIds(request.getHeader(HEADER_NAME_CORRELATION_ID));
	}

	private static void addIfNotBlank(String headerName, String value, Map<String, String> map) {
		if (StringUtils.isNotBlank(value)) {
			map.put(headerName, value);
		}
	}

}
