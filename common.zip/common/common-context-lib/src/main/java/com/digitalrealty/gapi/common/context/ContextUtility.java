package com.digitalrealty.gapi.common.context;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import lombok.extern.slf4j.Slf4j;

/**
 * This class exists to provide a side-load mechanism for non-standard entry
 * points to ensure that the minimally required context fields are populated.
 */
@Slf4j
public class ContextUtility {

	public static final String UNSPECIFIED = "UNSPECIFIED";

	private ContextUtility() {
	}

	public static void setGlobalUltimate(String globalUltimateKey) {
		ContextHeaders.setGlobalUltimate(globalUltimateKey);
	}

	public static void setLegalEntity(String legalEntityKey) {
		ContextHeaders.setLegalEntity(legalEntityKey);
	}

	public static void setUserEmail(String email) {
		ContextHeaders.setUserEmail(email);
	}

	public static void setDefault() {
		setMdcUserEmail(MDC.get(ContextFields.USEREMAIL));
		setMdcCorrelationIds(MDC.get(ContextFields.CORRELATIONID));
		setMdcGlobalUltimate(MDC.get(ContextFields.GLOBALULTIMATE));
		setMdcLegalEntity(MDC.get(ContextFields.LEGALENTITY));
	}

	public static void setMdcGlobalUltimate(String globalUltimateKey) {
		if (StringUtils.isNotBlank(globalUltimateKey)) {
			MDC.put(ContextFields.GLOBALULTIMATE, globalUltimateKey);
		}
	}

	public static void setMdcLegalEntity(String legalEntityKey) {
		if (StringUtils.isNotBlank(legalEntityKey)) {
			MDC.put(ContextFields.LEGALENTITY, legalEntityKey);
		}
	}

	public static void setMdcUserEmail(String email) {
		if (StringUtils.isNotBlank(email)) {
			MDC.put(ContextFields.USEREMAIL, email);
		}
	}

	public static void setMdcCorrelationIds(String correlationid) {
		if (StringUtils.isBlank(MDC.get(ContextFields.CORRELATIONID))) {
			if (StringUtils.isNotBlank(correlationid)) {
				MDC.put(ContextFields.CORRELATIONID, correlationid);
			} else {
				getCorrelationId();
			}
		}
	}

	public static void setMdcMethod(String method) {
		if (StringUtils.isNotBlank(method)) {
			MDC.put(ContextFields.METHOD, method);
		}
	}

	public static void add(String key, Object value) {
		if (StringUtils.isNotBlank(key)) {
			if (value == null) {
				MDC.put(key, "NULL");
			} else {
				MDC.put(key, StringUtils.isNotBlank(value.toString()) ? value.toString() : "BLANK");
			}
		}
	}

	public static void remove(String key) {
		if (StringUtils.isNotBlank(key)) {
			MDC.remove(key);
		}
	}

	public static void extract(Object obj) {
		if (obj == null) {
			return;
		}
		for (Field f : obj.getClass().getDeclaredFields()) {
			if (f.getAnnotation(ContextField.class) != null) {
				try {
					Method m = obj.getClass().getMethod("get" + StringUtils.capitalize(f.getName()));
					ContextUtility.add(f.getName(), m.invoke(obj));
				} catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
					log.error("can not get value of {}", f.getName(), e);
				}
			}
		}
	}

	/**
	 * @return user email from current thread context; NEVER null
	 */
	public static String getGlobalUltimate() {
		return MDC.get(ContextFields.GLOBALULTIMATE);
	}

	/**
	 * @return user email from current thread context; NEVER null
	 */
	public static String getLegalEntity() {
		return MDC.get(ContextFields.LEGALENTITY);
	}

	/**
	 * @return user email from current thread context; NEVER null
	 */
	public static String getUserEmail() {
		return StringUtils.isNotBlank(MDC.get(ContextFields.USEREMAIL)) ? MDC.get(ContextFields.USEREMAIL) : ContextUtility.UNSPECIFIED;
	}

	/**
	 * @return requestMethod from current thread context; NEVER null
	 */
	public static String getMethod() {
		return StringUtils.isNotBlank(MDC.get(ContextFields.METHOD)) ? MDC.get(ContextFields.METHOD) : ContextUtility.UNSPECIFIED;
	}

	/**
	 * gets current correlationId & automatically sets it if one is not already set
	 *
	 * @return correlationId from current thread context; NEVER null;
	 */
	public static String getCorrelationId() {
		if (StringUtils.isNotBlank(MDC.get(ContextFields.CORRELATIONID))) {
			return MDC.get(ContextFields.CORRELATIONID);
		}

		String id = UUID.randomUUID().toString();
		setMdcCorrelationIds(id);
		return id;
	}

	/**
	 * DO NOT use this method unless you really know what you are doing - there are
	 * very few places outside of globalapi-common-* libraries where it would be
	 * appropriate to call this method
	 *
	 * @param correlationId SHOULD NOT be blank; but one will be generated if it is
	 */
	public static void setCorrelationId(String correlationId) {
		setMdcCorrelationIds(correlationId);
	}

}
