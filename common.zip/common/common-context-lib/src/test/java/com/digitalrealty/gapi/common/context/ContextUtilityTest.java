package com.digitalrealty.gapi.common.context;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import net.logstash.logback.argument.StructuredArgument;

@ExtendWith(MockitoExtension.class)
class ContextUtilityTest {

	@InjectMocks
	ContextUtility contextUtility;

	MockedStatic<ContextUtility> contextUtilityMockedStatic;
	@Mock
	StructuredArgument structuredArgument;

	@BeforeEach
	void setUp() {
		contextUtilityMockedStatic = Mockito.mockStatic(ContextUtility.class);
	}

	@AfterEach
	void tearDown() {
		contextUtilityMockedStatic.close();
	}

	@Test
	void getUserEmail() {

		contextUtilityMockedStatic.when(ContextUtility::getUserEmail).thenReturn("testid");
		assertThat(ContextUtility.getUserEmail()).isEqualTo("testid");
	}

	@Test
	void getMethod() {
		contextUtilityMockedStatic.when(ContextUtility::getMethod).thenReturn("method");
		assertThat(ContextUtility.getMethod()).isEqualTo("method");
	}

	@Test
	void getCorrelationId() {
		contextUtilityMockedStatic.when(ContextUtility::getCorrelationId).thenReturn("corrid");
		assertThat(ContextUtility.getCorrelationId()).isEqualTo("corrid");
	}
}