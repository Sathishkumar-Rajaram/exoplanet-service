package com.digitalrealty.gapi.common.context;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
class ContextHeadersTest {

    public static final String HEADER_NAME_CORRELATION_ID = "correlationid";
    public static final String HEADER_NAME_USER_EMAIL = "userEmail";

    @InjectMocks
    ContextHeaders contextHeaders;
    MockedStatic<ContextHeaders> contextHeadersStatic;

    @BeforeEach
    void setUp() {
        contextHeadersStatic = Mockito.mockStatic(ContextHeaders.class);
    }

    @AfterEach
    void tearDown() {
        contextHeadersStatic.close();
    }

    @Test
    void getMap() {

        Map<String, String> headers = new HashMap<>();
        headers.put(HEADER_NAME_USER_EMAIL, MDC.get(ContextFields.USEREMAIL));
        headers.put(HEADER_NAME_CORRELATION_ID, MDC.get(ContextFields.CORRELATIONID));
        contextHeadersStatic.when(() -> ContextHeaders.getMap()).thenReturn(headers);
        assertThat(ContextHeaders.getMap().get(HEADER_NAME_USER_EMAIL)).isEqualTo(MDC.get(ContextFields.USEREMAIL));
        assertThat(ContextHeaders.getMap().get(HEADER_NAME_CORRELATION_ID)).isEqualTo(MDC.get(ContextFields.CORRELATIONID));

    }
}