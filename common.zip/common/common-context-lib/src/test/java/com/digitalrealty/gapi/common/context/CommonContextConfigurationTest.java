package com.digitalrealty.gapi.common.context;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CommonContextConfigurationTest {

    @Mock
    InterceptorRegistry interceptorRegistry;

    @Test
    void addInterceptors() {
        CommonContextConfiguration commonContextConfiguration = mock(CommonContextConfiguration.class);
        doNothing().when(commonContextConfiguration).addInterceptors(interceptorRegistry);
        commonContextConfiguration.addInterceptors(interceptorRegistry);
        verify(commonContextConfiguration, times(1)).addInterceptors(interceptorRegistry);
    }
}