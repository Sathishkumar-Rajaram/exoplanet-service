package com.digitalrealty.gapi.common.context;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.method.HandlerMethod;

import com.digitalrealty.gapi.common.context.configuration.HeaderConfig;

@ExtendWith(MockitoExtension.class)
class ContextInterceptorTest {

	@InjectMocks
	ContextInterceptor contextInterceptor;

	@Mock
	HandlerMethod handlerMethod;

	@Mock
	HeaderConfig headerConfig;

	@Test
	void preHandle() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		request.addHeader(ContextHeaders.HEADER_GLOBAL_ULTIMATE, "1");
		request.addHeader(ContextHeaders.HEADER_LEGAL_ENTITY, UUID.randomUUID().toString());
		request.addHeader(ContextHeaders.HEADER_NAME_USER_EMAIL, "john@doe.com");
		request.setRequestURI("http://localhost/users/");

		boolean value = contextInterceptor.preHandle(request, response, handlerMethod);

		assertThat(value).isEqualTo(Boolean.TRUE);
	}
}