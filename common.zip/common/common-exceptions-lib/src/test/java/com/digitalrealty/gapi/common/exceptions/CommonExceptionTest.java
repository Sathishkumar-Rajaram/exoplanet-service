package com.digitalrealty.gapi.common.exceptions;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class CommonExceptionTest {

    @Mock
    CommonException commonException;
    @Mock
    ErrorCode errorCode;

    @Test
    void getMessage() {
        when(errorCode.getName()).thenReturn("testName");
        when(errorCode.getErrorText()).thenReturn("testErrorText");
        StringBuilder sb = new StringBuilder(errorCode.getName()).append(": ").append(errorCode.getErrorText());
        when(commonException.getMessage()).thenReturn(sb.toString());
        String value = commonException.getMessage();
        assertThat(value).isNotNull();
        assertThat(value).isEqualTo("testName: testErrorText");
        verify(commonException, times(1)).getMessage();
    }

    @Test
    void fromErrorCodes() {
        ErrorCode errorCode2 = new ErrorCode("Testing", "Testing", 0, false);
        CommonException commonException1 = new CommonException(errorCode2);
        Collection<IErrorCode> errorCodes2 = new ArrayList<>();
        errorCodes2.add(errorCode2);

        try (MockedStatic<CommonException> utilities = Mockito.mockStatic(CommonException.class)) {
            utilities.when(() -> CommonException.fromErrorCodes(errorCodes2)).thenReturn(commonException1);
            assertThat(CommonException.fromErrorCodes(errorCodes2)).isNotNull();
            assertThat(CommonException.fromErrorCodes(errorCodes2).getErrorCode().getErrorText()).isEqualTo("Testing");
            assertThat(CommonException.fromErrorCodes(errorCodes2).getErrorCode().getName()).isEqualTo("Testing");
            assertThat(CommonException.fromErrorCodes(errorCodes2).getErrorCode().getHttpStatusCode()).isEqualTo(0);
        }
    }

    @Test
    void fromList() {
        ErrorCode errorCode2 = new ErrorCode("Testing", "Testing", 0, false);
        CommonException commonException1 = new CommonException(errorCode2);
        Collection<IErrorCode> errorCodes2 = new ArrayList<>();
        errorCodes2.add(errorCode2);
        List<CommonException> exceptions = new ArrayList<>();
        exceptions.add(commonException1);

        try (MockedStatic<CommonException> utilities = Mockito.mockStatic(CommonException.class)) {
            utilities.when(() -> CommonException.fromList(exceptions)).thenReturn(commonException1);
            assertThat(CommonException.fromList(exceptions)).isNotNull();
            assertThat(CommonException.fromList(exceptions).getErrorCode().getErrorText()).isEqualTo("Testing");
            assertThat(CommonException.fromList(exceptions).getErrorCode().getName()).isEqualTo("Testing");
            assertThat(CommonException.fromList(exceptions).getErrorCode().getHttpStatusCode()).isEqualTo(0);
        }
    }

    @Test
    void testFromList() {
        ErrorCode errorCode2 = new ErrorCode("Testing", "Testing", 0, false);
        CommonException commonException1 = new CommonException(errorCode2);
        Collection<IErrorCode> errorCodes2 = new ArrayList<>();
        errorCodes2.add(errorCode2);
        List<CommonException> exceptions = new ArrayList<>();
        exceptions.add(commonException1);

        try (MockedStatic<CommonException> utilities = Mockito.mockStatic(CommonException.class)) {
            utilities.when(() -> CommonException.fromList(exceptions, "test error message")).thenReturn(commonException1);
            assertThat(CommonException.fromList(exceptions, "test error message")).isNotNull();
            assertThat(CommonException.fromList(exceptions, "test error message").getErrorCode().getErrorText()).isEqualTo("Testing");
            assertThat(CommonException.fromList(exceptions, "test error message").getErrorCode().getName()).isEqualTo("Testing");
            assertThat(CommonException.fromList(exceptions, "test error message").getErrorCode().getHttpStatusCode()).isEqualTo(0);
        }
    }
}