package com.digitalrealty.gapi.common.exceptions;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.SQLOutput;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class CommonExceptionsConfigurationTest {

    @Mock
    CommonExceptionsConfiguration commonExceptionsConfiguration;
    ErrorCode errorCode2;

    @BeforeEach
    void setUp() {
        errorCode2 = new ErrorCode("Testing", "Testing", 0, false);
    }

    @Test
    void mapErrorCode() {
        doNothing().when(commonExceptionsConfiguration).mapErrorCode("keyTest", errorCode2);
        commonExceptionsConfiguration.mapErrorCode("keyTest", errorCode2);
        verify(commonExceptionsConfiguration, times(1)).mapErrorCode("keyTest", errorCode2);
    }

    @Test
    void getErrorCode() {

        when(commonExceptionsConfiguration.getErrorCode("keyTest", errorCode2)).thenReturn(errorCode2);
        IErrorCode errorCode = commonExceptionsConfiguration.getErrorCode("keyTest", errorCode2);
        assertThat(errorCode).isNotNull();
        assertThat(errorCode.getName()).isEqualTo("Testing");
        assertThat(errorCode.getErrorText()).isEqualTo("Testing");
        assertThat(errorCode.getHttpStatusCode()).isEqualTo(0);
        assertThat(errorCode.isRecoverable()).isEqualTo(false);
        verify(commonExceptionsConfiguration, times(1)).getErrorCode("keyTest", errorCode2);
    }

    @Test
    void testGetErrorCode() {
        when(commonExceptionsConfiguration.getErrorCode("keyTest")).thenReturn(errorCode2);
        IErrorCode errorCode = commonExceptionsConfiguration.getErrorCode("keyTest");
        assertThat(errorCode).isNotNull();
        assertThat(errorCode.getName()).isEqualTo("Testing");
        assertThat(errorCode.getErrorText()).isEqualTo("Testing");
        assertThat(errorCode.getHttpStatusCode()).isEqualTo(0);
        assertThat(errorCode.isRecoverable()).isEqualTo(false);
        verify(commonExceptionsConfiguration, times(1)).getErrorCode("keyTest");
    }

    @Test
    void mapContainsKey() {
        when(commonExceptionsConfiguration.mapContainsKey("keyTest")).thenReturn(true);
        boolean testValue = commonExceptionsConfiguration.mapContainsKey("keyTest");
        assertThat(testValue).isEqualTo(true);
        verify(commonExceptionsConfiguration, times(1)).mapContainsKey("keyTest");
    }
}