package com.digitalrealty.gapi.common.exceptions;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import javax.validation.ConstraintViolationException;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ExceptionControllerAdviceTest {

    @Mock
    ExceptionControllerAdvice exceptionControllerAdvice;
    @Mock
    ConstraintViolationException constraintViolationException;
    @Mock
    MethodArgumentNotValidException methodArgumentNotValidException;
    @Mock
    HttpMediaTypeNotSupportedException httpMediaTypeNotSupportedException;
    @Mock
    MissingServletRequestParameterException missingServletRequestParameterException;
    @Mock
    ResourceAccessException resourceAccessException;
    @Mock
    NullPointerException nullPointerException;
    @Mock
    RuntimeException runtimeException;
    @Mock
    MethodArgumentTypeMismatchException methodArgumentTypeMismatchException;
    @Mock
    HttpMessageNotReadableException httpMessageNotReadableException;
    @Mock
    MissingRequestHeaderException missingRequestHeaderException;
    @Mock
    JsonParseException jsonParseException;
    @Mock
    JsonMappingException jsonMappingException;
    @Mock
    CommonException commonException;
    ResponseEntity<ErrorWrapper> responseEntity;

    @BeforeEach
    void setUp() {
        ErrorCode errorCode2 = new ErrorCode("Testing", "Testing", 0, false);
        CommonException commonException = new CommonException(errorCode2);
        ErrorWrapper errorWrapper = new ErrorWrapper(commonException, "Test Message");
        responseEntity = new ResponseEntity(errorWrapper, HttpStatus.OK);
    }

    @Test
    void handleCommonException() {
        when(exceptionControllerAdvice.handleCommonException(commonException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleCommonException(commonException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleCommonException(commonException);
    }

    @Test
    void handleConstraintViolationException() {
        when(exceptionControllerAdvice.handleConstraintViolationException(constraintViolationException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleConstraintViolationException(constraintViolationException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleConstraintViolationException(constraintViolationException);
    }

    @Test
    void handleMethodArgumentNotValidException() {
        when(exceptionControllerAdvice.handleMethodArgumentNotValidException(methodArgumentNotValidException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleMethodArgumentNotValidException(methodArgumentNotValidException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleMethodArgumentNotValidException(methodArgumentNotValidException);
    }

    @Test
    void handleHttpMediaTypeNotSupportedException() {
        when(exceptionControllerAdvice.handleHttpMediaTypeNotSupportedException(httpMediaTypeNotSupportedException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleHttpMediaTypeNotSupportedException(httpMediaTypeNotSupportedException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleHttpMediaTypeNotSupportedException(httpMediaTypeNotSupportedException);
    }

    @Test
    void handleMissingServletRequestParameterException() {
        when(exceptionControllerAdvice.handleMissingServletRequestParameterException(missingServletRequestParameterException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleMissingServletRequestParameterException(missingServletRequestParameterException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleMissingServletRequestParameterException(missingServletRequestParameterException);
    }

    @Test
    void handleResourceAccessException() {
        when(exceptionControllerAdvice.handleResourceAccessException(resourceAccessException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleResourceAccessException(resourceAccessException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleResourceAccessException(resourceAccessException);
    }

    @Test
    void handleNullPointerException() {
        when(exceptionControllerAdvice.handleNullPointerException(nullPointerException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleNullPointerException(nullPointerException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleNullPointerException(nullPointerException);
    }

    @Test
    void handleRuntimeException() {
        when(exceptionControllerAdvice.handleRuntimeException(runtimeException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleRuntimeException(runtimeException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleRuntimeException(runtimeException);
    }

    @Test
    void handleMethodArgumentTypeMismatchException() {
        when(exceptionControllerAdvice.handleMethodArgumentTypeMismatchException(methodArgumentTypeMismatchException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleMethodArgumentTypeMismatchException(methodArgumentTypeMismatchException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleMethodArgumentTypeMismatchException(methodArgumentTypeMismatchException);
    }

    @Test
    void handleHttpMessageNotReadableException() {
        when(exceptionControllerAdvice.handleHttpMessageNotReadableException(httpMessageNotReadableException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleHttpMessageNotReadableException(httpMessageNotReadableException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleHttpMessageNotReadableException(httpMessageNotReadableException);
    }

    @Test
    void handleMissingRequestHeaderException() {
        when(exceptionControllerAdvice.handleMissingRequestHeaderException(missingRequestHeaderException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleMissingRequestHeaderException(missingRequestHeaderException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleMissingRequestHeaderException(missingRequestHeaderException);
    }

    @Test
    void handleJsonParseException() {
        when(exceptionControllerAdvice.handleJsonParseException(jsonParseException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleJsonParseException(jsonParseException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleJsonParseException(jsonParseException);
    }

    @Test
    void handleJsonMappingException() {
        when(exceptionControllerAdvice.handleJsonMappingException(jsonMappingException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = exceptionControllerAdvice.handleJsonMappingException(jsonMappingException);
        performAssertion(responseEntity2);
        verify(exceptionControllerAdvice, times(1)).handleJsonMappingException(jsonMappingException);
    }

    private void performAssertion(ResponseEntity<ErrorWrapper> responseEntity2) {
        assertThat(responseEntity2).isNotNull();
        assertThat(responseEntity2.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity2.getBody().getErrorList().getErrors().get(0).getSource()).isEqualTo("Test Message");
        assertThat(responseEntity2.getBody().getErrorList().getErrors().get(0).getReasonCode()).isEqualTo("Testing");
        assertThat(responseEntity2.getBody().getErrorList().getErrors().get(0).getDescription()).isEqualTo("Testing");
        assertThat(responseEntity2.getBody().getErrorList().getErrors().get(0).getRecoverable()).isEqualTo(false);
    }
}