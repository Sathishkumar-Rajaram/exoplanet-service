package com.digitalrealty.gapi.common.exceptions;

import org.hibernate.exception.JDBCConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JPAExceptionControllerAdviceTest {

    @Mock
    JPAExceptionControllerAdvice jpaExceptionControllerAdvice;
    @Mock
    ObjectOptimisticLockingFailureException objectOptimisticLockingFailureException;
    @Mock
    DataIntegrityViolationException dataIntegrityViolationException;
    @Mock
    JDBCConnectionException jdbcConnectionException;

    ResponseEntity<ErrorWrapper> responseEntity;

    @BeforeEach
    void setUp() {
        ErrorCode errorCode2 = new ErrorCode("Testing", "Testing", 0, false);
        CommonException commonException = new CommonException(errorCode2);
        ErrorWrapper errorWrapper = new ErrorWrapper(commonException, "Test Message");
        responseEntity = new ResponseEntity(errorWrapper, HttpStatus.OK);
    }

    @Test
    void handleObjectOptimisticLockingFailureException() {

        when(jpaExceptionControllerAdvice.handleObjectOptimisticLockingFailureException(objectOptimisticLockingFailureException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = jpaExceptionControllerAdvice.handleObjectOptimisticLockingFailureException(objectOptimisticLockingFailureException);
        performAssertion(responseEntity2);
        verify(jpaExceptionControllerAdvice, times(1)).handleObjectOptimisticLockingFailureException(objectOptimisticLockingFailureException);
    }

    @Test
    void handleDataIntegrityViolationException() {

        when(jpaExceptionControllerAdvice.handleDataIntegrityViolationException(dataIntegrityViolationException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = jpaExceptionControllerAdvice.handleDataIntegrityViolationException(dataIntegrityViolationException);
        performAssertion(responseEntity2);
        verify(jpaExceptionControllerAdvice, times(1)).handleDataIntegrityViolationException(dataIntegrityViolationException);
    }

    @Test
    void handleJDBCConnectionException() {

        when(jpaExceptionControllerAdvice.handleJDBCConnectionException(jdbcConnectionException)).thenReturn(responseEntity);
        ResponseEntity<ErrorWrapper> responseEntity2 = jpaExceptionControllerAdvice.handleJDBCConnectionException(jdbcConnectionException);
        performAssertion(responseEntity2);
        verify(jpaExceptionControllerAdvice, times(1)).handleJDBCConnectionException(jdbcConnectionException);
    }

    private void performAssertion(ResponseEntity<ErrorWrapper> responseEntity2) {
        assertThat(responseEntity2).isNotNull();
        assertThat(responseEntity2.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity2.getBody().getErrorList().getErrors().get(0).getSource()).isEqualTo("Test Message");
        assertThat(responseEntity2.getBody().getErrorList().getErrors().get(0).getReasonCode()).isEqualTo("Testing");
        assertThat(responseEntity2.getBody().getErrorList().getErrors().get(0).getDescription()).isEqualTo("Testing");
        assertThat(responseEntity2.getBody().getErrorList().getErrors().get(0).getRecoverable()).isEqualTo(false);
    }
}