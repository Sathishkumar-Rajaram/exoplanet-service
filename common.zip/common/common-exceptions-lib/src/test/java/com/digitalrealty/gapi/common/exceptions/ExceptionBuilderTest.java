package com.digitalrealty.gapi.common.exceptions;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
class ExceptionBuilderTest {

    @Test
    void createMessage() {

        ErrorCode errorCode2 = new ErrorCode("Testing", "Testing", 0, false);
        CommonException commonException1 = new CommonException(errorCode2);

        try (MockedStatic<ExceptionBuilder> utilities = Mockito.mockStatic(ExceptionBuilder.class)) {
            utilities.when(() -> ExceptionBuilder.createMessage(commonException1)).thenReturn("Test Message");
            assertThat(ExceptionBuilder.createMessage(commonException1)).isEqualTo("Test Message");
        }
    }
}