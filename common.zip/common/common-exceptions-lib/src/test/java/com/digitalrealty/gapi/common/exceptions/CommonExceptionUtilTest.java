package com.digitalrealty.gapi.common.exceptions;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Collection;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
class CommonExceptionUtilTest {

    @Test
    void convertExceptionToCommonException() {

        ErrorCode errorCode = new ErrorCode("Testing", "Testing", 0, false);
        CommonException commonException1 = new CommonException(errorCode);
        Exception exception = new Exception("testException");
        Collection<IErrorCode> errorCodes2 = new ArrayList<>();
        errorCodes2.add(errorCode);

        try (MockedStatic<CommonExceptionUtil> utilities = Mockito.mockStatic(CommonExceptionUtil.class)) {
            utilities.when(() -> CommonExceptionUtil.convertExceptionToCommonException(exception, ErrorCode.BAD_REQUEST)).thenReturn(commonException1);
            assertThat(CommonExceptionUtil.convertExceptionToCommonException(exception, ErrorCode.BAD_REQUEST)).isNotNull();
            assertThat(CommonExceptionUtil.convertExceptionToCommonException(exception, ErrorCode.BAD_REQUEST).getErrorCode().getErrorText()).isEqualTo("Testing");
            assertThat(CommonExceptionUtil.convertExceptionToCommonException(exception, ErrorCode.BAD_REQUEST).getErrorCode().getName()).isEqualTo("Testing");
            assertThat(CommonExceptionUtil.convertExceptionToCommonException(exception, ErrorCode.BAD_REQUEST).getErrorCode().getHttpStatusCode()).isEqualTo(0);
        }
    }

    @Test
    void convertErrorHttpStatusToCommonException() {

        ErrorCode errorCode = new ErrorCode("Testing", "Testing", 0, false);
        CommonException commonException1 = new CommonException(errorCode);
        Exception exception = new Exception("testException");
        Collection<IErrorCode> errorCodes2 = new ArrayList<>();
        errorCodes2.add(errorCode);

        try (MockedStatic<CommonExceptionUtil> utilities = Mockito.mockStatic(CommonExceptionUtil.class)) {
            utilities.when(() -> CommonExceptionUtil.convertErrorHttpStatusToCommonException(HttpStatus.OK)).thenReturn(commonException1);
            assertThat(CommonExceptionUtil.convertErrorHttpStatusToCommonException(HttpStatus.OK)).isNotNull();
            assertThat(CommonExceptionUtil.convertErrorHttpStatusToCommonException(HttpStatus.OK).getErrorCode().getErrorText()).isEqualTo("Testing");
            assertThat(CommonExceptionUtil.convertErrorHttpStatusToCommonException(HttpStatus.OK).getErrorCode().getName()).isEqualTo("Testing");
            assertThat(CommonExceptionUtil.convertErrorHttpStatusToCommonException(HttpStatus.OK).getErrorCode().getHttpStatusCode()).isEqualTo(0);
        }

    }
}