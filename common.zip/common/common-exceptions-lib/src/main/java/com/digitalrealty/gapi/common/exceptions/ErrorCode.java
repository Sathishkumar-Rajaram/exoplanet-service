package com.digitalrealty.gapi.common.exceptions;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import lombok.EqualsAndHashCode;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public final class ErrorCode implements IErrorCode {
	public static final ErrorCode BAD_REQUEST = new ErrorCode("BAD_REQUEST", "Bad request was submitted.", 400, false);
	public static final ErrorCode BAD_URL = new ErrorCode("BAD_URL", "Bad URL.", 400, false);
	public static final ErrorCode CONSTRAINT_VIOLATION = new ErrorCode("CONSTRAINT_VIOLATION", "Request is invalid.", 400, false);
	public static final ErrorCode DOWNSTREAM_SYSTEM = new ErrorCode("DOWNSTREAM_SYSTEM", "Error communicating with downstream system.", 500, false);
	public static final ErrorCode DUPLICATE_RECORD = new ErrorCode("DUPLICATE_RECORD", "Duplicate record is not allowed.", 400, false);
	public static final ErrorCode EMPTY_RESPONSE = new ErrorCode("EMPTY_RESPONSE", "Received an empty response.", 400, false);
	public static final ErrorCode GET_PARAMETER_MISSING = new ErrorCode("GET_PARAMETER_MISSING", "Request parameter '{name}' is required.", 400, false);
	public static final ErrorCode JSON_TO_OBJECT = new ErrorCode("JSON_TO_OBJECT", "Can't convert JSON string.", 400, false);
	public static final ErrorCode OBJECT_TO_JSON = new ErrorCode("OBJECT_TO_JSON", "Can't convert object to JSON string.", 400, false);
	public static final ErrorCode MULTIPLE_EXCEPTIONS_FOUND = new ErrorCode("MULTIPLE_EXCEPTIONS_FOUND", "There were multiple exceptions", 400, false);
	public static final ErrorCode OPTIMISTIC_LOCKING = new ErrorCode("OPTIMISTIC_LOCKING", "This record has been modified. Please try again in a few seconds. If problem persists, please press F5 and try again.", 500, true);
	public static final ErrorCode RESOURCE_ACCESS = new ErrorCode("RESOURCE_ACCESS", "Resource is unavailable or down.", 500, false);
	public static final ErrorCode SYSTEM = new ErrorCode("SYSTEM", "There was an unexpected system error.", 500, false);
	public static final ErrorCode UNAUTHORIZED = new ErrorCode("UNAUTHORIZED", "Authorization error. You are not authorized to interact with Digital Realty Global API.", 401, false);
	public static final ErrorCode DOWNSTREAM_SERVICE_ERROR =  new ErrorCode("DOWNSTREAM_SERVICE_ERROR", "Downstream Global Portal service error", 500, false);
	public static final ErrorCode PAYLOAD_TOO_LARGE =  new ErrorCode("PAYLOAD_TOO_LARGE", "Request payload is too large to process the request", 413, false);

	@EqualsAndHashCode.Include
	private final String name;
	@EqualsAndHashCode.Exclude
	private final String errorText;
	@EqualsAndHashCode.Include
	private final int httpStatusCode;
	@EqualsAndHashCode.Include
	private final boolean recoverable;

	public ErrorCode(String name, String errortext, int httpStatusCode, boolean recoverable) {
		this.name = name;
		this.errorText = errortext;
		this.httpStatusCode = httpStatusCode;
		this.recoverable = recoverable;
	}

	private ErrorCode(IErrorCode oldCode, Map<String, Object> substitutionMap) {
		this.name = oldCode.getName();
		this.recoverable = oldCode.isRecoverable();
		this.httpStatusCode = oldCode.getHttpStatusCode();
		String errText = oldCode.getErrorText();
		if (substitutionMap != null) {
			for (Map.Entry<String, Object> entry : substitutionMap.entrySet()) {
				if (entry.getValue() == null) {
					errText = StringUtils.replace(errText, "{" + entry.getKey() + "}", "<null>");
				} else {
					errText = StringUtils.replace(errText, "{" + entry.getKey() + "}", entry.getValue().toString());
				}
			}
		}
		this.errorText = errText;
	}

	public IErrorCode withMappedErrorText(Map<String, Object> substitutionMap) {
		return new ErrorCode(this, substitutionMap);
	}

	@Override
	public String getErrorText() {
		return this.errorText;
	}

	@Override
	public int getHttpStatusCode() {
		return this.httpStatusCode;
	}

	@Override
	public boolean isRecoverable() {
		return this.recoverable;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
	}
}
