package com.digitalrealty.gapi.common.exceptions;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorList {
    @JsonProperty("Error")
    @Schema(required = true, description = "A List of Errors resulting from a request")
    private List<Error> errors;
}

