package com.digitalrealty.gapi.common.exceptions;

public interface ErrorData {
    String getDescription();

    String getDetails();

    String getSource();

    String getReasonCode();

    boolean isRecoverable();

    int getHttpStatusCode();
}
