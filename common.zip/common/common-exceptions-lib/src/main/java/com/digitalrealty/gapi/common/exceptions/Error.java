package com.digitalrealty.gapi.common.exceptions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Error {
	public static final String CORRELATIONID = "Correlation-Id";

	@JsonProperty("Source")
	@Schema(example = "SERVICE_NAME", description = "Identifies the service where the Error occurred")
	private String source;
	@JsonProperty("ReasonCode")
	@Schema(example = "ID_NOT_FOUND", description = "Code that identifies the Error")
	private String reasonCode;
	@JsonProperty("Description")
	@Schema(example = "The ID included in the request was not found", description = "Further details on what caused the error")
	private String description;
	@JsonProperty("Recoverable")
	@Schema(example = "false", description = "Describes if the request be able to continue after Error")
	private Boolean recoverable;
	@JsonProperty("Details")
	@Schema(example = "correlationid : a54496de-a1c7-4175-af46-b43c2c85be01", description = "Details of exact location of Error in the service and/or identifiers for tracing the request")
	private String details;

	public Error(CommonException commonException, String source) {
		this.source = source;
		this.reasonCode = commonException.getErrorCode().getName();
		this.recoverable = commonException.getErrorCode().isRecoverable();
		String errText = commonException.getErrorCode().getErrorText();
		StringBuilder detailsBuilder = new StringBuilder();
		Map<String, Object> temp = new HashMap<>(commonException.getAdditionalData());
		if (StringUtils.isNotBlank(commonException.getCorrelationId())) {
			temp.put(CommonException.CORRELATION_ID_CONTEXT_FIELD, commonException.getCorrelationId());
		} else {
			temp.put(CommonException.CORRELATION_ID_CONTEXT_FIELD, MDC.get(CORRELATIONID));
		}
		List<String> keys = temp.keySet().stream().collect(Collectors.toList());
		for (String key : keys) {
			String substr = "{" + key + "}";
			if (errText.contains(substr)) {
				if (temp.get(key) == null) {
					errText = StringUtils.replace(errText, substr, "<null>");
				} else {
					errText = StringUtils.replace(errText, substr, temp.get(key).toString());
				}
				temp.remove(key);
			}
		}
		this.description = errText;
		if (!temp.isEmpty()) {
			detailsBuilder.append(temp.entrySet().stream().map(entry -> entry.getKey() + " : " + entry.getValue()).collect(Collectors.joining(" ,")));
		}
		this.details = detailsBuilder.toString();
	}
}