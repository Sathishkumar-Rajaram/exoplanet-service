package com.digitalrealty.gapi.common.exceptions;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.MethodArgumentNotValidException;

import javax.validation.ConstraintViolationException;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
@Configuration
@ComponentScan
@Data
public class CommonExceptionsConfiguration {
    private final Map<String, IErrorCode> mappedErrorCodes = new LinkedHashMap<>();

    @Value("${errors.source:${spring.application.name:GlobalAPI}}")
    private String source;

    @Value("${errors.replace-source:false}")
    private boolean replaceDownStreamSource;

    /**
     * Map a key name a specific {@link IErrorCode}.
     * <p>
     * This method should be called during application startup to map application-specific {@link IErrorCode} instances
     * to be used when the application encounters one of the following exceptions: <br/>
     * {@link javax.validation.ConstraintViolation} <br/>
     * {@link org.springframework.web.bind.MethodArgumentNotValidException}
     * <p>
     * Key name formats<br/><pre>
     *      Annotation.className.fieldName
     *      Annotation.fieldName
     *      fieldName
     * </pre>
     * {@link org.springframework.http.converter.HttpMessageNotReadableException}<br/>
     * <p>
     * Key name formats<br/><pre>
     *      ExceptionClassName.fieldName
     *      fieldName
     *      ExceptionClassName
     * </pre>
     *
     * @param key  {@link String} the name of the entry to be mapped; MUST NOT be <code>null</code>
     * @param code {@link IErrorCode} to be mapped to the given key
     *
     * @see ExceptionControllerAdvice#handleConstraintViolationException(ConstraintViolationException)
     * @see ExceptionControllerAdvice#handleMethodArgumentNotValidException(MethodArgumentNotValidException)
     * @see ExceptionControllerAdvice#handleHttpMessageNotReadableException(HttpMessageNotReadableException)
     */
    public void mapErrorCode(String key, IErrorCode code) {
        this.mappedErrorCodes.put(key.toLowerCase(), code);
    }

    /**
     * Gets the {@link IErrorCode} that is mapped to the given key, or returns the defaultCode if the key is not present
     * in the Map.
     * <p>
     * This method is called by {@link ExceptionControllerAdvice} to find application-specific {@link
     * IErrorCode}s to be used for the following exceptions: <br/>
     * {@link javax.validation.ConstraintViolation} <br/>
     * {@link org.springframework.http.converter.HttpMessageNotReadableException}<br/>
     * {@link org.springframework.web.bind.MethodArgumentNotValidException}
     *
     * @param key         {@link String} the name of the entry to check; MUST NOT be <code>null</code>
     * @param defaultCode {@link IErrorCode}
     */
    public IErrorCode getErrorCode(String key, IErrorCode defaultCode) {
        return this.mappedErrorCodes.getOrDefault(key.toLowerCase(), defaultCode);
    }

    /**
     * This method is only meant for internal use - caller SHOULD first check {@link #mapContainsKey(String)}
     *
     * @param key {@link String} the name of the entry to check; MUST NOT be <code>null</code>
     *
     * @return {@link IErrorCode} for given key, if one exists; MAY be <code>null</code>
     */
    IErrorCode getErrorCode(String key) {
        return this.mappedErrorCodes.get(key.toLowerCase());
    }

    /**
     * check to see if the internal Map of {@link IErrorCode}s contains the given key
     *
     * @param key {@link String} the name of the entry to check; SHOULD NOT be <code>null</code>
     *
     * @return <code>true</code> if the given key exists; <code>false</code> otherwise
     */
    public boolean mapContainsKey(String key) {
        if (StringUtils.isBlank(key)) {
            return false;
        }
        return this.mappedErrorCodes.containsKey(key.toLowerCase());
    }

}
