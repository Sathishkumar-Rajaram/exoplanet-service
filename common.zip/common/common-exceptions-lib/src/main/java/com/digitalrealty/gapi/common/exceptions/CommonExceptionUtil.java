package com.digitalrealty.gapi.common.exceptions;

import org.springframework.http.HttpStatus;

public class CommonExceptionUtil {

	public static CommonException convertExceptionToCommonException(Exception e, ErrorCode errorCode) {
		if (e == null && errorCode == null) {
			return new CommonException(ErrorCode.SYSTEM);
		}

		if (e instanceof CommonException) {
			return (CommonException) e;
		}

		if (errorCode == null) {
			return new CommonException(ErrorCode.SYSTEM, e);
		}

		return new CommonException(errorCode, e);
	}

	public static CommonException convertErrorHttpStatusToCommonException(HttpStatus status) {
		if (status.equals(HttpStatus.NOT_FOUND)) {
			return new CommonException(ErrorCode.DOWNSTREAM_SYSTEM);
		}

		if (status.is4xxClientError()) {
			return new CommonException(ErrorCode.BAD_REQUEST);
		}

		if (status.is5xxServerError()) {
			return new CommonException(ErrorCode.RESOURCE_ACCESS);
		}

		throw new CommonException(ErrorCode.RESOURCE_ACCESS);
	}
	
	public static CommonException processOtherGapiServiceException(Throwable e) {
		if (e instanceof CommonException) {
			return (CommonException) e;
		} else
			return new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR, e);
	}
}
