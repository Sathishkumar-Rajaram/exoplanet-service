package com.digitalrealty.gapi.common.exceptions;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import lombok.EqualsAndHashCode;
import lombok.Value;

@Value
@EqualsAndHashCode(of = "errorCode")
public class CommonException extends RuntimeException {
    static final String CORRELATION_ID_CONTEXT_FIELD = "correlationid";

    private final transient String correlationId;
    private final transient IErrorCode errorCode;
    private final transient Map<String, Object> additionalData = new LinkedHashMap<>();
    private final transient List<CommonException> multipleCommonExceptions = new LinkedList<>();

    /**
     * Simplest constructor available.
     * <p>
     * Note that {@link IErrorCode} is reported upstream to API caller.
     * <p>
     * delegates to {@link #CommonException(IErrorCode, String, Throwable, Map, List)}
     *
     * @param errorCode {@link IErrorCode} MUST NOT be <code>null</code>
     */
    public CommonException(IErrorCode errorCode) {
        this(errorCode, null, null, null, null);
    }

    /**
     * delegates to {@link #CommonException(IErrorCode, String, Throwable, Map, List)}
     *
     * @param errorCode {@link IErrorCode} MUST NOT be <code>null</code>
     * @param cause     {@link Throwable} cause
     */
    public CommonException(IErrorCode errorCode, Throwable cause) {
        this(errorCode, ExceptionBuilder.createMessage(cause), cause, null, null);
    }

    /**
     * delegates to {@link #CommonException(IErrorCode, String, Throwable, Map, List)}
     *
     * @param errorCode    {@link IErrorCode} MUST NOT be <code>null</code>
     * @param errorMessage {@link String} a descriptive message to be logged (NOT reported upstream)
     *                     - will be generated from cause if blank
     * @param cause        {@link Throwable} cause
     */
    public CommonException(IErrorCode errorCode, String errorMessage, Throwable cause) {
        this(errorCode, errorMessage, cause, null, null);
    }

    /**
     * preferred constructor for wrapping other Throwables
     * <p>
     * delegates to {@link #CommonException(IErrorCode, String, Throwable, Map, List)}
     *
     * @param errorCode      {@link IErrorCode} MUST NOT be <code>null</code>
     * @param errorMessage   {@link String} a descriptive message to be logged (NOT reported upstream)
     *                       - will be generated from cause if blank
     * @param cause          {@link Throwable} cause
     * @param additionalData {@link Map} MAY be <code>null</code> (WILL be reported upstream if not null/empty)
     */
    public CommonException(IErrorCode errorCode, String errorMessage, Throwable cause, Map<String, ?> additionalData) {
        this(errorCode, errorMessage, cause, additionalData, null);
    }

    /**
     * Create a CommonException with an additional message to be logged.
     * <p>
     * Note that {@link IErrorCode} is reported upstream to API caller -
     * but the errorMessage will NOT be sent back (it will only be logged).
     * <p>
     * delegates to {@link #CommonException(IErrorCode, String, Throwable, Map, List)}
     *
     * @param errorCode    {@link IErrorCode} MUST NOT be <code>null</code>
     * @param errorMessage {@link String} descriptive message to be logged (NOT reported upstream)
     */
    public CommonException(IErrorCode errorCode, String errorMessage) {
        this(errorCode, errorMessage, null, null, null);
    }

    /**
     * Create a CommonException containing multiple exceptions.
     * <p>
     * The ErrorCode and all child ErrorCodes will be reported upstream to the API caller.
     * <p>
     * delegates to {@link #CommonException(IErrorCode, String, Throwable, Map, List)}
     *
     * @param errorCode                {@link IErrorCode} MUST NOT be <code>null</code> (will be reported upstream)
     * @param errorMessage             {@link String} descriptive message to be logged (NOT reported upstream)
     * @param multipleCommonExceptions List of additional exceptions to be reported upstream
     */
    CommonException(IErrorCode errorCode, String errorMessage, List<CommonException> multipleCommonExceptions) {
        this(errorCode, errorMessage, null, null, multipleCommonExceptions);
    }

    /**
     * delegates to {@link #CommonException(IErrorCode, String, Throwable, Map, List)}
     *
     * @param errorCode      {@link IErrorCode} MUST NOT be <code>null</code> (will be reported upstream)
     * @param errorMessage   {@link String} descriptive message to be logged (NOT reported upstream)
     * @param additionalData {@link Map} MAY be <code>null</code> (WILL be reported upstream)
     */
    public CommonException(IErrorCode errorCode, String errorMessage, Map<String, ?> additionalData) {
        this(errorCode, errorMessage, null, additionalData, null);
    }

    /**
     * Please use {@link #CommonException(IErrorCode, String, Map)}
     * <p>
     * delegates to {@link #CommonException(IErrorCode, String, Throwable, Map, List)}
     */
    public CommonException(IErrorCode errorCode, Map<String, ?> additionalData) {
        this(errorCode, null, null, additionalData, null);
    }

    /**
     * This is the primary constructor. All other constructors delegate to this one.
     * <p>
     * Users are encouraged to use one of the simpler constructors.
     *
     * @param errorCode                {@link IErrorCode} MUST NOT be <code>null</code> (will be reported upstream)
     * @param errorMessage             {@link String} descriptive message to be logged (NOT reported upstream)
     *                                 - will be generated from cause if blank
     * @param cause                    {@link Throwable} cause
     * @param additionalData           {@link Map} MAY be <code>null</code> (WILL be reported upstream)
     * @param multipleCommonExceptions List of additional exceptions to be reported upstream
     */
    CommonException(IErrorCode errorCode,
                    String errorMessage,
                    Throwable cause,
                    Map<String, ?> additionalData,
                    List<CommonException> multipleCommonExceptions) {
        super(StringUtils.isNotBlank(errorMessage) ? errorMessage : ExceptionBuilder.createMessage(cause), cause);
        this.errorCode = errorCode;
        if (additionalData != null) {
            this.additionalData.putAll(additionalData);
        }
        if (multipleCommonExceptions != null) {
            this.multipleCommonExceptions.addAll(multipleCommonExceptions);
        }
        this.correlationId = MDC.get(CORRELATION_ID_CONTEXT_FIELD);
    }

    @Override
    public String getMessage() {
        final StringBuilder sb = new StringBuilder(this.errorCode.getName()).append(": ").append(this.errorCode.getErrorText());
        if (!additionalData.isEmpty()) {
            sb.append(" Details: ");
            sb.append(additionalData.entrySet().stream().map(entry -> "[" + entry.getKey() + " = " + entry.getValue() + "]").collect(Collectors.joining(", ")));
        }
        String parentMessage = super.getMessage();
        if (StringUtils.isNotBlank(parentMessage) && !additionalData.containsValue(parentMessage)) {
            sb.append(" WithMessage: ").append(parentMessage);
        }
        if (!multipleCommonExceptions.isEmpty()) {
            for (CommonException each : this.getMultipleCommonExceptions()) {
                sb.append(" AND ");
                sb.append(each.getMessage());
            }
        }
        return sb.toString();
    }

    public static CommonException fromErrorCodes(Collection<IErrorCode> errorCodes) {
        List<CommonException> exceptionsList = new ArrayList<>();
        for (IErrorCode errorCode : errorCodes) {
            exceptionsList.add(new CommonException(errorCode));
        }
        return fromList(exceptionsList, null);
    }

    /**
     * @see #fromList(List, String)
     */
    public static CommonException fromList(List<CommonException> exceptions) {
        return fromList(exceptions, null);
    }

    /**
     * @param exceptions   a List of zero, one, or more {@link CommonException}s; MUST NOT be <code>null</code>
     * @param errorMessage a descriptive message to be logged (will not be sent back to API caller); <code>null</code>
     *                     safe
     *
     * @return {@link CommonException} never <code>null</code>
     */
    static CommonException fromList(List<CommonException> exceptions, String errorMessage) {
        switch (exceptions.size()) {
            case 0:
                return new CommonException(ErrorCode.SYSTEM, errorMessage);
            case 1:
                return exceptions.get(0);
            default:
                return new CommonException(ErrorCode.MULTIPLE_EXCEPTIONS_FOUND, errorMessage, exceptions);
        }
    }
}
