package com.digitalrealty.gapi.common.exceptions;

public interface IErrorCode {
    String getName();

    String getErrorText();

    int getHttpStatusCode();

    boolean isRecoverable();
}
