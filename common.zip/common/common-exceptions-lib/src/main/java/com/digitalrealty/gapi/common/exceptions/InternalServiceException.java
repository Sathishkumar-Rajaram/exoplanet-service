package com.digitalrealty.gapi.common.exceptions;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.util.Collections;
import java.util.List;

@Data
public class InternalServiceException extends RuntimeException implements ErrorData {
    private final String reasonCode;
    private final String description;
    private final boolean recoverable;
    private final String details;
    private final int httpStatusCode;
    private final transient List<InternalServiceException> multipleExceptions;
    private String source;//NOSONAR squid:S1165

    public InternalServiceException(ErrorData data) {
        this.source = data.getSource();
        this.reasonCode = data.getReasonCode();
        this.description = data.getDescription();
        this.recoverable = data.isRecoverable();
        this.details = data.getDetails();
        this.httpStatusCode = data.getHttpStatusCode();
        this.multipleExceptions = Collections.emptyList();
    }

    public InternalServiceException(String source, String reasonCode, String description, boolean recoverable, String details, int statusCode) {
        this.source = source;
        this.reasonCode = reasonCode;
        this.description = description;
        this.recoverable = recoverable;
        this.details = details;
        this.httpStatusCode = statusCode;
        this.multipleExceptions = Collections.emptyList();
    }

    InternalServiceException(List<InternalServiceException> multipleExceptions, int statusCode) {
        if (multipleExceptions == null || multipleExceptions.isEmpty()) {
            this.multipleExceptions = Collections.emptyList();
            this.source = null;
            this.reasonCode = ErrorCode.DOWNSTREAM_SYSTEM.getName();
            this.description = null;
            this.recoverable = Boolean.FALSE;
            this.details = null;
            this.httpStatusCode = statusCode;
        } else {
            this.multipleExceptions = Collections.unmodifiableList(multipleExceptions);
            this.description = multipleExceptions.get(0).getDescription();
            this.details = multipleExceptions.get(0).getDetails();
            this.reasonCode = multipleExceptions.get(0).getReasonCode();
            this.recoverable = multipleExceptions.get(0).isRecoverable();
            this.source = multipleExceptions.get(0).getSource();
            this.httpStatusCode = multipleExceptions.get(0).getHttpStatusCode();
        }
    }

    @Override
    public String getMessage() {
        final StringBuilder sb = new StringBuilder(reasonCode)
                .append(": ").append(description)
                .append(" Recoverable: ").append(recoverable)
                .append(" HttpStatus: ").append(httpStatusCode)
                .append(" Source: ").append(source);
        if (StringUtils.isNotBlank(details)) {
            sb.append(" Details: ").append(details);
        }
        if (!this.multipleExceptions.isEmpty()) {
            for (InternalServiceException each : this.getMultipleExceptions()) {
                sb.append(" AND ");
                sb.append(each.getMessage());
            }
        }
        return sb.toString();
    }

}

