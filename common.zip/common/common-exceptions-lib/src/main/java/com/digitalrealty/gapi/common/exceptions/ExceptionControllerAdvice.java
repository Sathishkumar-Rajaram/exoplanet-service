package com.digitalrealty.gapi.common.exceptions;

import static net.logstash.logback.argument.StructuredArguments.keyValue;

import java.util.*;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.GsonJsonParser;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Slf4j
@ControllerAdvice
@SuppressWarnings({ "squid:S1133", "java:S1874", "squid:S1123", "squid:CallToDeprecatedMethod" })
public class ExceptionControllerAdvice {
	public static final String CONSTRAINT_FIELD = "constraintField";
	public static final String ERROR_CODE = "errorCode";
	private static final String MAPPED_ERROR_CODE_FROM = "found ErrorCode mapping for '{}'";
	private static final String NO_ERROR_CODE_MAPPING_FOR = "NO ErrorCode mapping for '{}'";
	private static final String EMPTY_LIST_FOR_ERROR_CODE_MAPPING = "EMPTY list for ErrorCode mapping";
	private final CommonExceptionsConfiguration configuration;

	private final ObjectMapper objectMapper;

	@Autowired
	public ExceptionControllerAdvice(CommonExceptionsConfiguration commonExceptionsConfiguration, ObjectMapper objectMapper) {
		super();
		this.configuration = commonExceptionsConfiguration;
		this.objectMapper = new ObjectMapper();
	}

	@ExceptionHandler(CommonException.class)
	public ResponseEntity<ErrorWrapper> handleCommonException(CommonException ex) {
		HttpStatus status = HttpStatus.valueOf(ex.getErrorCode().getHttpStatusCode());
		if (status.is5xxServerError()) {
			log.error(ex.getMessage(), keyValue(ERROR_CODE, ex.getErrorCode().getName()), ex);
		} else {
			log.error(ex.getMessage(), keyValue(ERROR_CODE, ex.getErrorCode().getName()));
		}
		ErrorWrapper errorResponse = new ErrorWrapper(ex, configuration.getSource());
		return new ResponseEntity<>(errorResponse, null, status);
	}

	@ExceptionHandler({ ConstraintViolationException.class })
	public ResponseEntity<ErrorWrapper> handleConstraintViolationException(ConstraintViolationException ex) {
		Set<CommonException> exceptions = ex.getConstraintViolations().stream().map(e -> {
			String key = e.getPropertyPath().toString();
			ErrorCodeMapping errorCodeMapping = getMappedConstraintErrorCode(key);
			return new CommonException(errorCodeMapping.getIErrorCode(), Collections.singletonMap(CONSTRAINT_FIELD, errorCodeMapping.getMappingKey()));
		}).collect(Collectors.toSet());
		return handleCommonException(CommonException.fromList(new ArrayList<>(exceptions), ExceptionBuilder.createMessage(ex)));
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorWrapper> handleMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
		Set<CommonException> exceptions = exception.getBindingResult().getAllErrors().stream().map(e -> {
			ErrorCodeMapping errorCodeMapping = getMappedConstraintErrorCode(e.getCodes());
			return new CommonException(errorCodeMapping.getIErrorCode(), Collections.singletonMap(CONSTRAINT_FIELD, errorCodeMapping.getMappingKey()));
		}).collect(Collectors.toSet());
		return handleCommonException(CommonException.fromList(new ArrayList<>(exceptions), ExceptionBuilder.createMessage(exception)));
	}

	ErrorCodeMapping getMappedConstraintErrorCode(String... constraintNames) {
		if (constraintNames == null || constraintNames.length == 0) {
			log.error(EMPTY_LIST_FOR_ERROR_CODE_MAPPING);
			return new ErrorCodeMapping(ErrorCode.CONSTRAINT_VIOLATION, null);
		}
		// check fully qualified key name
		for (String constraintName : constraintNames) {
			if (configuration.mapContainsKey(constraintName)) {
				log.error(MAPPED_ERROR_CODE_FROM, constraintName);
				return new ErrorCodeMapping(configuration.getErrorCode(constraintName), constraintName);
			}
			log.error(NO_ERROR_CODE_MAPPING_FOR, constraintName);
		}
		return new ErrorCodeMapping(ErrorCode.CONSTRAINT_VIOLATION, StringUtils.joinWith("; ", constraintNames));
	}

	@ExceptionHandler(HttpMediaTypeNotSupportedException.class)
	public ResponseEntity<ErrorWrapper> handleHttpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException ex) {
		return handleCommonException(new CommonException(ErrorCode.BAD_REQUEST, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ResponseEntity<ErrorWrapper> handleMissingServletRequestParameterException(MissingServletRequestParameterException ex) {
		IErrorCode code = getMappedErrorCode(ex.getClass().getSimpleName(), ex.getParameterName(), ErrorCode.GET_PARAMETER_MISSING);
		Map<String, String> missing = new HashMap<>();
		missing.put("name", ex.getParameterName());
		missing.put("type", ex.getParameterType());
		return handleCommonException(new CommonException(code, ExceptionBuilder.createMessage(ex), missing));
	}

	@ExceptionHandler(ResourceAccessException.class)
	public ResponseEntity<ErrorWrapper> handleResourceAccessException(ResourceAccessException ex) {
		return handleCommonException(new CommonException(ErrorCode.RESOURCE_ACCESS, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<ErrorWrapper> handleNullPointerException(NullPointerException ex) {
		return handleCommonException(new CommonException(ErrorCode.SYSTEM, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<ErrorWrapper> handleRuntimeException(RuntimeException ex) {
		for (Throwable t : ExceptionUtils.getThrowableList(ex)) {
			if ((t instanceof CommonException) || (t instanceof CommonException)) {
				log.info("caught wrapped CommonException:{} as {}", ((CommonException) t).getErrorCode(), ex.getClass().getName());
				return handleCommonException((CommonException) t);
			}
		}
		return handleCommonException(new CommonException(ErrorCode.SYSTEM, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(WebClientResponseException.class)
	public ResponseEntity<ErrorWrapper> handleWebClientResponseException(WebClientResponseException ex) {
		try {
			ErrorWrapper errorWrapper = objectMapper.readValue(ex.getResponseBodyAsString(), ErrorWrapper.class);
			log.error("Caught WebClientResponseException: {}", ex);
			return new ResponseEntity<>(errorWrapper, ex.getStatusCode());
		}catch (Exception exception){
			log.error("{}", new CommonException(ErrorCode.JSON_TO_OBJECT, exception));
		}
		return handleCommonException(new CommonException(new ErrorCode(ex.getStatusText(), ex.getMessage(), ex.getStatusCode().value(), false)));
	}


	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ErrorWrapper> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex) {
		IErrorCode code = getMappedErrorCode(ex.getClass().getSimpleName(), ex.getName(), ErrorCode.BAD_REQUEST);
		return handleCommonException(new CommonException(code, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<ErrorWrapper> handleHttpMessageNotReadableException(HttpMessageNotReadableException ex) {
		String lastExceptionClassName = ex.getClass().getSimpleName();
		Throwable t = ex.getCause();
		while (t != null) {
			if (t instanceof JsonParseException) {
				return handleJsonParseException((JsonParseException) t);
			}
			if (t instanceof JsonMappingException) {
				return handleJsonMappingException((JsonMappingException) t);
			}
			lastExceptionClassName = t.getClass().getSimpleName();
			t = ex.getCause();
		}
		IErrorCode code = getMappedErrorCode(ex.getClass().getSimpleName(), lastExceptionClassName, ErrorCode.BAD_REQUEST);
		return handleCommonException(new CommonException(code, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(MissingRequestHeaderException.class)
	public ResponseEntity<ErrorWrapper> handleMissingRequestHeaderException(MissingRequestHeaderException ex) {
		String fieldName = ex.getHeaderName();
		IErrorCode code = getMappedErrorCode(ex.getClass().getSimpleName(), fieldName, ErrorCode.BAD_REQUEST);
		return handleCommonException(new CommonException(code, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(JsonParseException.class)
	public ResponseEntity<ErrorWrapper> handleJsonParseException(JsonParseException ex) {
		String fieldName = ex.getProcessor().getParsingContext().getCurrentName();
		IErrorCode code = getMappedErrorCode(ex.getClass().getSimpleName(), fieldName, ErrorCode.BAD_REQUEST);
		return handleCommonException(new CommonException(code, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(JsonMappingException.class)
	public ResponseEntity<ErrorWrapper> handleJsonMappingException(JsonMappingException ex) {
		String fieldName = null;
		if (!CollectionUtils.isEmpty(ex.getPath())) {
			fieldName = ex.getPath().get(ex.getPath().size() - 1).getFieldName();
		}
		IErrorCode code = getMappedErrorCode(ex.getClass().getSimpleName(), fieldName, ErrorCode.BAD_REQUEST);
		return handleCommonException(new CommonException(code, ExceptionBuilder.createMessage(ex), ex));
	}

	IErrorCode getMappedErrorCode(String exceptionClassName, String fieldName, IErrorCode defaultCode) {
		String combinedKey = exceptionClassName + "." + fieldName;
		if (this.configuration.mapContainsKey(combinedKey)) {
			log.debug(MAPPED_ERROR_CODE_FROM, combinedKey);
			return this.configuration.getErrorCode(combinedKey);
		}
		if (this.configuration.mapContainsKey(fieldName)) {
			log.debug(MAPPED_ERROR_CODE_FROM, fieldName);
			return this.configuration.getErrorCode(fieldName);
		}
		if (this.configuration.mapContainsKey(exceptionClassName)) {
			log.debug(MAPPED_ERROR_CODE_FROM, exceptionClassName);
			return this.configuration.getErrorCode(exceptionClassName);
		}
		log.error(NO_ERROR_CODE_MAPPING_FOR, combinedKey);
		return defaultCode;
	}

	@Data
	@AllArgsConstructor
	static class ErrorCodeMapping {
		private IErrorCode iErrorCode;
		private String mappingKey;
	}

	@ExceptionHandler(MaxUploadSizeExceededException.class)
	public ResponseEntity<ErrorWrapper> handleMaxUploadSizeExceededException(MaxUploadSizeExceededException ex) {
		IErrorCode code = getMappedErrorCode(ex.getClass().getSimpleName(), ex.getMessage(), ErrorCode.PAYLOAD_TOO_LARGE);
		return handleCommonException(new CommonException(code, ExceptionBuilder.createMessage(ex), ex));
	}
}
