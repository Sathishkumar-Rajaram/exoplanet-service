package com.digitalrealty.gapi.common.exceptions;

import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class ExceptionBuilder {

	ExceptionBuilder() {
	}

	/**
	 * @deprecated use {@link CommonException#fromErrorCodes(Collection)}
	 */
	@Deprecated(since = "3.0.0", forRemoval = true)
	@SuppressWarnings({ "squid:S1133", "squid:MissingDeprecatedCheck" })
	public static CommonException createCommonExceptionFromErrorCodes(Collection<IErrorCode> errorCodes) {
		return CommonException.fromErrorCodes(errorCodes);
	}

	/**
	 * @deprecated use {@link CommonException#fromList(List)}
	 */
	@Deprecated(since = "3.0.0", forRemoval = true)
	@SuppressWarnings({ "squid:S1133", "squid:MissingDeprecatedCheck" })
	public static CommonException createCommonExceptionFromList(List<CommonException> exceptions) {
		return CommonException.fromList(exceptions, null);
	}

	/**
	 * Gets a sensible string to put into the errorMessage argument when
	 * constructing a new {@link CommonException}.
	 *
	 * @param t {@link Throwable}; <code>null</code> safe
	 *
	 * @return {@link String} never <code>null</code> or empty
	 */
	static String createMessage(Throwable t) {
		if (t == null) {
			return null;
		}
		return StringUtils.isNotBlank(t.getMessage()) ? t.getClass().getSimpleName() + " : " + t.getMessage() : t.getClass().getSimpleName();
	}

}
