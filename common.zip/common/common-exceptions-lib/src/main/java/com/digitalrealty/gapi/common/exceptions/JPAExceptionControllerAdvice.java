package com.digitalrealty.gapi.common.exceptions;

import org.hibernate.exception.JDBCConnectionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
@ConditionalOnClass({ JDBCConnectionException.class, DataIntegrityViolationException.class, ObjectOptimisticLockingFailureException.class })
@Order(Ordered.HIGHEST_PRECEDENCE)
public class JPAExceptionControllerAdvice {

	private final ExceptionControllerAdvice exceptionControllerAdvice;

	@Autowired
	public JPAExceptionControllerAdvice(ExceptionControllerAdvice exceptionControllerAdvice) {
		super();
		this.exceptionControllerAdvice = exceptionControllerAdvice;
	}

	@ExceptionHandler(ObjectOptimisticLockingFailureException.class)
	public ResponseEntity<ErrorWrapper> handleObjectOptimisticLockingFailureException(ObjectOptimisticLockingFailureException ex) {
		return exceptionControllerAdvice.handleCommonException(new CommonException(ErrorCode.OPTIMISTIC_LOCKING, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<ErrorWrapper> handleDataIntegrityViolationException(DataIntegrityViolationException ex) {
		return exceptionControllerAdvice.handleCommonException(new CommonException(ErrorCode.DUPLICATE_RECORD, ExceptionBuilder.createMessage(ex), ex));
	}

	@ExceptionHandler(JDBCConnectionException.class)
	public final ResponseEntity<ErrorWrapper> handleJDBCConnectionException(JDBCConnectionException ex) {
		return exceptionControllerAdvice.handleCommonException(new CommonException(ErrorCode.RESOURCE_ACCESS, ExceptionBuilder.createMessage(ex), ex));
	}

}
