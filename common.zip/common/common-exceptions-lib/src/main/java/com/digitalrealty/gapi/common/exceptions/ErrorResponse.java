package com.digitalrealty.gapi.common.exceptions;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ErrorResponse {
    @JsonProperty("Errors")
    @Schema(required = true)
    private ErrorList standardErrorList;

    public ErrorResponse(CommonException commonException, String source) {
        List<Error> errors = new ArrayList<>();
        if (!CollectionUtils.isEmpty(commonException.getMultipleCommonExceptions())) {
            commonException.getMultipleCommonExceptions().stream().forEach(e -> errors.add(new Error(e, source)));
        } else {
            errors.add(new Error(commonException, source));
        }
        standardErrorList = new ErrorList(errors);
    }
}
