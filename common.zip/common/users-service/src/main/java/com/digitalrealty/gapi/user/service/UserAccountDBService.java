package com.digitalrealty.gapi.user.service;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.mapper.UserAccountMapper;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.repository.UserAccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class UserAccountDBService {

	private final UserAccountRepository userAccountRepository;

	private final UserAccountMapper userAccountMapper;
	public List<UserAccount> findByIdIn(List<UUID> userAccountIds) {
		return userAccountRepository.findByIdIn(userAccountIds).stream().map(userAccount -> userAccountMapper.map(userAccount)).collect(Collectors.toList());
	}

	public UserAccount findByAccountIdAndUserId(String accountId, UUID userId) {
		return userAccountMapper.map(userAccountRepository.findByLegalEntityKeyAndUserId(accountId, userId));
	}

	public List<UserAccount> findByAccountId(String accountId) {
		return userAccountRepository.findByLegalEntityKey(accountId).stream().map(userAccount -> userAccountMapper.map(userAccount)).collect(Collectors.toList());
	}

	public List<UserAccount> findByIdsAndStatus(List<UUID> userAccountIds, UserAccountStatus status) {
		return userAccountRepository.findByIdInAndStatus(userAccountIds, status).stream().map(userAccount -> userAccountMapper.map(userAccount)).collect(Collectors.toList());
	}

	public List<UserAccount> findByUserId(UUID userId) {
		return userAccountRepository.findByUserId(userId).stream().map(userAccount -> userAccountMapper.map(userAccount)).collect(Collectors.toList());
	}

	public List<UserAccount> findByUserEmailAndApprovalStatus(String email, ApprovalStatus approvalStatus) {
		return userAccountRepository.findByUserEmailAndApprovalStatus(email, approvalStatus.toString()).stream().map(userAccount -> userAccountMapper.map(userAccount)).collect(Collectors.toList());
	}
	public List<UserAccount> saveAccountApprovals(Map<UUID, ApprovalStatus> userAccounts) {
		List<UserAccountEntity> userAccountEntities = userAccountRepository.findByIdIn(userAccounts.keySet().stream().collect(Collectors.toList()));

		userAccountEntities = userAccountEntities.stream().map(userAccount -> {
			ApprovalStatus status = userAccounts.get(userAccount.getId());
			userAccount.setApprovalStatus(status);
			return userAccount;
		}).collect(Collectors.toList());

		return ((List<UserAccountEntity>) userAccountRepository.saveAll(userAccountEntities)).stream().map(userAcc -> userAccountMapper.map(userAcc)).collect(Collectors.toList());
	}

	public UserAccount saveAccount(UserAccount userAccount) {
		return userAccountMapper.map(userAccountRepository.save(userAccountMapper.map(userAccount)));
	}

	public void manageDefaultAccount(List<UserAccount> userAccounts) {
		List<UserAccountEntity> userAccountDefaultEntities = new ArrayList<>();
		userAccounts.stream()
				.forEach(userAccount -> {
					if ((!Objects.isNull(userAccount.getLegalEntityKey())) && (userAccount.getLegalEntityKey().equals(ContextUtility.getLegalEntity()) && !userAccount.getDefaultAccount())) {
						userAccount.setDefaultAccount(true);
						userAccountDefaultEntities.add(userAccountMapper.map(userAccount));
					} else if (userAccount.getDefaultAccount()) {
						userAccount.setDefaultAccount(false);
						userAccountDefaultEntities.add(userAccountMapper.map(userAccount));
					}
				});
		if (!userAccountDefaultEntities.isEmpty()) {
			userAccountRepository.saveAll(userAccountDefaultEntities);
		}
	}
	public Integer getActiveUserCount(String legalEntityKey) {
		return userAccountRepository.getActiveUserCount(legalEntityKey);
	}
}
