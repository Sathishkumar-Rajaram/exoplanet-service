package com.digitalrealty.gapi.user.model;

public interface ISuperUser {

	String getEmail();

}
