package com.digitalrealty.gapi.user.entity;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Audited
@Table(name = "user_account_role")
public class UserAccountRoleEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Type(type = "uuid-char")
	private UUID roleId;

	@Type(type = "uuid-char")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_account_role_assets_id", nullable = false)
	private UserAccountRoleAssetsEntity userAccountRoleAssets;
}
