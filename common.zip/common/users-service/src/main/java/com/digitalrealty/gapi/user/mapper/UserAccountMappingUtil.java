package com.digitalrealty.gapi.user.mapper;

import java.util.Collections;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.mapstruct.Named;
import org.springframework.stereotype.Component;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.model.UserAccountRoleAssets;
import com.digitalrealty.gapi.user.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class UserAccountMappingUtil {

	private final UserRepository userRepository;

	private final UserAccountRoleAssetsMapper userAccountRoleAssetsMapper;

	@Named("getUserAccountAssociations")
	public Set<UserAccountRoleAssets> getUserAccountAssociations(UserAccountEntity userAccount) {
		if (ObjectUtils.isNotEmpty(userAccount.getUserAccountRoleAssets())) {
			return userAccount.getUserAccountRoleAssets().stream().map(associationEntity -> userAccountRoleAssetsMapper.map(associationEntity)).collect(Collectors.toSet());

		}
		return Collections.<UserAccountRoleAssets>emptySet();
	}

	@Named("getUserByUserId")
	public UserEntity getUserByUserId(UUID userId) {
		return userRepository.findById(userId)
				.orElseThrow(() -> new CommonException(UserErrorCode.USER_NOTFOUND));
	}

}