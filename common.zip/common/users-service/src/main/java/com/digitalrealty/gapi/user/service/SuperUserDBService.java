package com.digitalrealty.gapi.user.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.user.repository.SuperUserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class SuperUserDBService {

	private final SuperUserRepository superUserRepository;

	public String findByEmail(String email) {
		return superUserRepository.findByEmail(email);
	}
}
