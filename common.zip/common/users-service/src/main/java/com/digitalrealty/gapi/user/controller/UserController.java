package com.digitalrealty.gapi.user.controller;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.user.configuration.ActionsConfig;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.payloadmodel.AccountValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountApprovalRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountApprovalResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssetResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssetRoles;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssignmentRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociationsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountRoleResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountStatusRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountStatusResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileUpdateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileUpdateResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateResponse;
import com.digitalrealty.gapi.user.service.AccountService;
import com.digitalrealty.gapi.user.service.AuthorizationService;
import com.digitalrealty.gapi.user.service.UserAccountAssetService;
import com.digitalrealty.gapi.user.service.UserAccountRoleService;
import com.digitalrealty.gapi.user.service.UserAccountService;
import com.digitalrealty.gapi.user.service.UserService;

import lombok.RequiredArgsConstructor;
import springfox.documentation.annotations.ApiIgnore;

@RequiredArgsConstructor
@RestController
public class UserController {

	private final AuthorizationService authorizationService;

	private final AccountService accountService;

	private final UserAccountAssetService userAccountAssetService;

	private final UserAccountRoleService userAccountRoleService;

	private final UserService userService;

	private final UserAccountService userAccountService;

	private final ActionsConfig actionsConfig;

	@PostMapping(value = "/users", produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity<UserCreateResponse> createUser(@Valid @RequestBody UserCreateRequest createUserRequest) {
		authorizationService.isAuthorized(ActionValidationRequest.builder().actions(actionsConfig.getCreateUser()).build());

		return new ResponseEntity<>(userService.createUser(createUserRequest), HttpStatus.CREATED);
	}

	@PutMapping(value = "/users/update", produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity<UserProfileUpdateResponse> updateUserProfile(@Valid @RequestBody UserProfileUpdateRequest userProfileUpdateRequest) {
		return new ResponseEntity<>(userService.updateUserProfile(userProfileUpdateRequest), HttpStatus.OK);
	}

	@PutMapping(value = "/users/{user_id}", produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity<UserUpdateResponse> updateUser(@NotBlank @PathVariable(value = "user_id") UUID userId, @Valid @RequestBody UserUpdateRequest updateUserRequest) {
		authorizationService.isAuthorized(ActionValidationRequest.builder().actions(actionsConfig.getUpdateUser()).build());

		return new ResponseEntity<>(userService.updateUser(userId, updateUserRequest), HttpStatus.OK);
	}

	@GetMapping(value = "/users/{user_id}", produces = { "application/json" })
	public ResponseEntity<UserProfileResponse> getUserProfile(@NotBlank @PathVariable(value = "user_id") UUID userId) {
		authorizationService.isAuthorized(ActionValidationRequest.builder().actions(actionsConfig.getGetUserProfile()).build());

		return new ResponseEntity<>(userService.getUser(userId), HttpStatus.OK);
	}

	@GetMapping(value = "/users/user-account-previously-associated", produces = { "application/json" })
	public ResponseEntity<List<User>> getDeletedUserAccountForGU() {
		authorizationService.isAuthorized(ActionValidationRequest.builder().actions(actionsConfig.getGetDeletedUserAccountForGU()).build());

		return new ResponseEntity<>(userService.getDeletedUserAccount(), HttpStatus.OK);
	}

	@GetMapping(value = "/users/accounts", produces = { "application/json" })
	public ResponseEntity<Page<UserResponse>> getUsersInAccount(
			@RequestParam(value = "firstName", required = false) String filterFirstName,
			@RequestParam(value = "lastName", required = false) String filterLastName,
			@RequestParam(value = "email", required = false) String filterEmail,
			@RequestParam(value = "phone", required = false) String filterPhone,
			@RequestParam(value = "status", required = false) String filterStatus,

			@RequestParam(value = "sort", required = false, defaultValue = "asc") String sort,
			@RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
			@RequestParam(value = "size", required = false, defaultValue = "${pagination.size}") Integer size) {
		authorizationService.isAuthorized(ActionValidationRequest.builder().actions(actionsConfig.getGetUsersInAccount()).build());

		Pageable pageable = null;
		if (sort.contains(",")) {
			String[] sortParams = sort.split(",");
			pageable = PageRequest.of(page, size, sortParams[1].equalsIgnoreCase("DESC") ? Sort.Direction.DESC : Sort.Direction.ASC, sortParams[0]);
		} else {
			pageable = PageRequest.of(page, size, Sort.by(sort.equalsIgnoreCase("DESC") ? Sort.Direction.DESC : Sort.Direction.ASC, "id"));
		}

		return new ResponseEntity<>(userService.getUsers(pageable, filterFirstName, filterLastName, filterEmail, filterPhone, filterStatus), HttpStatus.OK);
	}

	@ApiIgnore
	@GetMapping(value = "/users/assetIds", produces = { "application/json" })
	public ResponseEntity<UserAccountAssetResponse> getUserAssets() {
		return new ResponseEntity<>(userAccountAssetService.getUserAssets(), HttpStatus.OK);
	}

	@ApiIgnore
	@GetMapping(value = "/users/roleIds", produces = { "application/json" })
	public ResponseEntity<UserAccountRoleResponse> getUserRoles() {
		return new ResponseEntity<>(userAccountRoleService.getUserRoles(), HttpStatus.OK);
	}

	@ApiIgnore
	@GetMapping(value = "/users/accountIds", produces = { "application/json" })
	public ResponseEntity<UserAccountResponse> getUserAccounts() {
		return new ResponseEntity<>(userAccountService.getUserAccounts(), HttpStatus.OK);
	}

	@PutMapping(value = "/users/{user_id}/user-account-status", produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity<UserAccountStatusResponse> updateUserAccountStatus(@NotBlank @PathVariable(value = "user_id") UUID userId, @Valid @RequestBody UserAccountStatusRequest userAccountApproval) {
		accountService.validateAccount(AccountValidationRequest.builder().legalEntityKeys(userAccountApproval.getUserAccounts().keySet().stream().collect(Collectors.toList())).build());
		authorizationService.isAuthorized(ActionValidationRequest.builder().actions(actionsConfig.getUpdateUserStatus()).build());

		return new ResponseEntity<>(userAccountService.updateUserAccountStatus(userId, userAccountApproval), HttpStatus.OK);
	}

	@PutMapping(value = "/users/user-account-approvals", produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity<UserAccountApprovalResponse> updateUserAccountApproval(@Valid @RequestBody UserAccountApprovalRequest userAccountApproval) {
		return new ResponseEntity<>(userAccountService.updateUserAccountApproval(userAccountApproval), HttpStatus.OK);
	}

	@GetMapping(value = "/users/{user_id}/assignments", produces = { "application/json" })
	public ResponseEntity<List<UserAccountAssociationsResponse>> getUserAssignments(@NotBlank @PathVariable(value = "user_id") UUID userId) {
		return new ResponseEntity<>(userAccountService.getUserAssignments(userId), HttpStatus.OK);
	}

	@PutMapping(value = "/users/{user_id}/assignments", produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity<User> manageAssignments(@NotBlank @PathVariable(value = "user_id") UUID userId, @Valid @RequestBody UserAccountAssignmentRequest userAccountAssignmentRequest) {
		accountService.validateAccount(AccountValidationRequest.builder().legalEntityKeys(userAccountAssignmentRequest.getUserAccounts().stream().map(UserAccountAssetRoles::getLegalEntityKey).collect(Collectors.toList())).build());
		authorizationService.isAuthorized(ActionValidationRequest.builder().actions(actionsConfig.getManageAssignments()).build());

		boolean includeInternal = false;
		try {
			authorizationService.isAuthorized(ActionValidationRequest.builder().actions(actionsConfig.getManageAssignmentsInternal()).build());
			includeInternal = true;
		} catch (Exception ex) {
			includeInternal = false;
		}

		if (!includeInternal && userAccountAssignmentRequest.getUserAccounts().stream().filter(UserAccountAssetRoles::getAnyAccount).count() > 0) {
			throw new CommonException(UserErrorCode.NO_PERMISSION);
		}

		return new ResponseEntity<>(userAccountService.manageAssignments(userId, includeInternal, userAccountAssignmentRequest), HttpStatus.OK);
	}

	@GetMapping(value = "/users/user-account-approvals", produces = { "application/json" })
	public ResponseEntity<List<UserAccount>> getUserAccountAssociations() {
		return new ResponseEntity<>(userAccountService.getUserAccountAssociations(), HttpStatus.OK);
	}

	@PutMapping(value = "/users/default-account", consumes = { "application/json" })
	public void manageDefaultAccount() {
		userAccountService.manageDefaultAccount();
	}

	@GetMapping(value = { "/users/active-users-number" })
	public Integer getActiveUsers() {
		return userAccountService.getActiveUserCount(ContextUtility.getLegalEntity());
	}
}
