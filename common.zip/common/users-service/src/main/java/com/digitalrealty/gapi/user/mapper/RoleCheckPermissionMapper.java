package com.digitalrealty.gapi.user.mapper;

import java.util.List;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.user.model.payloadmodel.RoleCheckPermissionsRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociations;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true))
public interface RoleCheckPermissionMapper {

	RoleCheckPermissionsRequest mapActionAndRolesToRoleCheck(String method, List<String> action, String legalEntityKey, UserAccountAssociations loggedAccountRoles);

}
