package com.digitalrealty.gapi.user.model;

import java.time.Instant;
import java.util.Set;

import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.enums.TermStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class User extends BaseModel {

	private String firstName;

	private String lastName;

	private String email;

	private String phone;

	private UserStatus status;

	private InternalStatus internalStatus;

	private TermStatus termsAndConditionsStatus;

	private Instant termsAndConditionsDate;

	private String termsAndConditionsVersion;

	private Instant statusChangeDate;

	private Set<UserAccount> userAccounts;

}
