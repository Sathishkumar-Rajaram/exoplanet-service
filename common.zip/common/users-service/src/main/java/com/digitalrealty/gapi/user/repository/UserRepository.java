package com.digitalrealty.gapi.user.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;

@Repository
public interface UserRepository extends PagingAndSortingRepository<UserEntity, UUID> {

	UserEntity findByEmail(String email);

	List<UserEntity> findByStatusIn(List<UserStatus> userStatuses);

	List<UserEntity> findByInternalStatusIn(List<InternalStatus> internalStatuses);

	List<UserEntity> findByStatus(UserStatus userStatus);

	Page<UserEntity> findByIdIn(List<UUID> userIdList, Pageable pageable);

	@Modifying
	// ************* H2 syntax - use only locally - !!!!!!!! NEVER CHECK IN
	// !!!!!!!!!!
	// @Query(value = "update user_gapi.users set execution_id = ?1 WHERE
	// internal_status in
	// ('NEED_SYNC','IDP_SYNCED','SNOW_SYNCED','NEED_ASSIGNMENT_SYNC') and
	// execution_id is null limit ?2", nativeQuery = true)
	// ********************************************************************************
	@Query(value = "update top(?2) user_gapi.users set execution_id = ?1 WHERE internal_status in ('NEED_SYNC','IDP_SYNCED','SNOW_SYNCED','NEED_ASSIGNMENT_SYNC') and execution_id is null", nativeQuery = true)
	void updateExecutionId(String executionId, int batchExecutionIdsSize);

	@Modifying
	@Query(value = "update user_gapi.users set execution_id=null where (EXTRACT (EPOCH FROM (CURRENT_TIMESTAMP()-last_modified_date))) > ?1 and execution_id is not null;", nativeQuery = true)
	void resetExecutionIds(long resetExecutionIdsTimeWindowSec);

	@Modifying
	@Query(value = "update user_gapi.users set execution_id = null WHERE execution_id = ?1", nativeQuery = true)
	void updateExecutionIdAsNull(String executionId);

	@Query(value = "select * from user_gapi.users WHERE execution_id = ?1", nativeQuery = true)
	List<UserEntity> findByExecutionId(String executionId);

	List<UserEntity> findByUserAccountsLegalEntityKeyInAndUserAccountsStatus(List<String> legalEntityKeys, UserAccountStatus status);
}