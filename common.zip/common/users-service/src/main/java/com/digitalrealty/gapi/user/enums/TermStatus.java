package com.digitalrealty.gapi.user.enums;

public enum TermStatus {
	ALERTED,
	ACCEPTED,
	REJECTED;
}
