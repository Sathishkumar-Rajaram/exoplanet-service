package com.digitalrealty.gapi.user.model;

import com.digitalrealty.gapi.user.model.snow.UCmdbCiRef1;
import com.digitalrealty.gapi.user.model.snow.UContactRef1;
import com.digitalrealty.gapi.user.model.snow.UCustomerRef1;
import com.digitalrealty.gapi.user.model.snow.ULocationRef1;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InsertUser {

    public String u_pm_high_sched;
    public String u_approve_additional_charges;
    public String u_appr_await_appr;
    public String u_place_orders;
    public String u_access_area_owner;
    public String u_accounting_contact;
    public String sys_updated_on;
    public String u_authorize_deliveries;
    public String u_read_only;
    public String u_access_area_delegate;
    public String u_everbridge;
    public String sys_updated_by;
    public String u_pm_low_wip;
    public String u_appr_rejected;
    public String sys_created_on;
    public String u_sec_approved;
    public String u_sec_wip;
    public String u_access_area_visitor;
    public String sys_created_by;
    public String u_authorize_vendor_work;
    public String u_pm_high_wc;
    public String u_emergency_contact;
    public String u_pm_low_sched;
    public String u_sfdc_access_rights_number;
    public String u_appr_approved;
    public String u_data_center_contact;
    public String u_sec_rejected;
    public String u_customer_evacuation_assistance_required;
    public String u_access_facility;
    public String u_fire_warden_contact;
    public String u_last_contact_to_update;
    public String u_customer_portal_access;
    public UCmdbCiRef1 u_cmdb_ci_ref_1;
    public ULocationRef1 u_location_ref_1;
    public String u_pbb_include;
    public String u_sec_await_appr;
    public String u_operations_contact;
    public String u_sec_wc;
    public String sys_id;
    public String u_end_date;
    public String u_dcim_enabled;
    public String u_sla_notification;
    public String u_pm_high_wip;
    public String u_sec_rec;
    public UContactRef1 u_contact_ref_1;
    public String sys_mod_count;
    public String u_pm_low_wc;
    public String u_request_support;
    public String sys_tags;
    public String u_ip_network_contact;
    public UCustomerRef1 u_customer_ref_1;
    public String u_view_invoices;
    public String u_primary_contact;
    public String u_change_management_approver_1;
    public String u_remote_hands_contact;
}
