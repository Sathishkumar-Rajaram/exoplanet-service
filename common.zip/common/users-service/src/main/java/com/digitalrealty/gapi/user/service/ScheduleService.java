package com.digitalrealty.gapi.user.service;

import java.util.List;
import java.util.UUID;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.user.configuration.JobsConfig;
import com.digitalrealty.gapi.user.model.User;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class ScheduleService {

	private final UserService userService;

	private final UserDBService userDBService;

	private final JobsConfig jobsConfig;

	@Scheduled(cron = "${jobs.resetExecutionIdSchedule}")
	public void resetExecutionIds() {
		try {

			userDBService.resetExecutionIds(jobsConfig.getResetExecutionIdsTimeWindowSec());

		} catch (CommonException e) {
			log.error("Reset execution ids as null on timewindow has failed", e);
		} catch (Exception e) {
			log.error("Reset execution ids as null on timewindow has failed", new CommonException(ErrorCode.SYSTEM, e));
		}
	}

	@Scheduled(cron = "${jobs.manageExecutionIdSchedule}")
	public void manageExecutionId() {
		log.debug("manageExecutionId");
		String executionId = UUID.randomUUID().toString();

		try {

			userDBService.updateExecutionId(executionId, jobsConfig.getManageExecutionIdsBatchSize());

			List<User> syncUsers = userDBService.findByExecutionId(executionId);

			userService.updateExternalSystems(syncUsers);

		} catch (CommonException e) {
			log.error("Update external systems internal status has failed", e);
		} catch (Exception e) {
			log.error("Update execution id on internal status has failed", new CommonException(ErrorCode.SYSTEM, e));
		} finally {
			try {
				userDBService.updateExecutionIdAsNull(executionId);
			} catch (CommonException e) {
				log.error("Update execution id as null has failed", e);
			} catch (Exception e) {
				log.error("Update execution id as null has failed", new CommonException(ErrorCode.SYSTEM, e));
			}
		}
	}
}
