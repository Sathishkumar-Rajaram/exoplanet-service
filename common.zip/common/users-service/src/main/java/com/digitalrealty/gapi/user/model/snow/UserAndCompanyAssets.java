package com.digitalrealty.gapi.user.model.snow;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserAndCompanyAssets {

	private String u_pm_high_sched;

	private Object u_last_contact_to_update;

	private String u_appr_await_appr;

	private UCmdbCiRef1 u_cmdb_ci_ref_1;

	private String u_pbb_include;

	private String sys_updated_on;

	private String u_sec_await_appr;

	private String sys_id;

	private String sys_updated_by;

	private String u_pm_low_wip;

	private String u_work_in_progress;

	private String sys_created_on;

	private String u_active;

	private String u_sec_approved;

	private String u_dcim_enabled;

	private String u_type;

	private String sys_created_by;

	private String u_pm_high_wip;

	private String u_data_center_ref_1;

	private String u_customer_approval;

	private String u_sec_rec;

	private String u_customer_escorted_only;

	private String u_pm_high_wc;

	private String sys_mod_count;

	private String u_pm_low_sched;

	private String u_pm_low_wc;

	private String sys_tags;

	private USiteCodeRef1 u_site_code_ref_1;

	private String u_tenant_code;

	private String u_work_completed;

	private UCustomerRef1 u_customer_ref_1;

	private String u_appr_rejeced;

	private String u_appr_approved;

	private String u_sec_rejected;

}
