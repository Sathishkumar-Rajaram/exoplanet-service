package com.digitalrealty.gapi.user.service;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EncryptionService {

	public String encryptEmail(String userEmail) {
		// TODO implement decryption
		return userEmail;
	}

}
