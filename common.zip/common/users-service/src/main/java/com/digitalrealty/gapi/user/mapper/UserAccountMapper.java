package com.digitalrealty.gapi.user.mapper;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.payloadmodel.GetAccountsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociationsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountsResponse;
import com.digitalrealty.gapi.user.repository.UserRepository;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true), uses = { UserAccountMappingUtil.class, UserAccountRoleAssetsMapper.class, UserAccountAssetMapper.class, UserAccountRoleMapper.class, UserRepository.class })
public interface UserAccountMapper {

	@Mapping(target = "user", source = "userId", qualifiedByName = "getUserByUserId")
	UserAccountEntity map(UserAccount userAccount);

	@Mapping(target = "associations", source = "userAccountEntity", qualifiedByName = "getUserAccountAssociations")
	@Mapping(target = "userId", source = "user.id")
	UserAccount map(UserAccountEntity userAccountEntity);

	@Mapping(target = "userAccountId", source = "userAccount.id")
	@Mapping(target = "legalEntityKey", source = "userAccount.legalEntityKey")
	@Mapping(target = "status", source = "userAccount.status")
	@Mapping(target = "approvalStatus", source = "userAccount.approvalStatus")
	@Mapping(target = "defaultAccount", source = "userAccount.defaultAccount")
	@Mapping(target = "anyAccount", source = "userAccount.anyAccount")
	@Mapping(target = "statusChangedDate", source = "userAccount.statusChangedDate")
	@Mapping(target = "account", source = "account")
	UserAccountsResponse mapToUserAccountsResponse(UserAccountEntity userAccount, GetAccountsResponse account);

	@Mapping(target = "userAccountId", source = "userAccount.id")
	@Mapping(target = "legalEntityKey", source = "userAccount.legalEntityKey")
	@Mapping(target = "status", source = "userAccount.status")
	@Mapping(target = "approvalStatus", source = "userAccount.approvalStatus")
	@Mapping(target = "defaultAccount", source = "userAccount.defaultAccount")
	@Mapping(target = "anyAccount", source = "userAccount.anyAccount")
	@Mapping(target = "statusChangedDate", source = "userAccount.statusChangedDate")
	@Mapping(target = "createdDate", source = "userAccount.createdDate")
	UserAccountsResponse mapToUserAccountsResponse(UserAccountEntity userAccount);

	@Mapping(target = "globalUltimateKey", source = "getAccountsResponse.globalUltimateKey")
	@Mapping(target = "globalUltimateName", source = "getAccountsResponse.globalUltimateName")
	@Mapping(target = "internalCompanyFlag", source = "getAccountsResponse.internalCompanyFlag")
	@Mapping(target = "isDefault", source = "getAccountsResponse.isDefault")
	@Mapping(target = "legalEntityKey", source = "getAccountsResponse.legalEntityKey")
	@Mapping(target = "legalEntityName", source = "getAccountsResponse.legalEntityName")
	@Mapping(target = "createTimestamp", source = "getAccountsResponse.createTimestamp")
	@Mapping(target = "accountStatusUpdateTimestamp", source = "getAccountsResponse.statusUpdateTimestamp")
	@Mapping(target = "accountStatus", source = "getAccountsResponse.status")
	@Mapping(target = "statusUpdateTimestamp", source = "userAccount.statusChangedDate")
	@Mapping(target = "status", source = "userAccount.status")
	@Mapping(target = "createdBy", source = "userAccount.createdBy")
	@Mapping(target = "approvalStatus", source = "userAccount.approvalStatus")
	@Mapping(target = "lastModifiedBy", source = "userAccount.lastModifiedBy")
	UserAccountAssociationsResponse mapToUserAccountAssociationsResponse(GetAccountsResponse getAccountsResponse, UserAccount userAccount);

}