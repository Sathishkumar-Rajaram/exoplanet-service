package com.digitalrealty.gapi.user.exception;

import com.digitalrealty.gapi.common.exceptions.ErrorCode;

public class UserErrorCode {

	public static final ErrorCode SNOW_DOWNSTREAM_ERROR = new ErrorCode("SNOW_DOWNSTREAM_ERROR", "SNOW error. System Error", 500, false);
	public static final ErrorCode NO_PERMISSION = new ErrorCode("NO_PERMISSION", "User does not have permission for this action.", 401, false);
	public static final ErrorCode NO_ACCOUNT_PERMISSION = new ErrorCode("NO_ACCOUNT_PERMISSION", "User does not have access to this account.", 401, false);
	public static final ErrorCode ROLE_ACTIVE = new ErrorCode("ROLE_ACTIVE", "This role is still in use", 409, false);

	public static final ErrorCode ACCOUNT_NOTFOUND = new ErrorCode("ACCOUNT_NOTFOUND", "The requested operation is not permitted for the account.", 401, false);
	public static final ErrorCode USER_NOTFOUND = new ErrorCode("USER_NOTFOUND", "The requested operation is not permitted for the user.", 401, false);
	public static final ErrorCode USER_ACCOUNT_NOTFOUND = new ErrorCode("USER_ACCOUNT_NOTFOUND", "The requested operation is not permitted for the useraccount.", 401, false);
	public static final ErrorCode USER_NOTACTIVE = new ErrorCode("USER_NOTACTIVE", "The logged in user is not active", 401, false);
	public static final ErrorCode USER_EXISTS = new ErrorCode("USER_EXISTS", "The user already exsists.", 400, false);
	public static final ErrorCode STATUS_NOT_ALLOWED = new ErrorCode("STATUS_NOT_ALLOWED", "The requested status is not allowed for this action.", 401, false);

	public static final ErrorCode MISSING_PAYLOAD = new ErrorCode("MISSING_PAYLOAD", "Payload is null or empty.", 400, false);

	public static final ErrorCode MISSING_FIRST_NAME = new ErrorCode("MISSING_FIRST_NAME", "Mandatory payload 'firstName' is null or empty.", 400, false);
	public static final ErrorCode LONG_FIRST_NAME = new ErrorCode("LONG_FIRST_NAME", "Payload 'firstName' has a value that exceeds the maximum amount of '50' characters.", 400, false);

	public static final ErrorCode MISSING_LAST_NAME = new ErrorCode("MISSING_LAST_NAME", "Mandatory payload 'lastName' is null or empty.", 400, false);
	public static final ErrorCode LONG_LAST_NAME = new ErrorCode("LONG_LAST_NAME", "Payload 'lastName' has a value that exceeds the maximum amount of '50' characters.", 400, false);

	public static final ErrorCode MISSING_EMAIL = new ErrorCode("MISSING_EMAIL", "Mandatory payload 'email' is null or empty.", 400, false);
	public static final ErrorCode LONG_EMAIL = new ErrorCode("LONG_EMAIL", "Payload 'email' has a value that exceeds the maximum amount of '100' characters.", 400, false);
	public static final ErrorCode VALID_EMAIL = new ErrorCode("VALID_EMAIL", "Payload 'email' is not an valid email address.", 400, false);

	public static final ErrorCode LONG_PHONE = new ErrorCode("LONG_PHONE", "Payload 'phone' has a value that exceeds the maximum amount of '40' characters.", 400, false);

	public static final ErrorCode ANYACCOUNT_OR_LEGAL = new ErrorCode("ANYACCOUNT_OR_LEGAL", "AnyAccount and/or LegalEntityKey has an invalid value", 400, false);
}
