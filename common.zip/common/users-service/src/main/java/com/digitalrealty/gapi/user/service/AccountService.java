package com.digitalrealty.gapi.user.service;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalrealty.gapi.common.context.ContextHeaders;
import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.digitalrealty.gapi.user.configuration.UserConfig;
import com.digitalrealty.gapi.user.model.payloadmodel.AccountValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.GetAccountsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateLegalEntitiesRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateLegalEntitiesResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountService {

	private final WebClient webClient;

	private final UserConfig userConfig;

	private final RedisCacheService redisCacheService;

	private final JwtConfig jwtConfig;

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public void validateAccount(AccountValidationRequest accountValidationRequest) {
		webClient.post()
				.uri(userConfig.getAccountServiceURL() + "/accounts/" + ContextUtility.getGlobalUltimate() + "/validate")
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(accountValidationRequest), AccountValidationRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.toBodilessEntity()
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public ValidateLegalEntitiesResponse validateLegalEntities(ValidateLegalEntitiesRequest validateLegalEntitiesRequest) {
		return webClient.post()
				.uri(userConfig.getAccountServiceURL() + "/accounts/validate")
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(validateLegalEntitiesRequest), ValidateLegalEntitiesRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(ValidateLegalEntitiesResponse.class)
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public Boolean checkAccountActive(String legalEntityKey) {
		return webClient.get()
				.uri(userConfig.getAccountServiceURL() + "/accounts/" + legalEntityKey + "/status")
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(Boolean.class)
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public String getCompanyName() {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(userConfig.getAccountServiceURL());
		builder.path(MessageFormat.format(userConfig.getAccountServiceCompanyNamePath(), ContextUtility.getLegalEntity()));

		String response = webClient.get()
				.uri(builder.build().toUriString())
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(String.class)
				.block();
		log.debug("Response: {}", response);
		return response;
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public Map<String, String> getAccountNames(List<String> legalEntityKeys) {
		return webClient.post()
				.uri(userConfig.getAccountServiceURL() + "/accounts/names")
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(legalEntityKeys), List.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(new ParameterizedTypeReference<Map<String, String>>() {
				})
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public List<GetAccountsResponse> getAccounts(List<String> legalEntityKeys) {
		return webClient.post()
				.uri(userConfig.getAccountServiceURL() + "/accounts")
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(legalEntityKeys), List.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(new ParameterizedTypeReference<List<GetAccountsResponse>>() {
				})
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public List<String> getLegalEntitiesForGU() {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(userConfig.getAccountServiceURL());
		builder.path(userConfig.getAccountServiceLegalEntitiesPath());

		return webClient.get()
				.uri(builder.build().toUri())
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(new ParameterizedTypeReference<List<String>>() {
				})
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public List<String> getLegalEntitiesForGlobalUltimate() {
		return webClient.get()
				.uri(userConfig.getAccountServiceURL() + "/accounts/legal-entities")
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(new ParameterizedTypeReference<List<String>>() {
				})
				.block();
	}
}
