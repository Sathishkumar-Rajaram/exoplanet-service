package com.digitalrealty.gapi.user.service;

import java.util.List;

import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.context.ContextHeaders;
import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.CommonExceptionUtil;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.digitalrealty.gapi.user.configuration.UserConfig;
import com.digitalrealty.gapi.user.model.payloadmodel.AssetBySitecodeRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.AssetValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.SiteCodeLocationResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
@Slf4j
public class AssetService {

	private final WebClient webClient;

	private final UserConfig userConfig;

	private final RedisCacheService redisCacheService;

	private final JwtConfig jwtConfig;

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public void validateAssets(List<AssetValidationRequest> assetValidationRequest) {
		webClient.post()
				.uri(userConfig.getAssetServiceURL() + "/assets/validate")
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(assetValidationRequest), List.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.toBodilessEntity()
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public List<SiteCodeLocationResponse> getAssetsBySitecodeAndLocationNames(String legalEntityKey, AssetBySitecodeRequest assetBySitecodeRequest) {
		return webClient.post()
				.uri(userConfig.getAssetServiceURL() + "/assets/details")
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.header(ContextHeaders.HEADER_LEGAL_ENTITY, legalEntityKey)
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(assetBySitecodeRequest), AssetBySitecodeRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(new ParameterizedTypeReference<List<SiteCodeLocationResponse>>() {
				})
				.block();
	}
}
