package com.digitalrealty.gapi.user.model.snow;

import java.util.List;

import com.digitalrealty.gapi.user.model.ValidateUserExists;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SNowValidateUserExists {

	private List<ValidateUserExists> result;

}
