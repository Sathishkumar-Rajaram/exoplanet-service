package com.digitalrealty.gapi.user.enums;

public enum UserAccountStatus {
	MANUALLY_SUSPENDED,
	ACTIVE,
	DELETED;
}
