package com.digitalrealty.gapi.user.model;

import java.util.UUID;

public interface IUserAccountAsset extends BaseInterface {

	String getAssetId();

	String getSitePath();

	UUID getUserAccountRoleAssetsId();

}
