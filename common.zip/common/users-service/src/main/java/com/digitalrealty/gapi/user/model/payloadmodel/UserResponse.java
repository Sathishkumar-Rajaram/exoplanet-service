package com.digitalrealty.gapi.user.model.payloadmodel;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserResponse {

	private UUID id;

	private String firstName;

	private String lastName;

	private String email;

	private String phone;

	private UserStatus status;

	private InternalStatus internalStatus;

	private Instant statusChangeDate;

	private List<UserAccountsResponse> userAccounts;

}
