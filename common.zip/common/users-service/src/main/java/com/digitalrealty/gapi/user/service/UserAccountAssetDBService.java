package com.digitalrealty.gapi.user.service;

import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.user.model.IUserAccountAsset;
import com.digitalrealty.gapi.user.repository.UserAccountAssetRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class UserAccountAssetDBService {

	private final UserAccountAssetRepository userAccountAssetRepository;

	public List<IUserAccountAsset> findByUserAccountId(UUID userAccountId) {
		return userAccountAssetRepository.findByUserAccountId(userAccountId);
	}

	public List<IUserAccountAsset> findIdsByUserAccountId(UUID userAccountId) {
		return userAccountAssetRepository.findIdsByUserAccountId(userAccountId.toString());
	}

}
