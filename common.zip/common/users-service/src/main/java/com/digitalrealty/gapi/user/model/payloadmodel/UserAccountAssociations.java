package com.digitalrealty.gapi.user.model.payloadmodel;

import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserAccountAssociations {

	private List<UUID> accountRoleIds;

	private List<String> accountAssetIds;

}
