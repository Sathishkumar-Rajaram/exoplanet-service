package com.digitalrealty.gapi.user.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.NoArgsConstructor;

@Configuration
@ConfigurationProperties(prefix = "auth.snow")
@NoArgsConstructor
@Data
public class SnowAuthConfig {
	private String adminSysId;
}
