package com.digitalrealty.gapi.user.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.NoArgsConstructor;

@Validated
@Configuration
@ConfigurationProperties(prefix = "urls")
@NoArgsConstructor
@Data
public class UserConfig {

	private String permissionServiceURL;

	private String accountServiceURL;

	private String assetServiceURL;

	private String idpServiceURL;

	private String snowServiceURL;

	private String emailServiceURL;

	private String userAndCompanyAssetsPath;

	private String insertValidateUserPath;

	private String updateUserPath;

	private String userSysIdByEmailPath;

	private String accountServiceCompanyNamePath;
	
	private String accountServiceLegalEntitiesPath;
}
