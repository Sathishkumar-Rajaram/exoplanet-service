package com.digitalrealty.gapi.user.model.payloadmodel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ValidateSiteRequest {
	private String assetId;
	private String sitecode;
	private String city;
	private String metro;
	private String country;
	private String region;
}
