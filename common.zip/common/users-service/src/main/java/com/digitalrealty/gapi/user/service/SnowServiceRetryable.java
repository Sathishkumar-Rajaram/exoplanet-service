package com.digitalrealty.gapi.user.service;

import java.text.MessageFormat;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalrealty.gapi.common.auth.service.SnowAuthService;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.user.configuration.UserConfig;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.mapper.UserMapper;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.snow.SNowInsertUser;
import com.digitalrealty.gapi.user.model.snow.SNowInsertUserRequest;
import com.digitalrealty.gapi.user.model.snow.SNowUpdateUser;
import com.digitalrealty.gapi.user.model.snow.SNowUserAndCompanyAssets;
import com.digitalrealty.gapi.user.model.snow.SNowUserSysIdByEmail;
import com.digitalrealty.gapi.user.model.snow.SNowValidateUserExists;
import com.digitalrealty.gapi.user.model.snow.SnowCreateUserRequest;
import com.digitalrealty.gapi.user.model.snow.SnowCreateUserResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Slf4j
@RequiredArgsConstructor
public class SnowServiceRetryable {

	public static final String U_CUSTOMER_REF_1 = "u_customer_ref_1";
	public static final String SYSPARM_DISPLAY_VALUE = "sysparm_display_value";
	public static final String U_ACTIVE = "u_active";
	public static final String U_TYPE = "u_type";
	public static final String SYSPARM_EXCLUDE_REFERENCE_LINK = "sysparm_exclude_reference_link";
	public static final String SCALE = "Scale";
	public static final String U_CMDB_CI_REF_1 = "u_cmdb_ci_ref_1";
	public static final String U_CONTACT_REF_1 = "u_contact_ref_1";
	public static final String U_LOCATION_REF_1 = "u_location_ref_1";
	public static final String SYSPARM_FIELDS = "sysparm_fields";
	public static final String USER_NAME = "user_name";

	private final UserMapper userMapper;

	private final WebClient webClient;

	private final UserConfig userConfig;

	private final SnowAuthService snowAuthService;

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public void createSnowUser(User user) {
		log.debug("Calling create user for Snow");
		SnowCreateUserRequest request = userMapper.mapUserToSnowCreateUserRequest(user);

		String snowUrl = userConfig.getSnowServiceURL() + "/api/drto/v1/users/addNewUser";
		webClient.post()
				.uri(snowUrl.trim())
				.header("Authorization", "Bearer " + snowAuthService.getAccessToken())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(request), SnowCreateUserRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(UserErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(SnowCreateUserResponse.class)
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public void updateSnowUser(User user) {
		log.debug("Calling update user for Snow");
		SnowCreateUserRequest request = userMapper.mapUserToSnowCreateUserRequest(user);
		webClient.post()
				.uri(uriBuilder -> uriBuilder.queryParam("id", request.getId())
						.path(userConfig.getSnowServiceURL() + "/api/drto/updateuser")
						.build())
				.header("Authorization", "Bearer " + snowAuthService.getAccessToken())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(request), SnowCreateUserRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(UserErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(SnowCreateUserResponse.class)
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public void deleteSnowUser(User user) {
		log.debug("Calling delete user for Snow");
		webClient.delete()
				.uri(uriBuilder -> uriBuilder.queryParam("id", user.getId())
						.path(userConfig.getSnowServiceURL() + "/api/drto/updateuser/removeportalaccount")
						.build())
				.header("Authorization", "Bearer " + snowAuthService.getAccessToken())
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(UserErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(Void.class)
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public SNowUserAndCompanyAssets getUserAndCompanyAssets(String companyName) {
		log.debug("Entering getUserAndCompanyAssets.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(userConfig.getSnowServiceURL());
		builder.path(userConfig.getUserAndCompanyAssetsPath());
		builder.queryParam(U_CUSTOMER_REF_1, companyName);
		builder.queryParam(SYSPARM_DISPLAY_VALUE, true);
		builder.queryParam(U_ACTIVE, true);
		builder.queryParam(U_TYPE, SCALE);
		builder.queryParam(SYSPARM_EXCLUDE_REFERENCE_LINK, false);
		log.debug("getUserAndCompanyAssets URL: {}", builder.build().toUriString());

		SNowUserAndCompanyAssets sNowUserAndCompanyAssets = webClient.get()
				.uri(builder.build().toUriString())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(UserErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(SNowUserAndCompanyAssets.class)
				.block();

		log.debug("Response: {}", sNowUserAndCompanyAssets);
		return sNowUserAndCompanyAssets;
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public SNowInsertUser insertUser(SNowInsertUserRequest sNowInsertUserRequest) {
		log.debug("Entering insertUser.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(userConfig.getSnowServiceURL());
		builder.path(userConfig.getInsertValidateUserPath());
		builder.queryParam(SYSPARM_FIELDS, "sys_id");
		log.debug("insertUser URL: {}", builder.build().toUriString());

		SNowInsertUser response = webClient.post()
				.uri(builder.build().toUriString())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.body(BodyInserters.fromValue(sNowInsertUserRequest))
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(UserErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(SNowInsertUser.class)
				.block();

		log.debug("Response: {}", response);
		return response;
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public SNowInsertUser updateUser(String sysId, SNowUpdateUser sNowUpdateUser) {
		log.debug("Entering updateUser.");
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(userConfig.getSnowServiceURL());
		builder.path(MessageFormat.format(userConfig.getUpdateUserPath(), sysId));
		builder.queryParam(SYSPARM_EXCLUDE_REFERENCE_LINK, false);
		builder.queryParam(SYSPARM_DISPLAY_VALUE, true);
		log.debug("updateUser URL: {}", builder.build().toUriString());

		SNowInsertUser response = webClient.patch()
				.uri(builder.build().toUriString())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.body(BodyInserters.fromValue(sNowUpdateUser))
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(UserErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(SNowInsertUser.class)
				.block();

		log.debug("Response: {}", response);
		return response;
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public SNowValidateUserExists validateUserExists(String uCustomerRef, String uCmdbCiRef, String uContactRef, String uLocationRef) {
		log.debug("Entering validateUserExists.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(userConfig.getSnowServiceURL());
		builder.path(userConfig.getInsertValidateUserPath());
		builder.queryParam(U_CUSTOMER_REF_1, uCustomerRef);
		builder.queryParam(U_CMDB_CI_REF_1, uCmdbCiRef);
		builder.queryParam(U_CONTACT_REF_1, uContactRef);
		builder.queryParam(U_LOCATION_REF_1, uLocationRef);
		builder.queryParam(SYSPARM_DISPLAY_VALUE, true);
		builder.queryParam(SYSPARM_EXCLUDE_REFERENCE_LINK, true);
		log.debug("validateUserExists URL: {}", builder.build().toUriString());

		SNowValidateUserExists response = webClient.get()
				.uri(builder.build().toUriString())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(SNowValidateUserExists.class)
				.block();

		log.debug("Response: {}", response);
		return response;
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public SNowUserSysIdByEmail getUserSysIdByEmail(String email) {
		log.debug("Entering getUserSysIdByEmail.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(userConfig.getSnowServiceURL());
		builder.path(userConfig.getUserSysIdByEmailPath());
		builder.queryParam(SYSPARM_DISPLAY_VALUE, true);
		builder.queryParam(USER_NAME, email);
		builder.queryParam(SYSPARM_EXCLUDE_REFERENCE_LINK, true);
		log.debug("getUserSysIdByEmail URL: {}", builder.build().toUriString());

		SNowUserSysIdByEmail response = webClient.get()
				.uri(builder.build().toUriString())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(UserErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(SNowUserSysIdByEmail.class)
				.block();

		log.debug("Response: {}", response);
		return response;
	}

}