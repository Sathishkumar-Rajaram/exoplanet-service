package com.digitalrealty.gapi.user.mapper;

import java.util.Collections;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.mapstruct.Named;
import org.springframework.stereotype.Component;

import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.entity.UserAccountRoleAssetsEntity;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.repository.UserAccountRepository;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class MappingUtil {

	private final UserAccountMapper userAccountMapper;

	private final UserAccountRepository userAccountRepository;

	@Named("getUserAccountsEntity")
	public Set<UserAccountEntity> getUserAccountsEntity(User user) {
		if (ObjectUtils.isNotEmpty(user.getUserAccounts())) {
			return user.getUserAccounts().stream().map(userAccount -> userAccountMapper.map(userAccount)).collect(Collectors.toSet());
		}
		return Collections.<UserAccountEntity>emptySet();
	}

	@Named("getUserAccounts")
	public Set<UserAccount> getUserAccounts(UserEntity user) {
		if (ObjectUtils.isNotEmpty(user.getUserAccounts())) {
			return user.getUserAccounts().stream().map(userAccount -> userAccountMapper.map(userAccount)).collect(Collectors.toSet());
		}
		return Collections.<UserAccount>emptySet();
	}

	@Named("getUserAccountRoleAssetById")
	public UserAccountRoleAssetsEntity getUserAccountRoleAssetById(UUID userAccountRoleAssetsId) {
		return userAccountRepository.findRoleAssetsByRoleAssetsId(userAccountRoleAssetsId.toString());
	}

}