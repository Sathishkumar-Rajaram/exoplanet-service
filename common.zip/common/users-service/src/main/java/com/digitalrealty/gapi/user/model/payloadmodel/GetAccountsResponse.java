package com.digitalrealty.gapi.user.model.payloadmodel;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GetAccountsResponse {

	String globalUltimateKey;

	String globalUltimateName;

	Boolean internalCompanyFlag;

	Boolean isDefault;

	String legalEntityKey;

	String legalEntityName;

	Instant createTimestamp;

	Instant statusUpdateTimestamp;

	String status;

}
