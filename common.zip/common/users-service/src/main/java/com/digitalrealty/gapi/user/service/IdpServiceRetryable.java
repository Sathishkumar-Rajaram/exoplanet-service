package com.digitalrealty.gapi.user.service;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.auth.service.IdpAuthService;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.user.configuration.UserConfig;
import com.digitalrealty.gapi.user.mapper.UserMapper;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.payloadmodel.IdpCreateUserRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.IdpCreateUserResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Slf4j
@RequiredArgsConstructor
public class IdpServiceRetryable {

	private final UserMapper userMapper;

	private final WebClient webClient;

	private final UserConfig userConfig;

	private final IdpAuthService idpAuthService;

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public void createIdpUser(User user) {
		log.trace("Calling create user for idp");
		IdpCreateUserRequest request = userMapper.mapUserToIdpCreateUserRequest(user);
		webClient.post()
				.uri(userConfig.getIdpServiceURL() + "/Users")
				.header("Authorization", "Bearer " + idpAuthService.getAccessToken())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(request), IdpCreateUserRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(IdpCreateUserResponse.class)
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public void updateIdpUser(User user) {
		log.trace("Calling update user for idp");
		IdpCreateUserRequest request = userMapper.mapUserToIdpCreateUserRequest(user);
		webClient.put()
				.uri(userConfig.getIdpServiceURL() + "/Users/" + user.getId())
				.header("Authorization", "Bearer " + idpAuthService.getAccessToken())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(request), IdpCreateUserRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(IdpCreateUserResponse.class)
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public void deleteIdpUser(User user) {
		log.trace("Calling delete user for idp");
		webClient.delete().uri(userConfig.getIdpServiceURL() + "/Users/" + user.getEmail())
				.header("Authorization", "Bearer " + idpAuthService.getAccessToken())
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(Void.class)
				.block();
	}

}
