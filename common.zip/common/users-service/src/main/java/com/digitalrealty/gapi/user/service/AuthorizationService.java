package com.digitalrealty.gapi.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.user.configuration.NoPermissionConfig;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.mapper.ActionMapper;
import com.digitalrealty.gapi.user.model.IUserAccountRole;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.payloadmodel.AccountValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.AssetModel;
import com.digitalrealty.gapi.user.model.payloadmodel.RoleCheckPermissionsRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociations;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthorizationService {

	private final ActionMapper actionMapper;

	private final UserAccountDBService userAccountDBService;

	private final UserAccountRoleDBService userAccountRoleDBService;

	private final UserDBService userDBService;

	private final SuperUserDBService superUserDBService;

	private final EncryptionService encryptionService;

	private final PermissionsService permissionService;

	private final AccountService accountService;
	private final NoPermissionConfig permissionConfig;

	public ActionValidationResponse isAuthorized(ActionValidationRequest actionValidationRequest) {

		accountService.validateAccount(AccountValidationRequest.builder().legalEntityKeys(Stream.of(ContextUtility.getLegalEntity()).collect(Collectors.toList())).build());
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());

		User user = userDBService.findByEmail(encryptedEmail);
		String superUser = superUserDBService.findByEmail(encryptedEmail);

		if (Objects.isNull(user) && StringUtils.isBlank(superUser)) {
			throw new CommonException(UserErrorCode.USER_NOTFOUND);
		}
		if (!StringUtils.isBlank(superUser)) {
			return ActionValidationResponse.builder().isSuper(true).build();
		}

		List<UserAccount> accounts = userAccountDBService.findByUserId(user.getId());
		List<UserAccount> userAccount = accounts.stream().filter(uAcc -> uAcc.getLegalEntityKey().equals(ContextUtility.getLegalEntity()) || uAcc.getAnyAccount()).collect(Collectors.toList());
		if (userAccount.isEmpty()) {
			throw new CommonException(UserErrorCode.ACCOUNT_NOTFOUND);
		}

		userAccount = userAccount.stream().map(loggedUserAccount -> {
			if (loggedUserAccount.getLegalEntityKey().equals(ContextUtility.getLegalEntity())) {
				Boolean isAccountActive = accountService.checkAccountActive(loggedUserAccount.getLegalEntityKey());

				if (isAccountActive != null) {
					if (isAccountActive && loggedUserAccount.getStatus() != UserAccountStatus.ACTIVE) {
						loggedUserAccount.setStatus(UserAccountStatus.ACTIVE);
						loggedUserAccount = userAccountDBService.saveAccount(loggedUserAccount);

						if (user.getStatus() == UserStatus.NOTACTIVE) {
							user.setStatus(UserStatus.ACTIVE);
							userDBService.saveUser(user);
						}
					} else if (!isAccountActive && loggedUserAccount.getStatus() == UserAccountStatus.ACTIVE) {
						loggedUserAccount.setStatus(UserAccountStatus.DELETED);
						loggedUserAccount = userAccountDBService.saveAccount(loggedUserAccount);
					}
				}
			}
			return loggedUserAccount;
		}).filter(loggedUserAccount -> loggedUserAccount.getStatus() == UserAccountStatus.ACTIVE).collect(Collectors.toList());

		if (user.getStatus() == UserStatus.NOTACTIVE) {
			throw new CommonException(UserErrorCode.USER_NOTACTIVE);
		}

		List<String> userLoggedAccounts = userAccount.stream().filter(userAcc -> !userAcc.getAnyAccount()).map(UserAccount::getLegalEntityKey).collect(Collectors.toList());
		if (accounts.stream().filter(userAcc -> (!userLoggedAccounts.isEmpty() && userLoggedAccounts.contains(userAcc.getLegalEntityKey())) || userAcc.getStatus() == UserAccountStatus.ACTIVE).findAny().isEmpty()) {
			user.setStatus(UserStatus.NOTACTIVE);
			userDBService.saveUser(user);

			throw new CommonException(UserErrorCode.USER_NOTACTIVE);
		}

		List<UUID> accountRoleIds = new ArrayList<UUID>();
		List<String> accountAssetIds = new ArrayList<String>();

		if (Objects.isNull(actionValidationRequest.getAssetIds()) || actionValidationRequest.getAssetIds().isEmpty()) {
			userAccount.forEach(userAcc -> {
				accountRoleIds.addAll(userAccountRoleDBService.findByUserAccountId(userAcc.getId()).stream().map(IUserAccountRole::getRoleId).collect(Collectors.toList()));
			});
		} else {
			List<String> assets = actionValidationRequest.getAssetIds().stream().filter(asset -> !StringUtils.isEmpty(asset.getAssetId())).map(AssetModel::getAssetId).collect(Collectors.toList());
			userAccount.forEach(userAcc -> {
				accountRoleIds.addAll(userAccountRoleDBService.findByAssetIdIn(userAcc.getId(), assets).stream().map(IUserAccountRole::getRoleId).collect(Collectors.toList()));
			});
			accountAssetIds = assets;
		}

		String method = actionValidationRequest.getMethod();
		if (Objects.isNull(method)) {
			method = ContextUtility.getMethod();
		}

		UserAccountAssociations associations = new UserAccountAssociations(accountRoleIds, accountAssetIds);
		boolean noPermissionActionExists = actionValidationRequest.getActions().stream().anyMatch(action -> action.equals(permissionConfig.getName()));
		if (noPermissionActionExists) {
			return actionMapper.mapUserToActionValidationResponse(false, user.getId(), associations);
		}

		permissionService.isAuthorized(RoleCheckPermissionsRequest.builder().method(method).action(actionValidationRequest.getActions()).associations(associations).build());
		return actionMapper.mapUserToActionValidationResponse(false, user.getId(), associations);
	}

}
