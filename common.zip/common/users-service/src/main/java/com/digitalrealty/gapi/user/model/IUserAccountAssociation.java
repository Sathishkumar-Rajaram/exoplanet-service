package com.digitalrealty.gapi.user.model;

import java.util.UUID;

public interface IUserAccountAssociation extends BaseInterface {

	UUID getRoleId();

	String getAssetId();

	String getAccountId();
}
