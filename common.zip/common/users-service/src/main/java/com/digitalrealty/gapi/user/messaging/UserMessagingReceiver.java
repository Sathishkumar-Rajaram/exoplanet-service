package com.digitalrealty.gapi.user.messaging;

import java.util.List;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.messaging.BaseReceiver;
import com.digitalrealty.gapi.messaging.user.MaintainUserMessage;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.service.UserDBService;
import com.digitalrealty.gapi.user.service.UserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@RequiredArgsConstructor
public class UserMessagingReceiver extends BaseReceiver {

	private final UserService userService;

	private final UserDBService userDBService;

	@JmsListener(destination = "${messaging.maintainUserQueue}", containerFactory = "jmsListenerContainerFactory")
	public void receiveMessage(MaintainUserMessage maintainUserMessage) {
		try {
			log.debug("ReceiveMessage: MaintainUserMessage");
			initializeContext(maintainUserMessage);

			userDBService.updateExecutionId(maintainUserMessage.getUserId().toString(), 1);

			List<User> syncUsers = userDBService.findByExecutionId(maintainUserMessage.getUserId().toString());
			userService.updateExternalSystems(syncUsers);
		} catch (CommonException e) {
			log.error("Update external systems internal status has failed", e);
		} catch (Exception e) {
			log.error("Update execution id on internal status has failed", new CommonException(ErrorCode.SYSTEM, e));
		} finally {
			try {
				userDBService.updateExecutionIdAsNull(maintainUserMessage.getUserId().toString());
			} catch (CommonException e) {
				log.error("Update execution id as null has failed", e);
			} catch (Exception e) {
				log.error("Update execution id as null has failed", new CommonException(ErrorCode.SYSTEM, e));
			}
		}
	}
}