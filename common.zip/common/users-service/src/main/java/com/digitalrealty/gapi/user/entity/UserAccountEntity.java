package com.digitalrealty.gapi.user.entity;

import java.time.Instant;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true, exclude = { "userAccountRoleAssets", "user" })
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Audited
@Table(name = "user_account")
public class UserAccountEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	private String legalEntityKey;

	@Type(type = "uuid-char")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	private UserEntity user;

	@Enumerated(EnumType.STRING)
	private UserAccountStatus status;

	@Enumerated(EnumType.STRING)
	private ApprovalStatus approvalStatus;

	private Boolean defaultAccount;

	private Boolean anyAccount;

	private Instant statusChangedDate;

	@OneToMany(mappedBy = "userAccount", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Set<UserAccountRoleAssetsEntity> userAccountRoleAssets;

}
