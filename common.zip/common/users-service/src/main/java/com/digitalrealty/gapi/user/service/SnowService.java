package com.digitalrealty.gapi.user.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.auth.service.SnowAuthService;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.CommonExceptionUtil;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.user.configuration.SnowAuthConfig;
import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.payloadmodel.ApproverValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ApproverValidationResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.AssetBySitecodeRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.SiteCodeLocationResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.SitecodeLocationRequest;
import com.digitalrealty.gapi.user.model.snow.SNowInsertUser;
import com.digitalrealty.gapi.user.model.snow.SNowInsertUserRequest;
import com.digitalrealty.gapi.user.model.snow.SNowUpdateUser;
import com.digitalrealty.gapi.user.model.snow.SNowUserAndCompanyAssets;
import com.digitalrealty.gapi.user.model.snow.SNowUserSysIdByEmail;
import com.digitalrealty.gapi.user.model.snow.UCmdbCiRef1;
import com.digitalrealty.gapi.user.model.snow.UCustomerRef1;
import com.digitalrealty.gapi.user.model.snow.USiteCodeRef1;
import com.digitalrealty.gapi.user.util.AssetUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class SnowService {

	public static final String UNAUTHORIZED = "401";

	private final AssetService assetService;

	private final UserDBService userDBService;

	private final SnowAuthService snowAuthService;

	private final SnowServiceRetryable snowServiceRetryable;

	private final AccountService accountService;

	private final PermissionsService permissionsService;

	private final SnowAuthConfig snowAuthConfig;

	public List<User> syncUsersToSnow(List<User> initiatedUsers) {
		log.debug("Synchronizing Users to Snow");

		List<User> syncedUsers = new ArrayList<>();
		List<User> createList = initiatedUsers.stream().filter(user -> (user.getStatus() == UserStatus.CREATED)).collect(Collectors.toList());
		List<User> updateList = initiatedUsers.stream().filter(user -> (user.getStatus() == UserStatus.ACTIVE)).collect(Collectors.toList());
		List<User> deleteList = initiatedUsers.stream().filter(user -> (user.getStatus() == UserStatus.NOTACTIVE)).collect(Collectors.toList());

		List<CommonException> commonExceptions = new ArrayList<CommonException>();
		createList.forEach(user -> {
			try {
				try {
					snowServiceRetryable.createSnowUser(user);
				} catch (Exception exception) {
					if ((exception.getMessage() == null) || !exception.getMessage().contains(UNAUTHORIZED)) {
						commonExceptions.add(new CommonException(ErrorCode.DOWNSTREAM_SYSTEM, exception));
					}
					snowAuthService.getAccessToken(true);
					snowServiceRetryable.createSnowUser(user);
				}

				user.setInternalStatus(InternalStatus.NEED_ASSIGNMENT_SYNC);
				syncedUsers.add(user);
			} catch (Exception ex) {
				commonExceptions.add(CommonExceptionUtil.convertExceptionToCommonException(ex, null));
			}
		});

		deleteList.forEach(user -> {
			try {
				try {
					snowServiceRetryable.deleteSnowUser(user);
				} catch (Exception exception) {
					if ((exception.getMessage() == null) || !exception.getMessage().contains(UNAUTHORIZED)) {
						commonExceptions.add(new CommonException(ErrorCode.DOWNSTREAM_SYSTEM, exception));
					}
					snowAuthService.getAccessToken(true);
					snowServiceRetryable.deleteSnowUser(user);
				}

				user.setInternalStatus(InternalStatus.NEED_ASSIGNMENT_SYNC);
				syncedUsers.add(user);
			} catch (Exception ex) {
				commonExceptions.add(CommonExceptionUtil.convertExceptionToCommonException(ex, null));
			}
		});

		updateList.forEach(user -> {
			try {
				try {
					snowServiceRetryable.updateSnowUser(user);
				} catch (Exception exception) {
					if ((exception.getMessage() == null) || !exception.getMessage().contains(UNAUTHORIZED)) {
						commonExceptions.add(new CommonException(ErrorCode.DOWNSTREAM_SYSTEM, exception));
					}
					snowAuthService.getAccessToken(true);
					snowServiceRetryable.updateSnowUser(user);
				}

				user.setInternalStatus(InternalStatus.NEED_ASSIGNMENT_SYNC);
				syncedUsers.add(user);
			} catch (Exception ex) {
				commonExceptions.add(CommonExceptionUtil.convertExceptionToCommonException(ex, null));
			}
		});

		List<User> savedUsers = userDBService.saveUsers(syncedUsers);

		if (!commonExceptions.isEmpty()) {
			throw CommonException.fromList(commonExceptions);
		}

		log.debug("Synchronized Users to Snow");
		return savedUsers;
	}

	public List<User> syncUsersAssetsAndRoles(List<User> userList) {
		log.debug("Entering syncUsersAssetsAndRoles");

		List<User> syncUsersAssetsAndRoles = new ArrayList<>();

		List<User> createList = userList.stream().filter(user -> (user.getStatus() == UserStatus.CREATED)).collect(Collectors.toList());
		List<User> updateList = userList.stream().filter(user -> (user.getStatus() == UserStatus.ACTIVE)).collect(Collectors.toList());
		List<User> deleteList = userList.stream().filter(user -> (user.getStatus() == UserStatus.NOTACTIVE)).collect(Collectors.toList());

		List<CommonException> commonExceptions = new ArrayList<CommonException>();

		createList.forEach(user -> {
			try {
				syncUsersAssetsAndRoles.add(processCreated(user));
			} catch (Exception ex) {
				commonExceptions.add(CommonExceptionUtil.convertExceptionToCommonException(ex, null));
			}
		});

		updateList.forEach(user -> {
			try {
				syncUsersAssetsAndRoles.add(processUpdated(user));
			} catch (Exception ex) {
				commonExceptions.add(CommonExceptionUtil.convertExceptionToCommonException(ex, null));
			}
		});

		deleteList.forEach(user -> {
			try {
				syncUsersAssetsAndRoles.add(processDeleted(user));
			} catch (Exception ex) {
				commonExceptions.add(CommonExceptionUtil.convertExceptionToCommonException(ex, null));
			}
		});

		List<User> savedUsers = userDBService.saveUsers(syncUsersAssetsAndRoles);

		if (!commonExceptions.isEmpty()) {
			throw CommonException.fromList(commonExceptions);
		}

		log.debug("Synchronized user assets to Snow");
		return savedUsers;
	}

	private User processCreated(User user) {
		SNowUserSysIdByEmail sysIdByEmail = getUserSysIdByEmail(user.getEmail());
		String userSysId = sysIdByEmail != null && CollectionUtils.isNotEmpty(sysIdByEmail.getResult()) ? sysIdByEmail.getResult().get(0).getSys_id() : StringUtils.EMPTY;

		Map<UUID, List<UUID>> userAccountRoles = new HashMap<>();
		List<String> legalEntityKeys = new ArrayList<>();
		List<String> assetIds = new ArrayList<>();
		List<String> sitePaths = new ArrayList<>();

		user.getUserAccounts().stream().filter(userAccount -> BooleanUtils.isFalse(userAccount.getAnyAccount())).forEach(userAccount -> {
			List<UUID> roleList = new ArrayList<>();

			userAccount.getAssociations().stream().forEach(userAccountAssociation -> {
				roleList.add(userAccountAssociation.getUserAccountRole().getRoleId());

				userAccountAssociation.getUserAccountAssets().stream().forEach(userAccountAsset -> {
					if (!StringUtils.isEmpty(userAccountAsset.getAssetId())) {
						assetIds.add(userAccountAsset.getAssetId());
					}

					if (!StringUtils.isEmpty(userAccountAsset.getSitePath())) {
						sitePaths.add(userAccountAsset.getSitePath());
					}
				});
			});

			userAccountRoles.put(userAccount.getId(), roleList);
			legalEntityKeys.add(userAccount.getLegalEntityKey());
		});

		ApproverValidationResponse approverValidationResponse = permissionsService.validateApprovers(ApproverValidationRequest.builder().userAccountRoles(userAccountRoles).build());
		Map<String, String> accountNames = accountService.getAccountNames(legalEntityKeys);

		user.getUserAccounts().stream().filter(userAccount -> BooleanUtils.isFalse(userAccount.getAnyAccount())).forEach(userAccount -> {

			SNowUserAndCompanyAssets sNowUserAndCompanyAssets = getUserAndCompanyAssets(accountNames.get(userAccount.getLegalEntityKey()));

			sNowUserAndCompanyAssets.getResult().forEach(userAsset -> {

				UCustomerRef1 uCustomerRef1 = userAsset.getU_customer_ref_1();
				UCmdbCiRef1 uCmdbCiRef1 = userAsset.getU_cmdb_ci_ref_1();
				USiteCodeRef1 uSiteCodeRef1 = userAsset.getU_site_code_ref_1();

				String locationCode = uCmdbCiRef1 != null ? uCmdbCiRef1.getLink().substring(uCmdbCiRef1.getLink().lastIndexOf("/") + 1) : StringUtils.EMPTY;
				String siteCode = uSiteCodeRef1 != null ? uSiteCodeRef1.getLink().substring(uSiteCodeRef1.getLink().lastIndexOf("/") + 1) : StringUtils.EMPTY;

				if (assetIds.contains(userAsset.getSys_id())) {
					insertAssetUser(SNowInsertUserRequest.builder()
							.u_customer_ref_1(uCustomerRef1 != null ? uCustomerRef1.getLink().substring(uCustomerRef1.getLink().lastIndexOf("/") + 1) : StringUtils.EMPTY)
							.u_contact_ref_1(userSysId)
							.u_cmdb_ci_ref_1(locationCode)
							.u_location_ref_1(siteCode)
							.u_last_contact_to_update(snowAuthConfig.getAdminSysId())
							.u_approve_additional_charges(String.valueOf(approverValidationResponse.getAdditionalChargesIds().contains(userAccount.getId())))
							.u_access_area_visitor(String.valueOf(approverValidationResponse.getVisitorApproverIds().contains(userAccount.getId())))
							.u_access_area_owner(String.valueOf(approverValidationResponse.getBadgeApproverIds().contains(userAccount.getId())))
							.u_operations_contact("true")
							.build());
				} else {

					String locationName = uCmdbCiRef1 != null ? uCmdbCiRef1.getDisplay_value().substring(uCmdbCiRef1.getLink().lastIndexOf("/") + 1) : StringUtils.EMPTY;
					String siteName = uSiteCodeRef1 != null ? uSiteCodeRef1.getDisplay_value().substring(uSiteCodeRef1.getLink().lastIndexOf("/") + 1) : StringUtils.EMPTY;

					AssetBySitecodeRequest assetBySitecodeRequest = new AssetBySitecodeRequest();
					assetBySitecodeRequest.getSitecodeLocationRequests().add(SitecodeLocationRequest.builder().sitecode(siteName).location(locationName).build());
					List<SiteCodeLocationResponse> assetsPaths = assetService.getAssetsBySitecodeAndLocationNames(userAccount.getLegalEntityKey(), assetBySitecodeRequest);

					Optional<String> assetPath = sitePaths.stream().filter(path -> {
						HashMap<String, String> assetPaths = AssetUtil.parseAssetPath(path);

						if (assetPaths.containsKey(AssetUtil.CITY)) {
							return (locationCode.equals(assetPaths.get(AssetUtil.CITY)) || assetsPaths.stream().anyMatch(asset -> asset.getCity().equals(locationCode)));

						}
						if (assetPaths.containsKey(AssetUtil.METRO)) {
							return (locationCode.equals(assetPaths.get(AssetUtil.METRO)) || assetsPaths.stream().anyMatch(asset -> asset.getMetro().equals(locationCode)));

						} else if (assetPaths.containsKey(AssetUtil.COUNTRY)) {
							return (locationCode.equals(assetPaths.get(AssetUtil.COUNTRY)) || assetsPaths.stream().anyMatch(asset -> asset.getCountry().equals(locationCode)));

						} else if (assetPaths.containsKey(AssetUtil.REGION)) {
							return (locationCode.equals(assetPaths.get(AssetUtil.REGION)) || assetsPaths.stream().anyMatch(asset -> asset.getRegion().equals(locationCode)));

						} else {
							return false;
						}
					}).findFirst();

					if (!assetPath.isEmpty()) {
						insertAssetUser(SNowInsertUserRequest.builder()
								.u_customer_ref_1(uCustomerRef1 != null ? uCustomerRef1.getLink().substring(uCustomerRef1.getLink().lastIndexOf("/") + 1) : StringUtils.EMPTY)
								.u_contact_ref_1(userSysId)
								.u_cmdb_ci_ref_1(locationCode)
								.u_location_ref_1(siteCode)
								.u_last_contact_to_update(snowAuthConfig.getAdminSysId())
								.u_approve_additional_charges(String.valueOf(approverValidationResponse.getAdditionalChargesIds().contains(userAccount.getId())))
								.u_access_area_visitor(String.valueOf(approverValidationResponse.getVisitorApproverIds().contains(userAccount.getId())))
								.u_access_area_owner(String.valueOf(approverValidationResponse.getBadgeApproverIds().contains(userAccount.getId())))
								.u_operations_contact("true")
								.build());
					} else {
						updateAssetUser(userAsset.getSys_id(), SNowUpdateUser.builder()
								.u_last_contact_to_update(snowAuthConfig.getAdminSysId())
								.u_approve_additional_charges("false")
								.u_access_area_visitor("false")
								.u_access_area_owner("false")
								.u_operations_contact("false")
								.build());
					}
				}
			});
		});

		user.setInternalStatus(InternalStatus.SNOW_SYNCED);
		return user;
	}

	private User processUpdated(User user) {
		Map<UUID, List<UUID>> userAccountRoles = new HashMap<>();
		List<String> legalEntityKeys = new ArrayList<>();
		List<String> assetIds = new ArrayList<>();
		List<String> sitePaths = new ArrayList<>();

		user.getUserAccounts().stream().filter(userAccount -> BooleanUtils.isFalse(userAccount.getAnyAccount())).forEach(userAccount -> {
			List<UUID> roleList = new ArrayList<>();

			userAccount.getAssociations().stream().forEach(userAccountAssociation -> {
				roleList.add(userAccountAssociation.getUserAccountRole().getRoleId());

				userAccountAssociation.getUserAccountAssets().stream().forEach(userAccountAsset -> {
					if (!StringUtils.isEmpty(userAccountAsset.getAssetId())) {
						assetIds.add(userAccountAsset.getAssetId());
					}

					if (!StringUtils.isEmpty(userAccountAsset.getSitePath())) {
						sitePaths.add(userAccountAsset.getSitePath());
					}
				});
			});

			userAccountRoles.put(userAccount.getId(), roleList);
			legalEntityKeys.add(userAccount.getLegalEntityKey());
		});

		ApproverValidationResponse approverValidationResponse = permissionsService.validateApprovers(ApproverValidationRequest.builder().userAccountRoles(userAccountRoles).build());
		Map<String, String> accountNames = accountService.getAccountNames(legalEntityKeys);

		user.getUserAccounts().stream().filter(userAccount -> BooleanUtils.isFalse(userAccount.getAnyAccount())).forEach(userAccount -> {
			SNowUserAndCompanyAssets sNowUserAndCompanyAssets = getUserAndCompanyAssets(accountNames.get(userAccount.getLegalEntityKey()));

			sNowUserAndCompanyAssets.getResult().forEach(userAsset -> {
				userAsset.getU_customer_ref_1();
				UCmdbCiRef1 uCmdbCiRef1 = userAsset.getU_cmdb_ci_ref_1();
				USiteCodeRef1 uSiteCodeRef1 = userAsset.getU_site_code_ref_1();

				String locationCode = uCmdbCiRef1 != null ? uCmdbCiRef1.getLink().substring(uCmdbCiRef1.getLink().lastIndexOf("/") + 1) : StringUtils.EMPTY;

				if (assetIds.contains(userAsset.getSys_id())) {
					updateAssetUser(userAsset.getSys_id(), SNowUpdateUser.builder()
							.u_last_contact_to_update(snowAuthConfig.getAdminSysId())
							.u_approve_additional_charges(String.valueOf(approverValidationResponse.getAdditionalChargesIds().contains(userAccount.getId())))
							.u_access_area_visitor(String.valueOf(approverValidationResponse.getVisitorApproverIds().contains(userAccount.getId())))
							.u_access_area_owner(String.valueOf(approverValidationResponse.getBadgeApproverIds().contains(userAccount.getId())))
							.u_operations_contact("true")
							.build());
				} else {
					String locationName = uCmdbCiRef1 != null ? uCmdbCiRef1.getDisplay_value().substring(uCmdbCiRef1.getLink().lastIndexOf("/") + 1) : StringUtils.EMPTY;
					String siteName = uSiteCodeRef1 != null ? uSiteCodeRef1.getDisplay_value().substring(uSiteCodeRef1.getLink().lastIndexOf("/") + 1) : StringUtils.EMPTY;

					AssetBySitecodeRequest assetBySitecodeRequest = new AssetBySitecodeRequest();
					assetBySitecodeRequest.getSitecodeLocationRequests().add(SitecodeLocationRequest.builder().sitecode(siteName).location(locationName).build());
					List<SiteCodeLocationResponse> assetsPaths = assetService.getAssetsBySitecodeAndLocationNames(userAccount.getLegalEntityKey(), assetBySitecodeRequest);

					Optional<String> assetPath = sitePaths.stream().filter(path -> {
						HashMap<String, String> assetPaths = AssetUtil.parseAssetPath(path);

						if (assetPaths.containsKey(AssetUtil.CITY)) {
							return (locationCode.equals(assetPaths.get(AssetUtil.CITY)) || assetsPaths.stream().anyMatch(asset -> asset.getCity().equals(locationCode)));

						}
						if (assetPaths.containsKey(AssetUtil.METRO)) {
							return (locationCode.equals(assetPaths.get(AssetUtil.METRO)) || assetsPaths.stream().anyMatch(asset -> asset.getMetro().equals(locationCode)));

						} else if (assetPaths.containsKey(AssetUtil.COUNTRY)) {
							return (locationCode.equals(assetPaths.get(AssetUtil.COUNTRY)) || assetsPaths.stream().anyMatch(asset -> asset.getCountry().equals(locationCode)));

						} else if (assetPaths.containsKey(AssetUtil.REGION)) {
							return (locationCode.equals(assetPaths.get(AssetUtil.REGION)) || assetsPaths.stream().anyMatch(asset -> asset.getRegion().equals(locationCode)));

						} else {
							return false;
						}
					}).findFirst();

					if (!assetPath.isEmpty()) {
						updateAssetUser(userAsset.getSys_id(), SNowUpdateUser.builder()
								.u_last_contact_to_update(snowAuthConfig.getAdminSysId())
								.u_approve_additional_charges(String.valueOf(approverValidationResponse.getAdditionalChargesIds().contains(userAccount.getId())))
								.u_access_area_visitor(String.valueOf(approverValidationResponse.getVisitorApproverIds().contains(userAccount.getId())))
								.u_access_area_owner(String.valueOf(approverValidationResponse.getBadgeApproverIds().contains(userAccount.getId())))
								.u_operations_contact("true")
								.build());
					} else {
						updateAssetUser(userAsset.getSys_id(), SNowUpdateUser.builder()
								.u_last_contact_to_update(snowAuthConfig.getAdminSysId())
								.u_approve_additional_charges("false")
								.u_access_area_visitor("false")
								.u_access_area_owner("false")
								.u_operations_contact("false")
								.build());
					}
				}
			});
		});

		user.setInternalStatus(InternalStatus.SYNCED);
		return user;
	}

	private User processDeleted(User user) {

		Map<UUID, List<UUID>> userAccountRoles = new HashMap<>();
		List<String> legalEntityKeys = new ArrayList<>();

		user.getUserAccounts().stream().filter(userAccount -> BooleanUtils.isFalse(userAccount.getAnyAccount())).forEach(userAccount -> {
			List<UUID> roleList = new ArrayList<>();

			userAccount.getAssociations().stream().forEach(userAccountAssociation -> {
				roleList.add(userAccountAssociation.getUserAccountRole().getRoleId());
			});

			userAccountRoles.put(userAccount.getId(), roleList);
			legalEntityKeys.add(userAccount.getLegalEntityKey());
		});

		Map<String, String> accountNames = accountService.getAccountNames(legalEntityKeys);
		user.getUserAccounts().stream().filter(userAccount -> BooleanUtils.isFalse(userAccount.getAnyAccount())).forEach(userAccount -> {

			SNowUserAndCompanyAssets sNowUserAndCompanyAssets = getUserAndCompanyAssets(accountNames.get(userAccount.getLegalEntityKey()));

			sNowUserAndCompanyAssets.getResult().forEach(userAsset -> {
				updateAssetUser(userAsset.getSys_id(), SNowUpdateUser.builder()
						.u_last_contact_to_update(snowAuthConfig.getAdminSysId())
						.u_access_area_owner("false")
						.build());
			});
		});

		user.setInternalStatus(InternalStatus.SYNCED);
		return user;
	}

	private SNowUserAndCompanyAssets getUserAndCompanyAssets(String companyName) {
		log.debug("Entering getUserAndCompanyAssets");
		try {
			return snowServiceRetryable.getUserAndCompanyAssets(companyName);
		} catch (Exception exception) {
			if (exception.getMessage() != null && exception.getMessage().contains(UNAUTHORIZED)) {
				snowAuthService.getAccessToken(true);
				return snowServiceRetryable.getUserAndCompanyAssets(companyName);
			}
			throw new CommonException(ErrorCode.DOWNSTREAM_SYSTEM, exception);
		}
	}

	private SNowInsertUser updateAssetUser(String sysId, SNowUpdateUser sNowUpdateUser) {
		log.debug("Entering updateUser");
		try {
			return snowServiceRetryable.updateUser(sysId, sNowUpdateUser);
		} catch (Exception exception) {
			if (exception.getMessage() != null && exception.getMessage().contains(UNAUTHORIZED)) {
				snowAuthService.getAccessToken(true);
				return snowServiceRetryable.updateUser(sysId, sNowUpdateUser);
			}
			throw new CommonException(ErrorCode.DOWNSTREAM_SYSTEM, exception);
		}
	}

	private SNowInsertUser insertAssetUser(SNowInsertUserRequest sNowInsertUserRequest) {
		log.debug("Entering insertAssetUser");
		try {
			return snowServiceRetryable.insertUser(sNowInsertUserRequest);
		} catch (Exception exception) {
			if (exception.getMessage() != null && exception.getMessage().contains(UNAUTHORIZED)) {
				snowAuthService.getAccessToken(true);
				return snowServiceRetryable.insertUser(sNowInsertUserRequest);
			}
			throw new CommonException(ErrorCode.DOWNSTREAM_SYSTEM, exception);
		}
	}

	private SNowUserSysIdByEmail getUserSysIdByEmail(String email) {
		log.debug("Entering getUserSysIdByEmail");
		try {
			return snowServiceRetryable.getUserSysIdByEmail(email);
		} catch (Exception exception) {
			if (exception.getMessage() != null && exception.getMessage().contains(UNAUTHORIZED)) {
				snowAuthService.getAccessToken(true);
				return snowServiceRetryable.getUserSysIdByEmail(email);
			}
			throw new CommonException(ErrorCode.DOWNSTREAM_SYSTEM, exception);
		}
	}
}
