package com.digitalrealty.gapi.user.model.snow;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
class SnowResult {
    @JsonProperty("request_number")
    private String requestNumber;
}