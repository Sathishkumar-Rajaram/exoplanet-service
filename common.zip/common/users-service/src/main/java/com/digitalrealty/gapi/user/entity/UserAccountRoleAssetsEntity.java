package com.digitalrealty.gapi.user.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.springframework.util.ObjectUtils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Audited
@Entity
@Table(name = "user_account_role_assets")
public class UserAccountRoleAssetsEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Type(type = "uuid-char")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_account_id", nullable = false)
	private UserAccountEntity userAccount;

	@OneToMany(mappedBy = "userAccountRoleAssets", fetch = FetchType.EAGER, orphanRemoval = true, cascade = CascadeType.ALL)
	private Set<UserAccountAssetEntity> userAccountAssets;

	@OneToOne(mappedBy = "userAccountRoleAssets", fetch = FetchType.EAGER, orphanRemoval = true, cascade = CascadeType.ALL)
	private UserAccountRoleEntity userAccountRole;

	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (!(o instanceof UserAccountRoleAssetsEntity)) {
			return false;
		}
		UserAccountRoleAssetsEntity other = (UserAccountRoleAssetsEntity) o;

		List<String> thisAssetIds = ObjectUtils.isEmpty(this.userAccountAssets) ? new ArrayList<String>() : this.userAccountAssets.stream().map(UserAccountAssetEntity::getAssetId).collect(Collectors.toList());
		List<String> otherAssetIds = ObjectUtils.isEmpty(other.userAccountAssets) ? new ArrayList<String>() : other.userAccountAssets.stream().map(UserAccountAssetEntity::getAssetId).collect(Collectors.toList());

		return this.userAccount.equals(other.userAccount) && thisAssetIds.equals(otherAssetIds) && this.userAccountRole.equals(other.userAccountRole);
	}

}
