package com.digitalrealty.gapi.user.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.digitalrealty.gapi.user.mapper.UserObjectMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
public class MappingConfig {

	@Bean
	public UserObjectMapper userObjectMapper() {
		return new UserObjectMapper();
	}

}
