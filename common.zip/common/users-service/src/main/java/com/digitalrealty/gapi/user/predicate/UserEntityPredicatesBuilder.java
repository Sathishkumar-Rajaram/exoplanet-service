package com.digitalrealty.gapi.user.predicate;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.enums.UserStatus;
import com.digitalrealty.gapi.user.model.SearchCriteria;
import com.querydsl.core.support.EnumConversion;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.EnumPath;
import com.querydsl.core.types.dsl.Expressions;
import com.querydsl.core.types.dsl.PathBuilder;

public class UserEntityPredicatesBuilder {
	private List<SearchCriteria> params;

	public UserEntityPredicatesBuilder() {
		params = new ArrayList<>();
	}

	public UserEntityPredicatesBuilder with(String key, String operation, Object value) {
		params.add(new SearchCriteria(key, operation, value));
		return this;
	}

	public BooleanExpression build() {
		if (params.isEmpty()) {
			return Expressions.asBoolean(true).isTrue();
		}

		List<BooleanExpression> predicates = params.stream().map(param -> {
			if (param.getKey() == "status") {
				PathBuilder<UserEntity> entityPath = new PathBuilder<>(UserEntity.class, "userEntity");
				EnumPath<UserStatus> path = entityPath.getEnum(param.getKey(), UserStatus.class);
				EnumConversion<UserStatus> conv = new EnumConversion<UserStatus>(path);
				UserStatus status = conv.newInstance(param.getValue());
				return path.eq(status);
			}
			UserEntityPredicate predicate = new UserEntityPredicate(param);
			return predicate.getPredicate();
		}).filter(Objects::nonNull).collect(Collectors.toList());

		BooleanExpression result = Expressions.asBoolean(true).isTrue();
		for (BooleanExpression predicate : predicates) {
			result = result.and(predicate);
		}
		return result;
	}
}