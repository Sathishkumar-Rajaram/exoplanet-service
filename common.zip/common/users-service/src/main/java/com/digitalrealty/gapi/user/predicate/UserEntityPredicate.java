package com.digitalrealty.gapi.user.predicate;

import java.util.Collection;

import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.model.SearchCriteria;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.NumberPath;
import com.querydsl.core.types.dsl.PathBuilder;
import com.querydsl.core.types.dsl.StringPath;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class UserEntityPredicate {

	private SearchCriteria criteria;

	public BooleanExpression getPredicate() {
		PathBuilder<UserEntity> entityPath = new PathBuilder<>(UserEntity.class, "userEntity");

		if (Integer.class.isAssignableFrom(entityPath.get(criteria.getKey()).getType())) {
			NumberPath<Integer> path = entityPath.getNumber(criteria.getKey(), Integer.class);
			int value = Integer.parseInt(criteria.getValue().toString());
			switch (criteria.getOperation()) {
			case ":":
				return path.eq(value);
			case ">":
				return path.goe(value);
			case "<":
				return path.loe(value);
			}
		} else {
			StringPath path = entityPath.getString(criteria.getKey());
			switch (criteria.getOperation()) {
			case ":":
				return path.containsIgnoreCase(criteria.getValue().toString());
			case "in":
				return path.in((Collection<? extends String>) criteria.getValue());
			}
		}
		return null;
	}
}