package com.digitalrealty.gapi.user.mapper;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.user.entity.UserAccountRoleAssetsEntity;
import com.digitalrealty.gapi.user.model.UserAccountRoleAssets;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true), uses = { UserAccountAssetMapper.class, UserAccountRoleMapper.class })
public interface UserAccountRoleAssetsMapper {

	UserAccountRoleAssets map(UserAccountRoleAssetsEntity associationEntity);

}