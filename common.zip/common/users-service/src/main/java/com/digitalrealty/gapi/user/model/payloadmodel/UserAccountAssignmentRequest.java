package com.digitalrealty.gapi.user.model.payloadmodel;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Validated
public class UserAccountAssignmentRequest {

	@NotEmpty
	List<@Valid UserAccountAssetRoles> userAccounts;

}
