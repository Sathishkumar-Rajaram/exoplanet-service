package com.digitalrealty.gapi.user.service;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.messaging.user.MaintainUserMessage;
import com.digitalrealty.gapi.user.configuration.MessagingConfig;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class JmsUserService {

	private final JmsTemplate jmsTemplate;

	private final MessagingConfig messagingConfig;

	public String sendMessage(MaintainUserMessage message) {
		jmsTemplate.convertAndSend(messagingConfig.getMaintainUserQueue(), message);
		return message.getUserId().toString();
	}
}
