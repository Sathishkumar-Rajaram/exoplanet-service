package com.digitalrealty.gapi.user.model.payloadmodel;

import java.time.Instant;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserAccountAssociationsResponse {

	String globalUltimateKey;

	String globalUltimateName;

	Boolean internalCompanyFlag;

	Boolean isDefault;

	String legalEntityKey;

	String legalEntityName;

	Instant createTimestamp;

	String createdBy;

	String lastModifiedBy;

	String accountStatus;

	Instant accountStatusUpdateTimestamp;

	Instant statusUpdateTimestamp;

	String status;

	String approvalStatus;

	List<RoleAssets> associations;

}