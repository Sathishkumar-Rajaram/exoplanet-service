package com.digitalrealty.gapi.user.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.digitalrealty.gapi.user.entity.UserAccountRoleEntity;
import com.digitalrealty.gapi.user.model.IUserAccountRole;

@Repository
public interface UserAccountRoleRepository extends CrudRepository<UserAccountRoleEntity, UUID> {

	List<IUserAccountRole> findByRoleId(UUID roleId);

	@Query(value = "SELECT user_account_role.role_id as roleId, user_account_role.user_account_role_assets_id as userAccountRoleAssetsId FROM user_gapi.user_account_role, user_gapi.user_account_role_assets WHERE " +
			"user_account_role_assets.id = user_account_role.user_account_role_assets_id AND user_account_role_assets.user_account_id = ?1", nativeQuery = true)
	List<IUserAccountRole> findByUserAccountId(String userAccountId);

	@Query(value = "SELECT role_id FROM user_gapi.user_account_role, user_gapi.user_account_role_assets WHERE " +
			"user_account_role_assets.id = user_account_role.user_account_role_assets_id AND user_account_role_assets.user_account_id = ?1", nativeQuery = true)
	List<UUID> findIdsByUserAccountId(String userAccountId);

	@Query(value = "SELECT user_account_role_assets.user_account_id FROM user_gapi.user_account_role, user_gapi.user_account_role_assets WHERE " +
			"user_account_role_assets.id = user_account_role.user_account_role_assets_id AND user_account_role_assets.user_account_id = ?1", nativeQuery = true)
	List<UUID> findUserAccountIdsByRoleId(String roleId);

	@Query(value = "SELECT user_account_role.role_id as roleId, user_account_role_assets.user_account_id as userAccountRoleAssetsId FROM user_gapi.user_account_role, user_gapi.user_account_role_assets, user_gapi.user_account_asset WHERE " +
			"user_account_role_assets.id = user_account_role.user_account_role_assets_id AND user_account_role_assets.user_account_id = ?1 AND user_account_asset.asset_id in ?2", nativeQuery = true)
	List<IUserAccountRole> findUserAccountIdsByAssetIdIn(String userAccountId, List<String> assetIds);
}
