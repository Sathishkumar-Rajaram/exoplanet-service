package com.digitalrealty.gapi.user.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.user.entity.UserAccountAssetEntity;
import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.entity.UserAccountRoleAssetsEntity;
import com.digitalrealty.gapi.user.entity.UserAccountRoleEntity;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.enums.TermStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.mapper.UserMapper;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.payloadmodel.AssetModel;
import com.digitalrealty.gapi.user.model.payloadmodel.RoleAssets;
import com.digitalrealty.gapi.user.model.payloadmodel.TermsConditionsRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssetRoles;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssignmentRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileUpdateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateLegalEntitiesRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateLegalEntitiesResponse;
import com.digitalrealty.gapi.user.predicate.UserEntityPredicatesBuilder;
import com.digitalrealty.gapi.user.repository.DynamicUserRepository;
import com.digitalrealty.gapi.user.repository.UserRepository;
import com.querydsl.core.types.Predicate;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class UserDBService {

	private final DynamicUserRepository dynamicUserRepository;

	private final AccountService accountService;

	private final UserRepository userRepository;

	private final UserMapper userMapper;

	private final UserAccountDBService userAccountDBService;

	public User findByEmail(String email) {
		return userMapper.map(userRepository.findByEmail(email));
	}

	public Page<UserEntity> findByLegalEntityKeyIn(List<String> legalEntityKeys, String filterFirstName, String filterLastName, String filterEmail, String filterPhone, String filterStatus, Pageable pageable) {
		List<UUID> userIds = new ArrayList<>();
		legalEntityKeys.forEach(legalEntityKey -> {
			userIds.addAll(userAccountDBService.findByAccountId(legalEntityKey).stream().map(UserAccount::getUserId).collect(Collectors.toSet()));
		});

		UserEntityPredicatesBuilder userEntityPredicatesBuilder = new UserEntityPredicatesBuilder();

		userEntityPredicatesBuilder.with("id", "in", userIds);

		if (!Objects.isNull(filterFirstName)) {
			userEntityPredicatesBuilder.with("firstName", ":", filterFirstName);
		}
		if (!Objects.isNull(filterLastName)) {
			userEntityPredicatesBuilder.with("lastName", ":", filterLastName);
		}
		if (!Objects.isNull(filterEmail)) {
			userEntityPredicatesBuilder.with("email", ":", filterEmail);
		}
		if (!Objects.isNull(filterPhone)) {
			userEntityPredicatesBuilder.with("phone", ":", filterPhone);
		}
		if (!Objects.isNull(filterStatus)) {
			userEntityPredicatesBuilder.with("status", ":", filterStatus);
		}

		Predicate predicate = userEntityPredicatesBuilder.build();
		return dynamicUserRepository.findAll(predicate, pageable);
	}

	public User findById(UUID id) {
		Optional<UserEntity> user = userRepository.findById(id);
		if (user.isPresent()) {
			return userMapper.map(user.get());
		}
		return null;
	}

	public User findByIdEager(UUID id) {
		Optional<UserEntity> user = userRepository.findById(id);
		if (user.isPresent()) {
			UserEntity entity = user.get();
			entity.getUserAccounts().stream().forEach(account -> {
				account.getUserAccountRoleAssets().stream().forEach(roleAssets -> {
					roleAssets.getUserAccountAssets();
					roleAssets.getUserAccountRole();
				});
			});
			return userMapper.map(entity);
		}
		return null;
	}

	private UserEntity findByUserIdEager(UUID id) {
		Optional<UserEntity> user = userRepository.findById(id);
		if (user.isPresent()) {
			UserEntity entity = user.get();
			entity.getUserAccounts().stream().forEach(account -> {
				account.getUserAccountRoleAssets().stream().forEach(roleAssets -> {
					roleAssets.getUserAccountAssets();
					roleAssets.getUserAccountRole();
				});
			});
			return entity;
		}
		return null;
	}

	public List<User> findByIdIn(List<UUID> userIds, Pageable pageable) {
		return userRepository.findByIdIn(userIds, pageable).stream().map(user -> userMapper.map(user)).collect(Collectors.toList());
	}

	public List<User> findByStatus(UserStatus userStatus) {
		return userRepository.findByStatus(userStatus).stream().map(user -> userMapper.map(user)).collect(Collectors.toList());
	}

	public List<User> findByInternalStatusIn(List<InternalStatus> internalStatuses) {
		return userRepository.findByInternalStatusIn(internalStatuses).stream().map(user -> userMapper.map(user)).collect(Collectors.toList());
	}

	public void updateExecutionId(String executionId, int batchExecutionIdsSize) {
		userRepository.updateExecutionId(executionId, batchExecutionIdsSize);
	}

	public void resetExecutionIds(long resetExecutionIdsTimeWindowSec) {
		userRepository.resetExecutionIds(resetExecutionIdsTimeWindowSec);
	}

	public void updateExecutionIdAsNull(String executionId) {
		userRepository.updateExecutionIdAsNull(executionId);
	}

	public List<User> findByExecutionId(String executionId) {
		return userRepository.findByExecutionId(executionId).stream().map(user -> userMapper.map(user)).collect(Collectors.toList());
	}

	public User createUser(UserCreateRequest createUserRequest) {
		UserEntity user = userMapper.map(createUserRequest);
		if (Objects.isNull(user)) {
			throw new CommonException(UserErrorCode.USER_NOTFOUND);
		}

		user.setTermsAndConditionsStatus(TermStatus.ALERTED);
		user.setStatus(UserStatus.CREATED);
		user.setStatusChangeDate(Instant.now());
		user.setInternalStatus(InternalStatus.NEED_SYNC);

		return userMapper.map(userRepository.save(user));
	}

	public User updateUserProfile(String email, UserProfileUpdateRequest userProfileUpdateRequest) {
		UserEntity user = userRepository.findByEmail(email);
		if (Objects.isNull(user)) {
			throw new CommonException(UserErrorCode.USER_NOTFOUND);
		}

		userMapper.update(user, userProfileUpdateRequest);

		return userMapper.map(userRepository.save(user));
	}

	public User updateUser(UUID userId, UserUpdateRequest updateUserRequest) {
		UserEntity user = userRepository.findById(userId)
				.orElseThrow(() -> new CommonException(UserErrorCode.USER_NOTFOUND));

		userMapper.update(user, updateUserRequest);

		return userMapper.map(userRepository.save(user));
	}

	public List<User> saveUsers(List<User> users) {
		return ((List<UserEntity>) userRepository.saveAll(users.stream().map(user -> userMapper.map(user)).collect(Collectors.toList()))).stream().map(user -> userMapper.map(user)).collect(Collectors.toList());
	}

	public User saveUser(User user) {
		return userMapper.map(userRepository.save(userMapper.map(user)));
	}

	public User updateUserAccountStatus(UUID targetUserId, Map<String, UserAccountStatus> userAccounts) {
		UserEntity userEntity = findByUserIdEager(targetUserId);
		if (Objects.isNull(userEntity)) {
			throw new CommonException(UserErrorCode.USER_NOTFOUND);
		}

		userEntity.getUserAccounts().stream().filter(account -> userAccounts.containsKey(account.getLegalEntityKey())).forEach(account -> {
			account.setStatus(userAccounts.get(account.getLegalEntityKey()));
			account.setStatusChangedDate(Instant.now());
		});

		if (userEntity.getUserAccounts().stream().filter(targetUserAccount -> targetUserAccount.getStatus() == UserAccountStatus.ACTIVE).count() == 0) {
			userEntity.setStatus(UserStatus.NOTACTIVE);
			userEntity.setStatusChangeDate(Instant.now());
		} else if (userEntity.getStatus() == UserStatus.NOTACTIVE) {
			userEntity.setStatus(UserStatus.ACTIVE);
			userEntity.setStatusChangeDate(Instant.now());
		}

		return userMapper.map(userRepository.save(userEntity));
	}

	public User saveUserAssignments(UUID targetUserId, boolean includeInternal, UserAccountAssignmentRequest userAccountAssignmentRequest, Map<String, List<UUID>> targetUserAccountRoles, Map<String, List<AssetModel>> targetUserAccountAssets) {
		UserEntity userEntity = findByUserIdEager(targetUserId);

		List<String> targetUserAccountIds = userAccountAssignmentRequest.getUserAccounts().stream().map(UserAccountAssetRoles::getLegalEntityKey).collect(Collectors.toList());

		ValidateLegalEntitiesResponse errorKeys = null;
		if (userEntity.getUserAccounts().isEmpty()) {
			errorKeys = ValidateLegalEntitiesResponse.builder().erroredLegalEntityKeys(new ArrayList<String>()).build();
		} else {
			errorKeys = accountService.validateLegalEntities(ValidateLegalEntitiesRequest.builder().legalEntityKeys(userEntity.getUserAccounts().stream().map(UserAccountEntity::getLegalEntityKey).collect(Collectors.toList())).build());
		}
		final ValidateLegalEntitiesResponse errorEntityKeys = errorKeys;

		userEntity.getUserAccounts().stream()
				.filter(userAccountEntity -> !targetUserAccountIds.contains(userAccountEntity.getLegalEntityKey()) &&
						((includeInternal && userAccountEntity.getAnyAccount()) || (!userAccountEntity.getAnyAccount() && !errorEntityKeys.erroredLegalEntityKeys.contains(userAccountEntity.getLegalEntityKey()))))
				.forEach(targetUserAccount -> {
					targetUserAccount.setStatus(UserAccountStatus.DELETED);
				});

		List<String> existingUserAccountIds = userEntity.getUserAccounts().stream().map(UserAccountEntity::getLegalEntityKey).collect(Collectors.toList());

		userEntity.getUserAccounts().stream()
				.forEach(existUserAccount -> {
					if (userAccountAssignmentRequest.getUserAccounts().stream().filter(userAccount -> userAccount.getLegalEntityKey().equalsIgnoreCase(existUserAccount.getLegalEntityKey())).count() > 0) {

						List<UUID> targetRoleIds = targetUserAccountRoles.get(existUserAccount.getLegalEntityKey());
						List<UUID> existingRoleIds = existUserAccount.getUserAccountRoleAssets().stream().map(roleAsset -> roleAsset.getUserAccountRole().getRoleId()).collect(Collectors.toList());
						UserAccountAssetRoles userAssociationRequest = userAccountAssignmentRequest.getUserAccounts().stream().filter(userAccount -> userAccount.getLegalEntityKey().equalsIgnoreCase(existUserAccount.getLegalEntityKey())).findFirst().get();

						// Edit existing
						existUserAccount.getUserAccountRoleAssets().stream().filter(roleAssets -> targetRoleIds.contains(roleAssets.getUserAccountRole().getRoleId())).map(roleAssets -> {

							RoleAssets association = userAssociationRequest.getAssociations().stream().filter(roleAssociation -> roleAssociation.getRole().equals(roleAssets.getUserAccountRole().getId())).findFirst().get();
							List<String> existingAssetIds = roleAssets.getUserAccountAssets().stream().map(UserAccountAssetEntity::getAssetId).collect(Collectors.toList());

							// Add new assets
							Set<UserAccountAssetEntity> addedAssets = association.getAssets().stream().filter(assetAssociation -> !existingAssetIds.contains(assetAssociation)).map(assetAssociation -> {
								UserAccountAssetEntity uaAsset = new UserAccountAssetEntity();
								uaAsset.setAssetId(assetAssociation.getAssetId());
								uaAsset.setSitePath(assetAssociation.getSitePath());
								uaAsset.setUserAccountRoleAssets(roleAssets);
								return uaAsset;
							}).collect(Collectors.toSet());
							roleAssets.getUserAccountAssets().addAll(addedAssets);

							// Remove assets
							Set<UserAccountAssetEntity> deletedAssets = roleAssets.getUserAccountAssets().stream().filter(assetAssociation -> !association.getAssets().contains(assetAssociation.getAssetId())).collect(Collectors.toSet());
							roleAssets.getUserAccountAssets().removeAll(deletedAssets);

							return roleAssets;
						});

						// Delete roles
						Set<UserAccountRoleAssetsEntity> deletedRoles = existUserAccount.getUserAccountRoleAssets().stream().filter(association -> !targetRoleIds.contains(association.getUserAccountRole().getRoleId())).collect(Collectors.toSet());
						existUserAccount.getUserAccountRoleAssets().removeAll(deletedRoles);

						// Add new associations
						userAssociationRequest.getAssociations().stream().filter(roleAssociation -> !existingRoleIds.contains(roleAssociation.getRole())).forEach(roleAssociation -> {
							UserAccountRoleAssetsEntity userAccountAssociation = new UserAccountRoleAssetsEntity();
							userAccountAssociation.setUserAccount(existUserAccount);

							UserAccountRoleEntity uaRole = new UserAccountRoleEntity();
							uaRole.setRoleId(roleAssociation.getRole());
							uaRole.setUserAccountRoleAssets(userAccountAssociation);
							userAccountAssociation.setUserAccountRole(uaRole);

							Set<UserAccountAssetEntity> addedAssets = roleAssociation.getAssets().stream().map(userAsset -> {
								UserAccountAssetEntity uaAsset = new UserAccountAssetEntity();
								uaAsset.setAssetId(userAsset.getAssetId());
								uaAsset.setSitePath(userAsset.getSitePath());
								uaAsset.setUserAccountRoleAssets(userAccountAssociation);
								return uaAsset;
							}).collect(Collectors.toSet());
							userAccountAssociation.setUserAccountAssets(addedAssets);

							existUserAccount.getUserAccountRoleAssets().add(userAccountAssociation);
						});
					}

					if (existUserAccount.getStatus() == UserAccountStatus.DELETED) {
						existUserAccount.setStatus(UserAccountStatus.ACTIVE);
					}
					existUserAccount.setUser(userEntity);
				});

		Set<UserAccountEntity> newUserAccountEntities = userAccountAssignmentRequest.getUserAccounts().stream()
				.filter(targetedUserAccount -> !existingUserAccountIds.contains(targetedUserAccount.getLegalEntityKey()))
				.map(targetedUserAccount -> {

					UserAccountEntity newUserAccount = new UserAccountEntity(targetedUserAccount.getLegalEntityKey(), userEntity, UserAccountStatus.ACTIVE, ApprovalStatus.INVITE_SENT, false, targetedUserAccount.getAnyAccount(), Instant.now(), null);

					Set<UserAccountRoleAssetsEntity> roleAssetAssociations = targetedUserAccount.getAssociations().stream().map(roleAssociation -> {
						UserAccountRoleAssetsEntity userAccountAssociation = new UserAccountRoleAssetsEntity();
						userAccountAssociation.setUserAccount(newUserAccount);

						UserAccountRoleEntity uaRole = new UserAccountRoleEntity();
						uaRole.setRoleId(roleAssociation.getRole());
						uaRole.setUserAccountRoleAssets(userAccountAssociation);
						userAccountAssociation.setUserAccountRole(uaRole);

						Set<UserAccountAssetEntity> addedAssets = roleAssociation.getAssets().stream().map(userAsset -> {
							UserAccountAssetEntity uaAsset = new UserAccountAssetEntity();
							uaAsset.setAssetId(userAsset.getAssetId());
							uaAsset.setSitePath(userAsset.getSitePath());
							uaAsset.setUserAccountRoleAssets(userAccountAssociation);
							return uaAsset;
						}).collect(Collectors.toSet());
						userAccountAssociation.setUserAccountAssets(addedAssets);

						return userAccountAssociation;
					}).collect(Collectors.toSet());

					newUserAccount.setUserAccountRoleAssets(roleAssetAssociations);
					return newUserAccount;
				})
				.collect(Collectors.toSet());

		if (existingUserAccountIds.size() == 0 && newUserAccountEntities.size() > 0) {
			List<UserAccountEntity> userAccountAssociations = new ArrayList<>(newUserAccountEntities);
			userAccountAssociations.get(0).setDefaultAccount(true);
			userAccountAssociations.get(0).setApprovalStatus(ApprovalStatus.APPROVED);
			newUserAccountEntities = new HashSet<UserAccountEntity>(userAccountAssociations);
		}

		userEntity.getUserAccounts().addAll(newUserAccountEntities);

		if (userEntity.getInternalStatus() == InternalStatus.SYNCED) {
			userEntity.setInternalStatus(InternalStatus.NEED_ASSIGNMENT_SYNC);
		}

		return userMapper.map(userRepository.save(userEntity));
	}

	public User saveTermsAndConditions(String encryptedEmail, TermsConditionsRequest termsConditionsRequest) {
		UserEntity user = userRepository.findByEmail(encryptedEmail);
		if (Objects.isNull(user)) {
			throw new CommonException(UserErrorCode.USER_NOTFOUND);
		}

		userMapper.update(user, termsConditionsRequest);
		user.setTermsAndConditionsDate(Instant.now());

		return userMapper.map(userRepository.save(user));
	}

	public List<User> getAllUsersWithDeletedAccountsForLE(List<String> legalEntityKeys) {
		return userRepository.findByUserAccountsLegalEntityKeyInAndUserAccountsStatus(legalEntityKeys, UserAccountStatus.DELETED)
				.stream().map(userMapper::map).collect(Collectors.toList());
	}
}
