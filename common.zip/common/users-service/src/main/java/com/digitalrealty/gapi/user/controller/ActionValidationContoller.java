package com.digitalrealty.gapi.user.controller;

import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationResponse;
import com.digitalrealty.gapi.user.service.AuthorizationService;
import com.digitalrealty.gapi.user.service.UserAccountRoleService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
public class ActionValidationContoller {

	private final AuthorizationService authorizationService;

	private final UserAccountRoleService userAccountRoleService;

	@PostMapping(value = { "/users/validate-action" }, produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity<ActionValidationResponse> validateAction(@Valid @RequestBody ActionValidationRequest actionValidationRequest) {
		return new ResponseEntity<>(authorizationService.isAuthorized(actionValidationRequest), HttpStatus.OK);
	}

	@GetMapping(value = "/users/validate-role/{role_id}", produces = { "application/json" })
	public ResponseEntity<Void> validateRole(@NotBlank @PathVariable(value = "role_id") UUID roleId) {
		userAccountRoleService.validateUserRole(roleId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}