package com.digitalrealty.gapi.user.model.snow;

import org.springframework.validation.annotation.Validated;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
public class SNowInsertUserRequest {

	private String u_customer_ref_1;

	private String u_cmdb_ci_ref_1;

	private String u_contact_ref_1;

	private String u_location_ref_1;

	private String u_last_contact_to_update;

	private String u_pm_high_sched;

	private String u_approve_additional_charges;

	private String u_appr_await_appr;

	private String u_place_orders;

	private String u_access_area_owner;

	private String u_accounting_contact;

	private String u_authorize_deliveries;

	private String u_read_only;

	private String u_access_area_delegate;

	private String u_everbridge;

	private String sys_updated_by;

	private String u_pm_low_wip;

	private String u_appr_rejected;

	private String u_access_area_visitor;

	private String u_authorize_vendor_work;

	private String u_pm_high_wc;

	private String u_emergency_contact;

	private String u_pm_low_sched;

	private String u_appr_approved;

	private String u_data_center_contact;

	private String u_sec_rejected;

	private String u_customer_evacuation_assistance_required;

	private String u_access_facility;

	private String u_fire_warden_contact;

	private String u_customer_portal_access;

	private String u_pbb_include;

	private String u_sec_await_appr;

	private String u_operations_contact;

	private String u_sec_wc;

	private String u_end_date;

	private String u_sla_notification;

	private String u_pm_high_wip;

	private String u_sec_rec;

	private String u_pm_low_wc;

	private String u_request_support;

	private String u_ip_network_contact;

	private String u_view_invoices;

	private String u_primary_contact;

	private String u_change_management_approver_1;

	private String u_remote_hands_contact;
}
