package com.digitalrealty.gapi.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.messaging.user.MaintainUserMessage;
import com.digitalrealty.gapi.messaging.user.UserRequestType;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.mapper.UserAccountMapper;
import com.digitalrealty.gapi.user.mapper.UserMapper;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.payloadmodel.GetAccountsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.TermsConditionsRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileUpdateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileUpdateResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateResponse;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {

	private final UserDBService userDBService;

	private final UserMapper userMapper;

	private final IdpService idpService;

	private final SnowService snowService;

	private final EmailService emailService;

	private final EncryptionService encryptionService;

	private final JmsUserService jmsUserService;

	private final AccountService accountService;

	private final UserAccountMapper userAccountMapper;

	private final SuperUserDBService superUserDBService;

	public UserCreateResponse createUser(UserCreateRequest createUserRequest) {
		User targetUser = userDBService.findByEmail(createUserRequest.getEmail());
		if (!Objects.isNull(targetUser)) {
			throw new CommonException(UserErrorCode.USER_EXISTS);
		}
		UserCreateResponse response = userMapper.mapUserToCreateUserResponse(userDBService.createUser(createUserRequest));

		jmsUserService.sendMessage(new MaintainUserMessage(response.getId(), UserRequestType.CREATED));
		return response;
	}

	public UserProfileUpdateResponse updateUserProfile(UserProfileUpdateRequest userProfileUpdateRequest) {
		String userEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());
		UserProfileUpdateResponse response = userMapper.mapUserToUserProfileUpdateResponse(userDBService.updateUserProfile(userEmail, userProfileUpdateRequest));
		jmsUserService.sendMessage(new MaintainUserMessage(response.getId(), UserRequestType.UPDATED));
		return response;
	}

	public UserUpdateResponse updateUser(UUID userId, UserUpdateRequest updateUserRequest) {
		UserUpdateResponse response = userMapper.mapUserToUpdateUserRequest(userDBService.updateUser(userId, updateUserRequest));
		jmsUserService.sendMessage(new MaintainUserMessage(response.getId(), UserRequestType.UPDATED));
		return response;
	}

	public void maintainTermsConditions(TermsConditionsRequest termsConditionsRequest) {
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());

		userDBService.saveTermsAndConditions(encryptedEmail, termsConditionsRequest);
	}

	public UserProfileResponse getUser(UUID userId) {
		return userMapper.mapUserToUserRetrieveResponse(userDBService.findById(userId));
	}

	public Page<UserResponse> getUsers(Pageable pageable, String filterFirstName, String filterLastName, String filterEmail, String filterPhone, String filterStatus) {
		List<String> loggedInUsersLegalEntityKeys = new ArrayList<>();

		List<String> legalEntityKeys = accountService.getLegalEntitiesForGlobalUltimate();
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());
		User loggedInUser = userDBService.findByEmail(encryptedEmail);

		if (!Objects.isNull(loggedInUser)) {
			loggedInUsersLegalEntityKeys = loggedInUser.getUserAccounts().stream()
					.map(UserAccount::getLegalEntityKey)
					.filter(legalEntityKeys::contains).collect(Collectors.toList());
		} else {
			String superUser = superUserDBService.findByEmail(encryptedEmail);
			if (Objects.isNull(superUser)) {
				throw new CommonException(UserErrorCode.NO_PERMISSION);
			}
		}

		Page<UserEntity> users = userDBService.findByLegalEntityKeyIn(loggedInUsersLegalEntityKeys, filterFirstName, filterLastName, filterEmail, filterPhone, filterStatus, pageable);
		List<GetAccountsResponse> accountInformation = accountService.getAccounts(loggedInUsersLegalEntityKeys);
		List<String> accountLegalEntityKeys = accountInformation.stream().map(GetAccountsResponse::getLegalEntityKey).collect(Collectors.toList());

		return new PageImpl<UserResponse>(users.getContent().stream()
				.map(user -> userMapper.mapToUserResponse(user, user.getUserAccounts().stream()
						.filter(userAccount -> accountLegalEntityKeys.contains(userAccount.getLegalEntityKey()))
						.map(userAccountEntity -> userAccountMapper.mapToUserAccountsResponse(userAccountEntity, accountInformation.stream().filter(userAcc -> userAcc.getLegalEntityKey().equals(userAccountEntity.getLegalEntityKey())).findFirst().get())).collect(Collectors.toList())))
				.collect(Collectors.toList()),
				pageable, users.getTotalElements());
	}

	public void updateExternalSystems(List<User> userList) {

		List<User> result = idpService.syncUsersToIdp(userList.stream().filter(user -> (user.getInternalStatus() == InternalStatus.NEED_SYNC)).collect(Collectors.toList()));

		result = snowService.syncUsersToSnow(Stream.concat(userList.stream().filter(user -> user.getInternalStatus() == InternalStatus.IDP_SYNCED), result.stream()).collect(Collectors.toList()));

		result = snowService.syncUsersAssetsAndRoles(Stream.concat(userList.stream().filter(user -> user.getInternalStatus() == InternalStatus.NEED_ASSIGNMENT_SYNC), result.stream()).collect(Collectors.toList()));

	}

	public List<User> getDeletedUserAccount() {
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());
		User loggedInUser = userDBService.findByEmail(encryptedEmail);
		List<String> legalEntitiesForGU = accountService.getLegalEntitiesForGU();
		List<String> userLegalEntitiesForGU = loggedInUser.getUserAccounts().stream().filter(ua -> legalEntitiesForGU.contains(ua.getLegalEntityKey())).map(UserAccount::getLegalEntityKey).collect(Collectors.toList());
		return userDBService.getAllUsersWithDeletedAccountsForLE(userLegalEntitiesForGU);
	}
}
