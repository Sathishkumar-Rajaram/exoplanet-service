package com.digitalrealty.gapi.user.util;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;

public class AssetUtil {

	public static final String SITE = "site";

	public static final String REGION = "region";

	public static final String COUNTRY = "country";

	public static final String METRO = "metro";

	public static final String CITY = "city";

	public static HashMap<String, String> parseAssetPath(String assetPath) {
		HashMap<String, String> assetPaths = new HashMap<String, String>();

		String[] parts = assetPath.split(",");
		for (int i = 0; i < parts.length; i++) {
			String[] keyValue = parts[i].split("=");
			try {
				assetPaths.put(keyValue[0], java.net.URLDecoder.decode(keyValue[1], StandardCharsets.UTF_8.name()));
			} catch (UnsupportedEncodingException exception) {
				throw new CommonException(ErrorCode.SYSTEM, exception);
			}
		}

		return assetPaths;
	}
}
