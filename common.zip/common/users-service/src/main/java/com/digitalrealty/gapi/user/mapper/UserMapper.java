package com.digitalrealty.gapi.user.mapper;

import java.util.List;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.payloadmodel.IdpCreateUserRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.TermsConditionsRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileUpdateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileUpdateResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateResponse;
import com.digitalrealty.gapi.user.model.snow.SnowCreateUserRequest;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true), uses = { MappingUtil.class })
public interface UserMapper {

	@Mapping(target = "userAccounts", source = "user", qualifiedByName = "getUserAccountsEntity")
	UserEntity map(User user);

	@Mapping(target = "userAccounts", source = "userEntity", qualifiedByName = "getUserAccounts")
	User map(UserEntity userEntity);

	UserEntity map(UserCreateRequest createUserRequest);

	void update(@MappingTarget UserEntity user, UserProfileUpdateRequest userProfileUpdateRequest);

	void update(@MappingTarget UserEntity user, UserUpdateRequest userUpdateRequest);

	void update(@MappingTarget UserEntity user, TermsConditionsRequest termsConditionsRequest);

	UserCreateResponse mapUserToCreateUserResponse(User user);

	UserProfileUpdateResponse mapUserToUserProfileUpdateResponse(User user);

	UserUpdateResponse mapUserToUpdateUserRequest(User user);

	UserProfileResponse mapUserToUserRetrieveResponse(User user);

	@Mapping(source = "email", target = "id")
	@Mapping(source = "email", target = "userName")
	@Mapping(source = "email", target = "emailAddress")
	@Mapping(source = "id", target = "externalId")
	IdpCreateUserRequest mapUserToIdpCreateUserRequest(User user);

	SnowCreateUserRequest mapUserToSnowCreateUserRequest(User user);

	@Mapping(target = "id", source = "user.id")
	@Mapping(target = "firstName", source = "user.firstName")
	@Mapping(target = "lastName", source = "user.lastName")
	@Mapping(target = "email", source = "user.email")
	@Mapping(target = "phone", source = "user.phone")
	@Mapping(target = "status", source = "user.status")
	@Mapping(target = "internalStatus", source = "user.internalStatus")
	@Mapping(target = "statusChangeDate", source = "user.statusChangeDate")
	@Mapping(target = "userAccounts", source = "userAccounts")
	UserResponse mapToUserResponse(UserEntity user, List<UserAccountsResponse> userAccounts);
}
