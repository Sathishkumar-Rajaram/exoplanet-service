package com.digitalrealty.gapi.user.model.payloadmodel;

import java.util.Map;
import java.util.UUID;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import com.digitalrealty.gapi.user.enums.ApprovalStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Validated
public class UserAccountApprovalRequest {

	@NotEmpty
	Map<UUID, ApprovalStatus> userAccounts;

}
