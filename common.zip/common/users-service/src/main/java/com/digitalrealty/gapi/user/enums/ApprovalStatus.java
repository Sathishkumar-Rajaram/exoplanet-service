package com.digitalrealty.gapi.user.enums;

public enum ApprovalStatus {
	INVITE_SENT,
    APPROVED,
    NOT_APPROVED_BY_USER;
}
