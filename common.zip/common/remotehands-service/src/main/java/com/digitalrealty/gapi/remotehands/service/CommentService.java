package com.digitalrealty.gapi.remotehands.service;

import java.text.MessageFormat;
import java.util.List;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalrealty.gapi.common.context.ContextHeaders;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.CommonExceptionUtil;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.remotehands.config.URLConfig;
import com.digitalrealty.gapi.remotehands.model.Comment;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
@Service
@Slf4j
public class CommentService {

	private final WebClient webClient;
	private final URLConfig urlConfig;
	private final RedisCacheService redisCacheService;
	private final JwtConfig jwtConfig;

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public List<Comment> getComment(String snowId) {
		log.debug("Entering getComment.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(urlConfig.getCommentServiceUrl());
		builder.path(MessageFormat.format(urlConfig.getCommentServicePath(), snowId));

		log.debug("getComment URL: {}", builder.build().toUriString());
		List<Comment> response = webClient.get()
				.uri(builder.build().toUri())
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(new ParameterizedTypeReference<List<Comment>>() {
				})
				.block();

		log.debug("Get Comments Response: {}", response);
		return response;
	}
}
