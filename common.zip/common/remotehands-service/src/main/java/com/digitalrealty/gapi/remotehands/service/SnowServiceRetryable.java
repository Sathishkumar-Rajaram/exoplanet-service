package com.digitalrealty.gapi.remotehands.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalrealty.gapi.common.auth.service.SnowAuthService;
import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;
import com.digitalrealty.gapi.remotehands.config.URLConfig;
import com.digitalrealty.gapi.remotehands.exception.RemotehandsErrorCode;
import com.digitalrealty.gapi.remotehands.model.CancelServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowRequest;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.FetchServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.UpdateServiceNowRequest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Slf4j
@RequiredArgsConstructor
public class SnowServiceRetryable {

	private static final String REMOTE_HANDS_SERVICES = "Remote Hands Services";
	private static final String ORDERBYDESC_SYS_CREATED_ON = "ORDERBYDESCsys_created_on";

	private final WebClient webClient;

	private final URLConfig urlConfig;

	private final SnowMappingConfig snowMappingConfig;

	private final SnowAuthService snowAuthService;

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public CreateServiceNowResponse createServiceNow(CreateServiceNowRequest createServiceNow) {
		log.debug("Entering createServiceNow.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(urlConfig.getSnowHost());
		builder.path(urlConfig.getSnowFacilityApiPath());
		builder.query(urlConfig.getSnowDefaultParams());

		log.debug("create servicenow ticket URL: {}", builder.build().toUriString());
		CreateServiceNowResponse response = webClient.post()
				.uri(builder.build().toUriString())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(createServiceNow), CreateServiceNowRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(CreateServiceNowResponse.class)
				.block();

		log.debug("create servicenow ticket Response - {}", response);
		return response;
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public FetchServiceNowResponse getBySnowId(String snowId, String accountName) {
		log.debug("Entering getBySnowId.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(urlConfig.getSnowHost());
		builder.path(urlConfig.getSnowFacilityApiPath());
		builder.query(urlConfig.getSnowDefaultParams());
		builder.queryParam("number", snowId).queryParam("company", accountName);
		builder.queryParam("category", REMOTE_HANDS_SERVICES);

		log.debug("getBySnowId URL: {}", builder.build().toUriString());
		FetchServiceNowResponse response = webClient.get()
				.uri(builder.build().toUri())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(FetchServiceNowResponse.class)
				.block();

		log.debug("getBySnowId Response: {}", response);
		return response;
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public Map<String, Object> getByCustomSearchParams(String accountName, String site, String status, String category, String requestType, String createdBy, Integer size, Integer page) {
		log.debug("Entering getByCustomSearchParams.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(urlConfig.getSnowHost());
		builder.path(urlConfig.getSnowFacilityApiPath());
		builder.query(urlConfig.getSnowDefaultParams());
		builder.queryParam("company", accountName);
		builder.queryParam("category", REMOTE_HANDS_SERVICES);

		StringBuilder sysQuery = new StringBuilder();
		if (StringUtils.isNotBlank(category)) {
			sysQuery.append("subcategory").append("LIKE").append(snowMappingConfig.getApiCategory().get(category)).append("^");
		}
		if (StringUtils.isNotBlank(site)) {
			builder.queryParam("location", site);
		}
		if (StringUtils.isNotBlank(status)) {
			String stateIntVals = getStateIntVals(status);
			sysQuery.append("state").append("IN").append(stateIntVals).append("^");
		}
		builder.queryParam("sysparm_query", sysQuery.append(ORDERBYDESC_SYS_CREATED_ON).toString());
		if (StringUtils.isNotBlank(requestType)) {
			builder.queryParam("type", snowMappingConfig.getWorkType().get(requestType));
		}
		if (StringUtils.isNotBlank(createdBy)) {
			builder.queryParam("caller", createdBy);
		}
		builder.queryParam("sysparm_count", "true");
		builder.queryParam("sysparm_limit", size);
		builder.queryParam("sysparm_offset", page*size);

		log.debug("getByCustomSearchParams URL: {}", builder.build().toUriString());
		Map<String, Object> responseMap = new HashMap<>();
		FetchServiceNowResponse respBody = webClient.get()
				.uri(builder.build().toUri())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.exchangeToMono(response -> {
					if (response.statusCode().is2xxSuccessful()) {
						responseMap.put("totalCount", response.headers().header("X-Total-Count").stream().findFirst().isPresent() ? response.headers().header("X-Total-Count").stream().findFirst().get() : 0);
						return response.bodyToMono(FetchServiceNowResponse.class);
					} else if (response.statusCode().is5xxServerError()) {
						return Mono.error(new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR));
					}
					return Mono.error(new RuntimeException(response.statusCode().value() + " " + response.statusCode().getReasonPhrase()));
				})
				.block();

		log.debug("getByCustomSearchParams Response: {}", respBody);
		responseMap.put("respList", Objects.nonNull(respBody) ? respBody.getResult() : Collections.emptyList());
		return responseMap;
	}

	private String getStateIntVals(String status) {
		return String.join(",", snowMappingConfig.getApiStatus().get(status).stream().map(state -> snowMappingConfig.getSnowStatusInteger().get(state)).collect(Collectors.toList()));
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public CreateServiceNowResponse updateServiceNow(UpdateServiceNowRequest updateReq, String sysId) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(urlConfig.getSnowHost());
		builder.path(urlConfig.getSnowFacilityApiPath());
		builder.path("/" + sysId);
		builder.query(urlConfig.getSnowDefaultParams());

		log.debug("Edit/update servicenow ticket URL: {}", builder.build().toUriString());
		CreateServiceNowResponse response = webClient.put()
				.uri(builder.build().toUri())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(updateReq), UpdateServiceNowRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(CreateServiceNowResponse.class)
				.block();

		log.debug("Edit/update servicenow ticket Response - {}", response);
		return response;
	}

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public CancelServiceNowResponse cancelServiceNow(String cancelReason, String company, String number) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(urlConfig.getSnowHost());
		builder.path(urlConfig.getSnowCancelworkorderApiPath());
		builder.queryParam("company", company).queryParam("useremail", ContextUtility.getUserEmail())
				.queryParam("CancelReason", snowMappingConfig.getCancelReason().get(cancelReason))
				.queryParam("number", number);

		log.debug("Cancel servicenow ticket URL: {}", builder.build().toUriString());
		CancelServiceNowResponse response = webClient.post()
				.uri(builder.build().toUri())
				.headers(httpHeaders -> httpHeaders.setBearerAuth(snowAuthService.getAccessToken()))
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR)))
				.bodyToMono(CancelServiceNowResponse.class)
				.block();

		log.debug("Cancel servicenow ticket Response - {}", response);
		return response;
	}

}
