package com.digitalrealty.gapi.remotehands.enums;

public enum ApiStatus {
	NEW("New"),
	IN_PROGRESS("In Progress"),
	COMPLETED("Completed"),
	CANCELLED("Cancelled");

	private String status;
	
	ApiStatus(String value) {
		this.status = value;
	}
	
	public String getStatus() {
		return status;
	}
}
