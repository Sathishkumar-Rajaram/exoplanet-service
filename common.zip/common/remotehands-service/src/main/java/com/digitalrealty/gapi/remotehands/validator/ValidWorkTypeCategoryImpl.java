package com.digitalrealty.gapi.remotehands.validator;

import java.util.Objects;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.BeanWrapperImpl;
import org.springframework.stereotype.Component;

import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;
import com.digitalrealty.gapi.remotehands.enums.WorkType;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class ValidWorkTypeCategoryImpl implements ConstraintValidator<ValidWorkTypeCategory, Object>  {

	private final SnowMappingConfig snowMappingConfig;
	private String categoryField;
	private String workTypeField;

	@Override
	public void initialize(ValidWorkTypeCategory constraintAnnotation) {
		this.categoryField = constraintAnnotation.categoryField();
		this.workTypeField = constraintAnnotation.workTypeField();
	}
	
	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		String category = (String) new BeanWrapperImpl(value).getPropertyValue(categoryField);
		String workType = (String) new BeanWrapperImpl(value).getPropertyValue(workTypeField);
		
		if (Objects.isNull(workType) || Objects.isNull(category)) {
			return true;
		} else if (WorkType.PLANNED_WORK.getWorkType().equalsIgnoreCase(workType)) {
			return snowMappingConfig.getPlannedCategory().contains(category);
		} else {
			return snowMappingConfig.getUrgentCategory().contains(category);
		}
	}

}
