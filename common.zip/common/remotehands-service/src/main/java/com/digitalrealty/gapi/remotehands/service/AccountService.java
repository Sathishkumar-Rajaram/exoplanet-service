package com.digitalrealty.gapi.remotehands.service;

import java.text.MessageFormat;

import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalrealty.gapi.common.context.ContextHeaders;
import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.CommonExceptionUtil;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.remotehands.config.URLConfig;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
@Service
@Slf4j
public class AccountService {

	private final WebClient webClient;

	private final URLConfig urlConfig;

	private final RedisCacheService redisCacheService;

	private final JwtConfig jwtConfig;

	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public String getCompanyName() {
		log.debug("Entering getCompanyName.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(urlConfig.getAccountServiceUrl());
		builder.path(MessageFormat.format(urlConfig.getAccountServiceCompanyNamePath(), ContextUtility.getLegalEntity()));

		log.debug("getCompanyName URL: {}", builder.build().toUriString());
		String response = webClient.get()
				.uri(builder.build().toUri())
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(),ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(String.class)
				.block();

		log.debug("Account service get Company Name Response: {}", response);
		return response;
	}
}
