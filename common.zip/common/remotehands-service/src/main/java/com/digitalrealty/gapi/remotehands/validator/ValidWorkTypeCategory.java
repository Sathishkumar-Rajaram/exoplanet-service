package com.digitalrealty.gapi.remotehands.validator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Target({ ElementType.TYPE, ElementType.FIELD, ElementType.ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = ValidWorkTypeCategoryImpl.class)
public @interface ValidWorkTypeCategory {
	String message() default "category and requestType values don't match";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

	String workTypeField();

	String categoryField();
}
