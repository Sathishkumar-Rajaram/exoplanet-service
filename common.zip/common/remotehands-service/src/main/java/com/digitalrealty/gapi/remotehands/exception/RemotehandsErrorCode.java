package com.digitalrealty.gapi.remotehands.exception;


import com.digitalrealty.gapi.common.exceptions.ErrorCode;

public class RemotehandsErrorCode {
	private RemotehandsErrorCode() {}
	
	public static final ErrorCode SNOW_DOWNSTREAM_ERROR = new ErrorCode("SNOW_DOWNSTREAM_ERROR", "SNOW error. System Error", 500, false);
	
	public static final ErrorCode MISSING_TITLE = new ErrorCode("MISSING_TITLE", "Mandatory payload 'title' is null or empty.", 400, false);
	public static final ErrorCode MISSING_SITE = new ErrorCode("MISSING_SITE", "Mandatory payload 'site' is null or empty.", 400, false);
	public static final ErrorCode MISSING_DETAILED_INSTRUCTION = new ErrorCode("MISSING_DETAILED_INSTRUCTION", "Mandatory payload 'detailedInstruction' is null or empty.", 400, false);
	public static final ErrorCode MISSING_CATEGORY = new ErrorCode("MISSING_CATEGORY", "Mandatory payload 'category' is null or empty.", 400, false);
	public static final ErrorCode MISSING_REQUESTTYPE = new ErrorCode("MISSING_REQUESTTYPE", "Mandatory payload 'requestType' is null or empty.", 400, false);
	
	public static final ErrorCode INVALID_CATEGORY = new ErrorCode("INVALID_CATEGORY", "Mandatory payload 'category' has an invalid value.", 400, false);
	public static final ErrorCode INVALID_REQUESTTYPE = new ErrorCode("INVALID_REQUESTTYPE", "Mandatory payload 'requestType' has an invalid value.", 400, false);
	public static final ErrorCode INVALID_NOTIFICATION_RECIPIENTS = new ErrorCode("INVALID_NOTIFICATION_RECIPIENTS", "Payload 'notificationRecipients' has an invalid email.", 400, false);
	public static final ErrorCode INVALID_SITE = new ErrorCode("INVALID_SITE", "Payload 'site' has to be '6' characters long.", 400, false);
	public static final ErrorCode MISMATCH_CATEGORY_REQUESTTYPE = new ErrorCode("MISMATCH_CATEGORY_REQUESTTYPE", "Payload 'category' has an unexpected value for the given 'requestType'", 400, false);
	public static final ErrorCode SITE_CODE_NOT_EXIST= new ErrorCode("SITE_CODE_NOT_EXIST", "Payload 'site' was not found.", 400, false);
	
	public static final ErrorCode REQUEST_ID_INVALID = new ErrorCode("REQUEST_ID_INVALID", "The requested resource was not found.", 404, false);

	public static final ErrorCode INVALID_QPARAM_STATUS = new ErrorCode("INVALID_QPARAM_STATUS", "Query parameter 'status' has an unexpected value.", 400, false);
	public static final ErrorCode INVALID_QPARAM_CATEGORY = new ErrorCode("INVALID_QPARAM_CATEGORY", "Query parameter 'category' has an unexpected value.", 400, false);
	public static final ErrorCode INVALID_QPARAM_REQUESTTYPE = new ErrorCode("INVALID_QPARAM_REQUESTTYPE", "Query parameter 'requestType' has an unexpected value.", 400, false);
	public static final ErrorCode INVALID_QPARAM_CREATEDBY = new ErrorCode("INVALID_QPARAM_CREATEDBY", "Query parameter 'createdBy' has an invalid email.", 400, false);
	public static final ErrorCode INVALID_QPARAM_SITE = new ErrorCode("INVALID_QPARAM_SITE", "Query parameter 'site' has to be '6' characters long.", 400, false);
	public static final ErrorCode QPARAM_SITE_NOT_EXIST = new ErrorCode("QPARAM_SITE_NOT_EXIST", "Query parameter 'site' was not found.", 400, false);
	public static final ErrorCode INVALID_QPARAM_SIZE = new ErrorCode("INVALID_QPARAM_SIZE", "Query parameter 'size' has to be between '1' and '1000'.", 400, false);
	public static final ErrorCode INVALID_QPARAM_PAGE = new ErrorCode("INVALID_QPARAM_PAGE", "Query parameter 'page' has to be started from '0'.", 400, false);
	
	public static final ErrorCode INVALID_CANCEL_REASON = new ErrorCode("INVALID_CANCEL_REASON", "Mandatory payload 'cancelReason' has an invalid value.", 400, false);

	public static final ErrorCode UPDATE_NOT_ALLOWED = new ErrorCode("UPDATE_NOT_ALLOWED", "This operation is not allowed since 'status' is not in New, In Progress", 400, false);
	public static final ErrorCode CANCEL_NOT_ALLOWED = new ErrorCode("CANCEL_NOT_ALLOWED", "This operation is not allowed since 'status' is not in New", 400, false);

	public static final ErrorCode SITE_CODE_NOT_CONFIGURED = new ErrorCode("SITE_CODE_NOT_CONFIGURED", "Site code is not configured in asset-service", 500, true);

}
