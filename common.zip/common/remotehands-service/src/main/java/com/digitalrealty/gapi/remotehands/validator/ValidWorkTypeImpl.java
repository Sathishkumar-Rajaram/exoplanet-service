package com.digitalrealty.gapi.remotehands.validator;

import java.util.Objects;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.stereotype.Component;

import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class ValidWorkTypeImpl implements ConstraintValidator<ValidWorkType, String> {

	private final SnowMappingConfig snowMappingConfig;
	
	@Override
	public boolean isValid(String type, ConstraintValidatorContext context) {
		return Objects.isNull(type) || snowMappingConfig.getWorkType().containsKey(type);
	}
	
}
