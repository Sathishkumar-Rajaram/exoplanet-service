package com.digitalrealty.gapi.remotehands;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.security.servlet.ManagementWebSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.aws.autoconfigure.context.ContextInstanceDataAutoConfiguration;
import org.springframework.cloud.aws.autoconfigure.context.ContextRegionProviderAutoConfiguration;
import org.springframework.cloud.aws.autoconfigure.context.ContextStackAutoConfiguration;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.retry.annotation.EnableRetry;

import com.digitalrealty.gapi.common.context.EnableCommonContext;
import com.digitalrealty.gapi.common.exceptions.EnableCommonExceptions;

@EnableCommonExceptions
@EnableCommonContext
@EnableRetry
@EnableEurekaClient
@EnableCaching
@RefreshScope
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class, ContextStackAutoConfiguration.class, ContextRegionProviderAutoConfiguration.class, ContextInstanceDataAutoConfiguration.class, SecurityAutoConfiguration.class, ManagementWebSecurityAutoConfiguration.class })
@ComponentScan({ "com.digitalrealty.gapi.remotehands", "com.digitalrealty.gapi.common.context", "com.digitalrealty.gapi.common.exceptions", "com.digitalrealty.gapi.common.auth", "com.digitalrealty.gapi.common.jwt" })
public class RemoteHandsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RemoteHandsApplication.class, args);
	}

}
