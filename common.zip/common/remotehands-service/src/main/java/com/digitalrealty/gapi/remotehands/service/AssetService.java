package com.digitalrealty.gapi.remotehands.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalrealty.gapi.common.context.ContextHeaders;
import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.digitalrealty.gapi.remotehands.config.URLConfig;
import com.digitalrealty.gapi.remotehands.model.SiteCodeRequest;
import com.digitalrealty.gapi.remotehands.model.SiteCodeResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
@Service
@Slf4j
public class AssetService {

	private final WebClient webClient;

	private final URLConfig urlConfig;
	
	private final RedisCacheService redisCacheService;

	private final JwtConfig jwtConfig;
	
	@Retryable(value = CommonException.class, maxAttempts = 3, backoff = @Backoff(delay = 100))
	public List<SiteCodeResponse> getSiteCodes(SiteCodeRequest siteCodeRequest) {
		log.debug("Entering getSiteCodes.");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(urlConfig.getAssetServiceUrl());
		builder.path(urlConfig.getAssetServiceSiteCodesPath());

		log.debug("getSiteCodes URL: {}", builder.build().toUriString());
		List<SiteCodeResponse> response = webClient.post()
				.uri(builder.build().toUri())
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(),ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(siteCodeRequest), SiteCodeRequest.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR)))
				.bodyToMono(new ParameterizedTypeReference<List<SiteCodeResponse>>() {
				})
				.block();

		log.debug("Asset service site codes Response: {}", response);
		return response;
	}
}
