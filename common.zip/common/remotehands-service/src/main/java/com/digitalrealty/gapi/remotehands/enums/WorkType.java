package com.digitalrealty.gapi.remotehands.enums;

public enum WorkType {
	URGENT_WORK("Urgent Work"),
	PLANNED_WORK("Planned Work");

	private String type;
	
	WorkType(String value) {
		this.type = value;
	}
	
	public String getWorkType() {
		return type;
	}
}
