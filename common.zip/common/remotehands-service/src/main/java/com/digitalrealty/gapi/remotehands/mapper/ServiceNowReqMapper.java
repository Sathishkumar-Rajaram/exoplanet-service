package com.digitalrealty.gapi.remotehands.mapper;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowRequest;
import com.digitalrealty.gapi.remotehands.model.CreateRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.UpdateRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.UpdateServiceNowRequest;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true))
public interface ServiceNowReqMapper {
	
	@Mapping(target = "cmdbCi", source = "createRemoteHandsRequest.location")
	@Mapping(target = "location", source = "snowSiteCode")
	@Mapping(target = "category", constant="Remote Hands Services")
	@Mapping(target = "subcategory", expression = "java( snowMappingConfig.getApiCategory().get(createRemoteHandsRequest.getCategory()))")
	@Mapping(target = "type", expression = "java( snowMappingConfig.getWorkType().get(createRemoteHandsRequest.getRequestType()))")
	@Mapping(target = "description", source = "createRemoteHandsRequest.detailedInstruction")
	@Mapping(target = "shortDescription", source = "createRemoteHandsRequest.title")
	@Mapping(target = "UExternalSource", source = "contactType")
	@Mapping(target = "company", source = "accountId")
	@Mapping(target = "UCcNotificationsList", source = "createRemoteHandsRequest.notificationRecipients")
	@Mapping(target = "UExternalReferenceNumber", source = "createRemoteHandsRequest.customerReference")
	@Mapping(target = "UShippingTrackingNumber", source = "createRemoteHandsRequest.referenceTicket")
	@Mapping(target = "caller", source = "email")
	CreateServiceNowRequest createServiceNowReqMap(CreateRemoteHandsRequest createRemoteHandsRequest, String accountId, String snowSiteCode, String email, String contactType, SnowMappingConfig snowMappingConfig);
	
	@Mapping(target = "UCcNotificationsList", source = "updateRemoteHandsRequest.notificationRecipients")
	@Mapping(target = "UExternalReferenceNumber", source = "updateRemoteHandsRequest.customerReference")
	UpdateServiceNowRequest updateServiceNowReqMap(UpdateRemoteHandsRequest updateRemoteHandsRequest);
	
}
