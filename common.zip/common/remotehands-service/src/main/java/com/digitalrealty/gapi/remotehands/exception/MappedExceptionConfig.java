package com.digitalrealty.gapi.remotehands.exception;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.digitalrealty.gapi.common.exceptions.CommonExceptionsConfiguration;

@Configuration
public class MappedExceptionConfig {

	@Autowired
	CommonExceptionsConfiguration configuration;

	@PostConstruct
	public void init() {
		configuration.mapErrorCode("NotBlank.CreateRemoteHandsRequest.title", RemotehandsErrorCode.MISSING_TITLE);
		configuration.mapErrorCode("NotBlank.CreateRemoteHandsRequest.site", RemotehandsErrorCode.MISSING_SITE);
		configuration.mapErrorCode("NotBlank.CreateRemoteHandsRequest.category", RemotehandsErrorCode.MISSING_CATEGORY);
		configuration.mapErrorCode("NotBlank.CreateRemoteHandsRequest.requestType", RemotehandsErrorCode.MISSING_REQUESTTYPE);
		configuration.mapErrorCode("NotBlank.CreateRemoteHandsRequest.detailedInstruction", RemotehandsErrorCode.MISSING_DETAILED_INSTRUCTION);
		
		configuration.mapErrorCode("ValidCategory.CreateRemoteHandsRequest.category", RemotehandsErrorCode.INVALID_CATEGORY);
		configuration.mapErrorCode("ValidWorkType.CreateRemoteHandsRequest.requestType", RemotehandsErrorCode.INVALID_REQUESTTYPE);
		configuration.mapErrorCode("Pattern.CreateRemoteHandsRequest.notificationRecipients", RemotehandsErrorCode.INVALID_NOTIFICATION_RECIPIENTS);
		configuration.mapErrorCode("Size.CreateRemoteHandsRequest.site", RemotehandsErrorCode.INVALID_SITE);
		configuration.mapErrorCode("ValidWorkTypeCategory.createRemoteHandsRequest", RemotehandsErrorCode.MISMATCH_CATEGORY_REQUESTTYPE);
		
		configuration.mapErrorCode("getAllRemoteHandsWithFilter.status", RemotehandsErrorCode.INVALID_QPARAM_STATUS);
		configuration.mapErrorCode("getAllRemoteHandsWithFilter.category", RemotehandsErrorCode.INVALID_QPARAM_CATEGORY);
		configuration.mapErrorCode("getAllRemoteHandsWithFilter.requestType", RemotehandsErrorCode.INVALID_QPARAM_REQUESTTYPE);
		configuration.mapErrorCode("getAllRemoteHandsWithFilter.createdBy", RemotehandsErrorCode.INVALID_QPARAM_CREATEDBY);
		configuration.mapErrorCode("getAllRemoteHandsWithFilter.site", RemotehandsErrorCode.INVALID_QPARAM_SITE);
		configuration.mapErrorCode("getAllRemoteHandsWithFilter.size", RemotehandsErrorCode.INVALID_QPARAM_SIZE);
		configuration.mapErrorCode("getAllRemoteHandsWithFilter.page", RemotehandsErrorCode.INVALID_QPARAM_PAGE);
		
		configuration.mapErrorCode("Pattern.UpdateRemoteHandsRequest.notificationRecipients", RemotehandsErrorCode.INVALID_NOTIFICATION_RECIPIENTS);
		
		configuration.mapErrorCode("ValidCancelReason.CancelRemoteHandsRequest.cancelReason", RemotehandsErrorCode.INVALID_CANCEL_REASON);
		
	}
}
