package com.digitalrealty.gapi.remotehands.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.stereotype.Component;

import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class ValidCancelReasonImpl implements ConstraintValidator<ValidCancelReason, String>{
	private final SnowMappingConfig snowMappingConfig;

	@Override
	public boolean isValid(String cancelReason, ConstraintValidatorContext context) {
		return snowMappingConfig.getCancelReason().containsKey(cancelReason);
	}
}
