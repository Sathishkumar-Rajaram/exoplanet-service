package com.digitalrealty.gapi.remotehands.model;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Pattern.Flag;

import org.springframework.validation.annotation.Validated;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
public class UpdateRemoteHandsRequest {

	private String customerReference;
	@Schema(example = "notificationRecipients", description = "Identifies the legal email.")
	@Pattern(regexp = "\\w+@\\w+\\.\\w+(,\\s*\\w+@\\w+\\.\\w+)*", flags = Flag.CASE_INSENSITIVE)
	private String notificationRecipients;

}