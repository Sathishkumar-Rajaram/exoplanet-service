package com.digitalrealty.gapi.remotehands.validator;

import java.util.Objects;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.stereotype.Component;

import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class ValidStatusImpl implements ConstraintValidator<ValidStatus, String> {
	
	private final SnowMappingConfig snowMappingConfig;
	
	@Override
	public boolean isValid(String status, ConstraintValidatorContext context) {
		return Objects.isNull(status) || snowMappingConfig.getApiStatus().containsKey(status);
	}
}
