package com.digitalrealty.gapi.remotehands.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.NoArgsConstructor;

@Configuration
@NoArgsConstructor
@Data
@ConfigurationProperties(prefix = "actions")
public class Actions {
	
	private List<String> createRemotehandsTicket;
	private List<String> getRequestDetailsByServicenowId;
	private List<String> getAllRemoteHandsWithFilter;
	private List<String> cancelRemotehandsTicket;
	private List<String> updateEditedFieldsBySnowId;
	private List<String> remotehandsTicketCategories;

}
