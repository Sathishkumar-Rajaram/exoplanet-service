package com.digitalrealty.gapi.remotehands.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Pattern.Flag;
import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import com.digitalrealty.gapi.remotehands.validator.ValidCategory;
import com.digitalrealty.gapi.remotehands.validator.ValidWorkType;
import com.digitalrealty.gapi.remotehands.validator.ValidWorkTypeCategory;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@ValidWorkTypeCategory(categoryField = "category", workTypeField = "requestType")
public class CreateRemoteHandsRequest {

	@NotBlank
	private String title;
	@NotBlank @Size(min = 6, max = 6)
	private String site;
	private String location;
	@NotBlank @ValidCategory
	private String category;
	@NotBlank @ValidWorkType
	private String requestType;
	@NotBlank
	private String detailedInstruction;
	private String customerReference;
	private String referenceTicket;
	@Schema(example = "notificationRecipients", description = "Identifies the legal email.")
	@Pattern(regexp = "^(\\w+((-\\w+)|(\\.\\w+))*\\@[A-Za-z0-9]+((\\.|-)[A-Za-z0-9]+)*\\.[A-Za-z0-9]{2,4}\\s*?,?\\s*?)+$", flags = Flag.CASE_INSENSITIVE)
	private String notificationRecipients;

}