package com.digitalrealty.gapi.remotehands.mapper;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;
import com.digitalrealty.gapi.remotehands.model.Comment;
import com.digitalrealty.gapi.remotehands.model.RemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.SearchRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.SnowResult;

import io.micrometer.core.instrument.util.StringUtils;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true))
public interface ServiceNowRespMapper {
	
	@Mapping(source = "result.number", target = "id")
	@Mapping(source = "result.cmdbCi", target = "location")
	@Mapping(source = "masterSite", target = "site")
	@Mapping(target = "category", expression = "java( mapByValue(snowMappingConfig.getApiCategory(), result.getSubcategory()))")
	@Mapping(target = "requestType", expression = "java( mapByValue(snowMappingConfig.getWorkType(), result.getType()))")
	@Mapping(source = "result.description", target = "detailedInstruction")
	@Mapping(source = "result.shortDescription", target = "title")
	@Mapping(target = "cancelReason", expression = "java( mapByValue(snowMappingConfig.getCancelReason(), result.getUCancelCodes()))")
	@Mapping(source = "result.sysCreatedOn", target = "createdOn")
	@Mapping(source = "result.sysUpdatedOn", target = "updatedOn")
	@Mapping(source = "result.closedAt", target = "closedOn")
	@Mapping(source = "result.caller", target = "createdBy")
	@Mapping(source = "result.UCcNotificationsList", target = "notificationRecipients")
	@Mapping(source = "result.UExternalReferenceNumber", target = "customerReference")
	@Mapping(source = "result.UShippingTrackingNumber", target = "referenceTicket")
	@Mapping(target = "status", expression = "java( getApiStatus(snowMappingConfig.getApiStatus(), result.getState(), result.getSubstate()))")
	@Mapping(source = "commentList", target = "comments")
	RemoteHandsResponse remotehandsRespMap(SnowResult result, List<Comment> commentList, String masterSite, SnowMappingConfig snowMappingConfig);
	
	
	@Mapping(source = "result.number", target = "id")
	@Mapping(source = "result.shortDescription", target = "title")
	@Mapping(target = "status", expression = "java(getApiStatus(snowMappingConfig.getApiStatus(), result.getState(), result.getSubstate()))")
	@Mapping(source = "masterSite", target = "site")
	@Mapping(source = "result.cmdbCi", target = "location")
	@Mapping(target = "category", expression = "java( mapByValue(snowMappingConfig.getApiCategory(), result.getSubcategory()))")
	@Mapping(target = "requestType", expression = "java( mapByValue(snowMappingConfig.getWorkType(), result.getType()))")
	@Mapping(source = "result.sysCreatedOn", target = "createdOn")
	@Mapping(source = "result.sysUpdatedOn", target = "updatedOn")
	@Mapping(source = "result.closedAt", target = "closedOn")
	@Mapping(source = "result.caller", target = "createdBy")
	SearchRemoteHandsResponse remotehandsSearchRespMap(SnowResult result, String masterSite, SnowMappingConfig snowMappingConfig);
	
	default String mapByValue(Map<String, String> map, String searchVal) {
		Optional<String> key = map.entrySet().stream().filter(entry -> entry.getValue().equals(searchVal)).map(Map.Entry::getKey).findFirst();
		return key.isPresent() ? key.get() : null;
	}
	
	default String getApiStatus(Map<String, List<String>> apiStatus, String stateVal, String substateVal) {
		String searchValue = StringUtils.isNotBlank(substateVal) ? substateVal : stateVal;
		Optional<String> key = apiStatus.entrySet().stream().filter(entry -> entry.getValue().contains(searchValue)).map(Map.Entry::getKey).findFirst();
		return key.isPresent() ? key.get() : null;
	}
}
