package com.digitalrealty.gapi.remotehands.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FetchServiceNowResponse {

	private List<SnowResult> result;

}