package com.digitalrealty.gapi.remotehands.config;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@NoArgsConstructor
@Data
@ConfigurationProperties(prefix = "urls")
public class URLConfig {

	private String snowHost;
	private String snowFacilityApiPath;
	private String snowCancelworkorderApiPath;
	private String snowDefaultParams;
	private String commentServiceUrl;
	private String commentServicePath;
	private String accountServiceUrl;
	private String accountServiceCompanyNamePath;
	private String assetServiceUrl;
	private String assetServiceSiteCodesPath;
	private String snowPaginationDefaultLimit;
}
