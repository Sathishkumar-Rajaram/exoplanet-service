package com.digitalrealty.gapi.remotehands.controller;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Pattern.Flag;
import javax.validation.constraints.Size;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalrealty.gapi.common.context.ActionValidationRequest;
import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.context.PermissionService;
import com.digitalrealty.gapi.remotehands.config.Actions;
import com.digitalrealty.gapi.remotehands.model.CancelRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.CancelRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.CategoriesRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.CreateRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.RemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.SearchRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.UpdateRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.service.RemotehandsService;
import com.digitalrealty.gapi.remotehands.validator.ValidCategory;
import com.digitalrealty.gapi.remotehands.validator.ValidStatus;
import com.digitalrealty.gapi.remotehands.validator.ValidWorkType;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Validated
public class RemoteHandsController {

	public final Actions actions;

	private final PermissionService permissionService;

	private final RemotehandsService remoteHandsService;

	@PostMapping(value = "/remotehands-tickets", consumes = "application/json", produces = "application/json")
	public ResponseEntity<RemoteHandsResponse> createRemotehandsTicket(@Valid @RequestBody CreateRemoteHandsRequest createRemoteHandsRequest, @RequestHeader(value = "contact-type", required = false) String contactType) {
		permissionService.validateAction(new ActionValidationRequest(ContextUtility.getMethod(), actions.getCreateRemotehandsTicket()));
		return new ResponseEntity<>(remoteHandsService.createServiceNow(createRemoteHandsRequest, contactType), HttpStatus.CREATED);
	}

	@GetMapping(value = "/remotehands-tickets/{ticketId}", produces = { "application/json" })
	public RemoteHandsResponse getRequestDetailsByServicenowId(@PathVariable(value = "ticketId") String snowId) {
		permissionService.validateAction(new ActionValidationRequest(ContextUtility.getMethod(), actions.getGetRequestDetailsByServicenowId()));
		return remoteHandsService.getBySnowId(snowId);
	}

	@GetMapping(value = { "/remotehands-tickets", "/remotehands-tickets/" }, produces = { "application/json" })
	public Page<SearchRemoteHandsResponse> getAllRemoteHandsWithFilter(@Size(min = 6, max = 6) @RequestParam(value = "site", required = false) String site,
			@ValidStatus @RequestParam(value = "status", required = false) String status,
			@ValidCategory @RequestParam(value = "category", required = false) String category,
			@ValidWorkType @RequestParam(value = "requestType", required = false) String requestType,
			@Schema(example = "createdBy", description = "Identifies the legal email.")
			@Pattern(regexp = "^(\\w+((-\\w+)|(\\.\\w+))*\\@[A-Za-z0-9]+((\\.|-)[A-Za-z0-9]+)*\\.[A-Za-z0-9]{2,4}\\s*?,?\\s*?)+$", flags = Flag.CASE_INSENSITIVE) @RequestParam(value = "createdBy", required = false) String createdBy,
			@Min(1) @Max(1000) @RequestParam(value = "size", required = false, defaultValue = "${urls.snow-pagination-default-size}") Integer size,
			@Min(0) @RequestParam(value = "page", required = false, defaultValue = "0") Integer page) {
		permissionService.validateAction(new ActionValidationRequest(ContextUtility.getMethod(), actions.getGetAllRemoteHandsWithFilter()));
		return remoteHandsService.getByCustomSearchParams(site, status, category, requestType, createdBy, size, page);
	}

	@PutMapping(value = "/remotehands-tickets/{ticketId}", consumes = "application/json", produces = { "application/json" })
	public RemoteHandsResponse updateEditedFieldsBySnowId(@Valid @RequestBody UpdateRemoteHandsRequest updateRemotehandsRequest, @PathVariable(value = "ticketId") String snowId) {
		permissionService.validateAction(new ActionValidationRequest(ContextUtility.getMethod(), actions.getUpdateEditedFieldsBySnowId()));
		return remoteHandsService.updateBySnowId(updateRemotehandsRequest, snowId);
	}

	@PutMapping(value = "/remotehands-tickets/{ticketId}/cancel", consumes = "application/json", produces = { "application/json" })
	public CancelRemoteHandsResponse cancelRemotehandsTicket(@Valid @RequestBody CancelRemoteHandsRequest cancelRemotehandsRequest, @PathVariable(value = "ticketId") String snowId) {
		permissionService.validateAction(new ActionValidationRequest(ContextUtility.getMethod(), actions.getCancelRemotehandsTicket()));
		return remoteHandsService.cancelBySnowId(cancelRemotehandsRequest, snowId);
	}

	@GetMapping(value = "/remotehands-tickets/categories", produces = { "application/json" })
	public CategoriesRemoteHandsResponse remotehandsTicketCategories(@ValidWorkType @RequestParam(value = "requestType", required = false) String requestType) {
		permissionService.validateAction(new ActionValidationRequest(ContextUtility.getMethod(), actions.getRemotehandsTicketCategories()));
		return remoteHandsService.getCategories(requestType);
	}

}
