package com.digitalrealty.gapi.remotehands.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.auth.service.SnowAuthService;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.remotehands.exception.RemotehandsErrorCode;
import com.digitalrealty.gapi.remotehands.model.CancelServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowRequest;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.FetchServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.UpdateServiceNowRequest;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class SnowService {

	public static final String UNAUTHORIZED = "401";

	private final SnowServiceRetryable snowServiceRetryable;

	private final SnowAuthService snowAuthService;

	public CreateServiceNowResponse createServiceNow(CreateServiceNowRequest createServiceNow) {
		try {
			return snowServiceRetryable.createServiceNow(createServiceNow);
		} catch (Exception exception) {
			if (exception.getMessage() != null && exception.getMessage().contains(UNAUTHORIZED)) {
				snowAuthService.getAccessToken(true);
				return snowServiceRetryable.createServiceNow(createServiceNow);
			}
			throw new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR, exception);
		}
	}

	public FetchServiceNowResponse getBySnowId(String snowId, String accountName) {
		try {
			return snowServiceRetryable.getBySnowId(snowId, accountName);
		} catch (Exception exception) {
			if (exception.getMessage() != null && exception.getMessage().contains(UNAUTHORIZED)) {
				snowAuthService.getAccessToken(true);
				return snowServiceRetryable.getBySnowId(snowId, accountName);
			}
			throw new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR, exception);
		}
	}

	public Map<String, Object> getByCustomSearchParams(String accountName, String site, String status, String category, String requestType,
			String createdBy, Integer size, Integer page) {
		try {
			return snowServiceRetryable.getByCustomSearchParams(accountName, site, status, category, requestType, createdBy, size, page);
		} catch (Exception exception) {
			if (exception.getMessage() != null && exception.getMessage().contains(UNAUTHORIZED)) {
				snowAuthService.getAccessToken(true);
				return snowServiceRetryable.getByCustomSearchParams(accountName, site, status, category, requestType, createdBy, size, page);
			}
			throw new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR, exception);
		}
	}

	public CreateServiceNowResponse updateServiceNow(UpdateServiceNowRequest updateReq, String sysId) {
		try {
			return snowServiceRetryable.updateServiceNow(updateReq, sysId);
		} catch (Exception exception) {
			if (exception.getMessage() != null && exception.getMessage().contains(UNAUTHORIZED)) {
				snowAuthService.getAccessToken(true);
				return snowServiceRetryable.updateServiceNow(updateReq, sysId);
			}
			throw new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR, exception);
		}
	}

	public CancelServiceNowResponse cancelServiceNow(String cancelReason, String company, String number) {
		try {
			return snowServiceRetryable.cancelServiceNow(cancelReason, company, number);
		} catch (Exception exception) {
			if (exception.getMessage() != null && exception.getMessage().contains(UNAUTHORIZED)) {
				snowAuthService.getAccessToken(true);
				return snowServiceRetryable.cancelServiceNow(cancelReason, company, number );
			}
			throw new CommonException(RemotehandsErrorCode.SNOW_DOWNSTREAM_ERROR, exception);
		}
	}

}
