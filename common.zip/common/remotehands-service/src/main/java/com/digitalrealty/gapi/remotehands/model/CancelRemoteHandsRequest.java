package com.digitalrealty.gapi.remotehands.model;

import org.springframework.validation.annotation.Validated;

import com.digitalrealty.gapi.remotehands.validator.ValidCancelReason;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
public class CancelRemoteHandsRequest {

	@ValidCancelReason
	private String cancelReason;
}
