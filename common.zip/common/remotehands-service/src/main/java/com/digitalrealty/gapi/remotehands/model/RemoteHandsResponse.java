package com.digitalrealty.gapi.remotehands.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RemoteHandsResponse {

	private String id;
	private String title;
	private String status;
	private String site;
	private String location;
	private String requestType;
	private String category;
	private String detailedInstruction;
	private String customerReference;
	private String referenceTicket;
	private String cancelReason;
	private String createdOn;
	private String updatedOn;
	private String closedOn;
	private String createdBy;
	@Builder.Default
	private String ticketType="Remote Hands";
	private String notificationRecipients;
	private List<Comment> comments;

}