package com.digitalrealty.gapi.remotehands.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SearchRemoteHandsResponse {

	private String id;
	private String title;
	private String status;
	private String site;
	private String location;
	private String category;
	private String requestType;
	private String createdOn;
	private String updatedOn;
	private String closedOn;
	private String createdBy;

}