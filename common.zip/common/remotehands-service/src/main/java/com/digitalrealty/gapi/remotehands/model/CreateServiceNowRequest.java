package com.digitalrealty.gapi.remotehands.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateServiceNowRequest {

	@JsonProperty("location")
	private String location;
	@JsonProperty("cmdb_ci")
	private String cmdbCi;
	@JsonProperty("category")
	private String category;
	@JsonProperty("subcategory")
	private String subcategory;
	@JsonProperty("type")
	private String type;
	@JsonProperty("description")
	private String description;
	@JsonProperty("short_description")
	private String shortDescription;
	@JsonProperty("u_external_source")
	private String uExternalSource;
	@JsonProperty("company")
	private String company;
	@JsonProperty("u_cc_notifications_list")
	private String uCcNotificationsList;
	@JsonProperty("u_external_reference_number")
	private String uExternalReferenceNumber;
	@JsonProperty("u_shipping_tracking_number")
	private String uShippingTrackingNumber;
	@JsonProperty("caller")
	private String caller;

}