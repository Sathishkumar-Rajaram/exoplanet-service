package com.digitalrealty.gapi.remotehands.config;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@NoArgsConstructor
@Data
@ConfigurationProperties(prefix = "snow-mapping")
public class SnowMappingConfig {

	private List<String> urgentCategory;
	private List<String> plannedCategory;
	private Map<String, String> apiCategory;
	private Map<String, List<String>> apiStatus;
	private Map<String, String> snowStatusInteger;
	private Map<String, String> workType;
	private Map<String, String> cancelReason;
}
