package com.digitalrealty.gapi.remotehands.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;
import com.digitalrealty.gapi.remotehands.enums.ApiStatus;
import com.digitalrealty.gapi.remotehands.enums.WorkType;
import com.digitalrealty.gapi.remotehands.exception.RemotehandsErrorCode;
import com.digitalrealty.gapi.remotehands.mapper.ServiceNowReqMapper;
import com.digitalrealty.gapi.remotehands.mapper.ServiceNowRespMapper;
import com.digitalrealty.gapi.remotehands.model.CancelServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.Category;
import com.digitalrealty.gapi.remotehands.model.Comment;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowRequest;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.FetchServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.CancelRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.CancelRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.CategoriesRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.CreateRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.UpdateRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.RemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.SearchRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.SiteCodeRequest;
import com.digitalrealty.gapi.remotehands.model.SiteCodeResponse;
import com.digitalrealty.gapi.remotehands.model.RequestType;
import com.digitalrealty.gapi.remotehands.model.ResultCategory;
import com.digitalrealty.gapi.remotehands.model.SnowResult;
import com.digitalrealty.gapi.remotehands.model.UpdateServiceNowRequest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Service
@Slf4j
public class RemotehandsService {

	private static final String CANCEL_SUCCESS_MSG = "We have received your request for cancellation of workorder '%s'. We will be in contact shortly. Please be aware that fees might still apply to this request if work has already started.";

	private final SnowService snowService;

	private final AccountService accountService;

	private final CommentService commentService;
	
	private final AssetService assetService;

	private final ServiceNowReqMapper serviceNowReqMapper;

	private final ServiceNowRespMapper serviceNowRespMapper;

	private final SnowMappingConfig snowMappingConfig;

	public RemoteHandsResponse createServiceNow(CreateRemoteHandsRequest createServiceNow, String contactType) {
		String accountName = accountService.getCompanyName();
		String snowSiteCode = getSnowSiteCode(createServiceNow.getSite(), false);
		CreateServiceNowRequest snowReq = serviceNowReqMapper.createServiceNowReqMap(createServiceNow, accountName, snowSiteCode, ContextUtility.getUserEmail(), contactType, snowMappingConfig);
		return serviceNowRespMapper.remotehandsRespMap(snowService.createServiceNow(snowReq).getResult(), null, createServiceNow.getSite(), snowMappingConfig);
	}

	public RemoteHandsResponse getBySnowId(String snowId) {
		String accountName = accountService.getCompanyName();
		List<Comment> commentList = commentService.getComment(snowId);
		FetchServiceNowResponse fetchResult = snowService.getBySnowId(snowId, accountName);
		if (fetchResult.getResult().isEmpty()) {
			log.debug("fetch result is empty for {} hence not found", snowId);
			throw new CommonException(RemotehandsErrorCode.REQUEST_ID_INVALID);
		}
		
		String masterSiteCode = getApiSiteCode(fetchResult.getResult().get(0).getLocation());
		return serviceNowRespMapper.remotehandsRespMap(fetchResult.getResult().get(0), commentList, masterSiteCode, snowMappingConfig);
	}

	public Page<SearchRemoteHandsResponse> getByCustomSearchParams(String site, String status, String category, String requestType, String createdBy, Integer size, Integer page) {
		String accountName = accountService.getCompanyName();
		
		String siteCode = null;
		if(StringUtils.isNotBlank(site)) {
			siteCode = getSnowSiteCode(site, true);
		}

		Map<String, Object> fetchResp = snowService.getByCustomSearchParams(accountName, siteCode, status, category, requestType, createdBy, size, page);
		List<SnowResult> snowResult = (List<SnowResult>) fetchResp.get("respList");
		List<SearchRemoteHandsResponse> rhSearchRespList = snowResult.stream().map(result -> {
			return serviceNowRespMapper.remotehandsSearchRespMap(result, getApiSiteCode(result.getLocation()), snowMappingConfig);
		}).collect(Collectors.toList());
		
		Pageable pageable = PageRequest.of(page, size);
		return new PageImpl<>(rhSearchRespList, pageable, Long.parseLong((String) fetchResp.get("totalCount")));
	}

	public RemoteHandsResponse updateBySnowId(UpdateRemoteHandsRequest updateRemotehands, String snowId) {
		String accountName = accountService.getCompanyName();

		FetchServiceNowResponse fetchResult = snowService.getBySnowId(snowId, accountName);
		if (fetchResult.getResult().isEmpty()) {
			log.debug("fetch result is empty for {} hence not found", snowId);
			throw new CommonException(RemotehandsErrorCode.REQUEST_ID_INVALID);
		}

		SnowResult result = fetchResult.getResult().get(0);
		if (Objects.nonNull(result) && (snowMappingConfig.getApiStatus().get(ApiStatus.NEW.getStatus()).contains(result.getState()) ||
				snowMappingConfig.getApiStatus().get(ApiStatus.IN_PROGRESS.getStatus()).contains(result.getState()))) {
			List<Comment> commentList = commentService.getComment(snowId);
			UpdateServiceNowRequest updateReq = serviceNowReqMapper.updateServiceNowReqMap(updateRemotehands);
			CreateServiceNowResponse updateResp =  snowService.updateServiceNow(updateReq, result.getSysId());
			
			String masterSiteCode = getApiSiteCode(updateResp.getResult().getLocation());
			return serviceNowRespMapper.remotehandsRespMap(updateResp.getResult(), commentList, masterSiteCode, snowMappingConfig);
		}
		log.error("Update operation is not allowed for {} as its not in New/In Progress state", snowId);
		throw new CommonException(RemotehandsErrorCode.UPDATE_NOT_ALLOWED);

	}

	public CancelRemoteHandsResponse cancelBySnowId(CancelRemoteHandsRequest cancelRemotehands, String snowId) {
		String accountName = accountService.getCompanyName();

		FetchServiceNowResponse fetchResult = snowService.getBySnowId(snowId, accountName);
		if (fetchResult.getResult().isEmpty()) {
			log.debug("fetch result is empty for {} hence not found", snowId);
			throw new CommonException(RemotehandsErrorCode.REQUEST_ID_INVALID);
		}

		SnowResult result = fetchResult.getResult().get(0);
		if (!Objects.nonNull(result) || !snowMappingConfig.getApiStatus().get(ApiStatus.NEW.getStatus()).contains(result.getState())) {
			log.error("Cancel operation is not allowed for {} as its not in New state", snowId);
			throw new CommonException(RemotehandsErrorCode.CANCEL_NOT_ALLOWED);
		}
		CancelServiceNowResponse response = snowService.cancelServiceNow(cancelRemotehands.getCancelReason(), result.getCompany(), result.getNumber());
		if (Objects.nonNull(response) && Objects.nonNull(response.getResult()) && Objects.nonNull(response.getResult().getStatus())) {
			String message = String.format(CANCEL_SUCCESS_MSG, snowId);
			return CancelRemoteHandsResponse.builder().message(message).build();
		}
		return null;
	}

	public CategoriesRemoteHandsResponse getCategories(String requestType) {
		CategoriesRemoteHandsResponse resp = new CategoriesRemoteHandsResponse();
		List<ResultCategory> resultCategory = new ArrayList<>();

		if (StringUtils.isBlank(requestType) || WorkType.PLANNED_WORK.getWorkType().equalsIgnoreCase(requestType)) {
			RequestType reqType = new RequestType();
			ResultCategory resCategory = new ResultCategory();
			reqType.setCategories(snowMappingConfig.getPlannedCategory().stream().map(pc -> {
				Category cat = new Category();
				cat.setName(pc);
				return cat;
			}).collect(Collectors.toList()));
			reqType.setName(WorkType.PLANNED_WORK.getWorkType());
			resCategory.setRequestType(reqType);
			resultCategory.add(resCategory);
		}
		if (StringUtils.isBlank(requestType) || WorkType.URGENT_WORK.getWorkType().equalsIgnoreCase(requestType)) {
			RequestType reqType = new RequestType();
			ResultCategory resCategory = new ResultCategory();
			reqType.setCategories(snowMappingConfig.getUrgentCategory().stream().map(uc -> {
				Category cat = new Category();
				cat.setName(uc);
				return cat;
			}).collect(Collectors.toList()));
			reqType.setName(WorkType.URGENT_WORK.getWorkType());
			resCategory.setRequestType(reqType);
			resultCategory.add(resCategory);
		}

		resp.setResult(resultCategory);
		return resp;
	}
	
	private String getSnowSiteCode(String apiSiteCode, boolean isQueryParam) {
		SiteCodeRequest siteCodeRequest = SiteCodeRequest.builder().masterSiteCodes(Arrays.asList(apiSiteCode)).build();
		Optional<String> snowSiteCode = assetService.getSiteCodes(siteCodeRequest).stream().filter(sc -> apiSiteCode.equalsIgnoreCase(sc.getMasterSiteCode())).map(SiteCodeResponse::getOperationalSiteCode).findFirst();
		if(snowSiteCode.isEmpty()) {
			throw new CommonException(!isQueryParam ? RemotehandsErrorCode.SITE_CODE_NOT_EXIST : RemotehandsErrorCode.QPARAM_SITE_NOT_EXIST);
		}
		return snowSiteCode.get();
	}
	
	private String getApiSiteCode(String operationalSiteCode) {
		SiteCodeRequest siteCodeRequest = SiteCodeRequest.builder().operationalSiteCodes(Arrays.asList(operationalSiteCode)).build();
		Optional<String> masterSiteCode = assetService.getSiteCodes(siteCodeRequest).stream().filter(sc -> operationalSiteCode.equalsIgnoreCase(sc.getOperationalSiteCode())).map(SiteCodeResponse::getMasterSiteCode).findFirst();
		if(masterSiteCode.isEmpty() && StringUtils.isNotBlank(operationalSiteCode)) {
			log.error("No master site code found for {}", operationalSiteCode, new CommonException(RemotehandsErrorCode.SITE_CODE_NOT_CONFIGURED));
		}
		return masterSiteCode.isPresent() ? masterSiteCode.get() : null;
	}

}
