package com.digitalrealty.gapi.remotehands.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SnowResult {

	@JsonProperty("sys_updated_on")
	private String sysUpdatedOn;
	@JsonProperty("sys_created_by")
	private String sysCreatedBy;
	@JsonProperty("u_date")
	private String uDate;
	@JsonProperty("u_cc_notifications_list")
	private String uCcNotificationsList;
	@JsonProperty("u_external_reference_number")
	private String uExternalReferenceNumber;
	@JsonProperty("u_shipping_tracking_number")
	private String uShippingTrackingNumber;
	@JsonProperty("u_external_source")
	private String uExternalSource;
	@JsonProperty("request_category")
	private String requestCategory;
	@JsonProperty("sys_created_on")
	private String sysCreatedOn;
	@JsonProperty("closed_at")
	private String closedAt;
	@JsonProperty("subcategory")
	private String subcategory;
	@JsonProperty("description")
	private String description;
	@JsonProperty("sys_id")
	private String sysId;
	@JsonProperty("company")
	private String company;
	@JsonProperty("location")
	private String location;
	@JsonProperty("type")
	private String type;
	@JsonProperty("expected_end")
	private String expectedEnd;
	@JsonProperty("number")
	private String number;
	@JsonProperty("cmdb_ci")
	private String cmdbCi;
	@JsonProperty("short_description")
	private String shortDescription;
	@JsonProperty("work_start")
	private String workStart;
	@JsonProperty("request_type")
	private String requestType;
	@JsonProperty("closed_by")
	private String closedBy;
	@JsonProperty("sys_updated_by")
	private String sysUpdatedBy;
	@JsonProperty("opened_by")
	private String openedBy;
	@JsonProperty("expected_start")
	private String expectedStart;
	@JsonProperty("opened_at")
	private String openedAt;
	@JsonProperty("caller")
	private String caller;
	@JsonProperty("category")
	private String category;
	@JsonProperty("user")
	private String user;
	@JsonProperty("u_cancel_codes")
	private String uCancelCodes;
	@JsonProperty("state")
	private String state;
	@JsonProperty("substate")
	private String substate;
	

}