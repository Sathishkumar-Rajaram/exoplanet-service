package com.digitalrealty.gapi.remotehands.validator;

import java.util.Objects;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.stereotype.Component;

import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class ValidCategoryImpl implements ConstraintValidator<ValidCategory, String> {

	private final SnowMappingConfig snowMappingConfig;

	@Override
	public boolean isValid(String category, ConstraintValidatorContext context) {
		return Objects.isNull(category) || snowMappingConfig.getPlannedCategory().contains(category)
				|| snowMappingConfig.getUrgentCategory().contains(category);
	}

}
