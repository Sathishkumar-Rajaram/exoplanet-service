package com.digitalrealty.gapi.remotehands.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.TestPropertySource;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;
import com.digitalrealty.gapi.remotehands.enums.WorkType;
import com.digitalrealty.gapi.remotehands.mapper.ServiceNowReqMapper;
import com.digitalrealty.gapi.remotehands.mapper.ServiceNowRespMapper;
import com.digitalrealty.gapi.remotehands.model.CategoriesRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.FetchServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.SiteCodeResponse;
import com.digitalrealty.gapi.remotehands.model.SnowResult;

@ExtendWith(MockitoExtension.class)
@TestPropertySource(locations = {"classpath:application-test.yml"})
public class RemotehandsServiceTest {
	
	@Mock
	private SnowService snowService;

	@Mock
	private AccountService accountService;

	@Mock
	private CommentService commentService;
	
	@Mock
	private AssetService assetService;
	
	@Mock
	private ServiceNowReqMapper serviceNowReqMapper;
	
	@Mock
	private ServiceNowRespMapper serviceNowRespMapper;

	@Mock
	private SnowMappingConfig snowMappingConfig;
	
	@InjectMocks
	private RemotehandsService remotehandsService;
	
	@Test
	void createServiceNowTest() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(assetService.getSiteCodes(Mockito.any())).thenReturn(List.of(TestConfiguration.getSiteCodeResponse()));
		when(snowService.createServiceNow(Mockito.any())).thenReturn(TestConfiguration.getCreateServiceNowResponse());
		remotehandsService.createServiceNow(TestConfiguration.getRemoteHandsPostReq(), "Global Portal");
		
		verify(snowService, times(1)).createServiceNow(null);
		
	}
	
	@Test
	void createServiceNowTestForSiteCodeNotExist() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(assetService.getSiteCodes(Mockito.any())).thenReturn(List.of(SiteCodeResponse.builder().build()));
		Exception exception =  assertThrows(CommonException.class, () -> {
			remotehandsService.createServiceNow(TestConfiguration.getRemoteHandsPostReq(), "Global Portal");
		});
		assertThat(exception.getMessage()).contains("site");
	}
	
	@Test
	void getBySnowIdTest() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(commentService.getComment(TestConfiguration.TICKET_ID)).thenReturn(List.of(TestConfiguration.getComment()));
		when(snowService.getBySnowId(Mockito.anyString(), Mockito.anyString())).thenReturn(TestConfiguration.getFetchServiceNowResponse());
		when(assetService.getSiteCodes(Mockito.any())).thenReturn(List.of(TestConfiguration.getSiteCodeResponse()));

		remotehandsService.getBySnowId(TestConfiguration.TICKET_ID);
		
		verify(snowService, times(1)).getBySnowId(TestConfiguration.TICKET_ID,TestConfiguration.ACCOUNT_NEAME);
	}
	
	@Test
	void getBySnowIdTestForRequestIdNotFound() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(snowService.getBySnowId(Mockito.anyString(), Mockito.anyString())).thenReturn(FetchServiceNowResponse.builder().result(Collections.emptyList()).build());
		
		Exception exception =  assertThrows(CommonException.class, () -> {
			remotehandsService.getBySnowId(TestConfiguration.TICKET_ID);
		});
		assertThat(exception.getMessage()).contains("REQUEST_ID_INVALID");
	}
	
	@Test
	void updateBySnowIdTest() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(snowService.getBySnowId(Mockito.anyString(), Mockito.anyString())).thenReturn(TestConfiguration.getFetchServiceNowResponse());
		when(snowMappingConfig.getApiStatus()).thenReturn(Map.of("New", List.of("New","In Progress")));
		when(assetService.getSiteCodes(Mockito.any())).thenReturn(List.of(TestConfiguration.getSiteCodeResponse()));
		when(snowService.updateServiceNow(Mockito.any(), Mockito.any())).thenReturn(TestConfiguration.getCreateServiceNowResponse());

		remotehandsService.updateBySnowId(TestConfiguration.getUpdateRemoteHandsRequest(), TestConfiguration.TICKET_ID);
		verify(snowService, times(1)).updateServiceNow(null,null);
	}
	
	@Test
	void updateBySnowIdTestForRequestIdNotFound() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(snowService.getBySnowId(Mockito.anyString(), Mockito.anyString())).thenReturn(FetchServiceNowResponse.builder().result(Collections.emptyList()).build());
		
		Exception exception =  assertThrows(CommonException.class, () -> {
			remotehandsService.updateBySnowId(TestConfiguration.getUpdateRemoteHandsRequest(), TestConfiguration.TICKET_ID);
		});
		assertThat(exception.getMessage()).contains("REQUEST_ID_INVALID");
	}
	
	@Test
	void updateBySnowIdTestForInvalidState() {
		SnowResult snowResult = TestConfiguration.getFetchServiceNowResponse().getResult().get(0);
		snowResult.setState("Cancelled");
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(snowService.getBySnowId(Mockito.anyString(), Mockito.anyString())).thenReturn(FetchServiceNowResponse.builder().result(List.of(snowResult)).build());
		when(snowMappingConfig.getApiStatus()).thenReturn(Map.of("Cancelled", List.of("Cancelled","Cancelled Complete"), "New", List.of("New","Draft"), "In Progress", List.of("In Progress")));
		
		Exception exception =  assertThrows(CommonException.class, () -> {
			remotehandsService.updateBySnowId(TestConfiguration.getUpdateRemoteHandsRequest(), TestConfiguration.TICKET_ID);
		});
		assertThat(exception.getMessage()).contains("UPDATE_NOT_ALLOWED");
	}
	
	@Test
	void getByCustomSearchParamsTest() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(assetService.getSiteCodes(Mockito.any())).thenReturn(List.of(TestConfiguration.getSiteCodeResponse()));
		when(snowService.getByCustomSearchParams(TestConfiguration.ACCOUNT_NEAME, TestConfiguration.OP_SITE, "New", null, null, null, 1, 1))
			.thenReturn(Map.of("respList", TestConfiguration.getFetchServiceNowResponse().getResult(), "totalCount", "20"));
		remotehandsService.getByCustomSearchParams(TestConfiguration.MASTER_SITE, "New", null, null, null, 1, 1);
		verify(snowService, times(1)).getByCustomSearchParams(TestConfiguration.ACCOUNT_NEAME, TestConfiguration.OP_SITE, "New", null, null, null, 1, 1);
	}
	
	@Test
	void getByCustomSearchParamsTestForInvalidSite() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(assetService.getSiteCodes(Mockito.any())).thenReturn(List.of(TestConfiguration.getSiteCodeResponse()));
		
		Exception exception =  assertThrows(CommonException.class, () -> {
			remotehandsService.getByCustomSearchParams("Invalid site", "New", null, null, null, 1, 1);
		});
		assertThat(exception.getMessage()).contains("QPARAM_SITE_NOT_EXIST");
	}
	
	@Test
	void cancelBySnowIdTest() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(snowService.getBySnowId(Mockito.anyString(), Mockito.anyString())).thenReturn(TestConfiguration.getFetchServiceNowResponse());
		when(snowMappingConfig.getApiStatus()).thenReturn(Map.of("New", List.of("New","In Progress")));

		remotehandsService.cancelBySnowId(TestConfiguration.getRemoteHandsCancelReq(), TestConfiguration.TICKET_ID);
		verify(snowService, times(1)).cancelServiceNow("Duplicate request", TestConfiguration.ACCOUNT_NEAME, TestConfiguration.TICKET_ID);
	}
	
	@Test
	void cancelBySnowIdTestForRequestIdNotFound() {
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(snowService.getBySnowId(Mockito.anyString(), Mockito.anyString())).thenReturn(FetchServiceNowResponse.builder().result(Collections.emptyList()).build());
		
		Exception exception =  assertThrows(CommonException.class, () -> {
			remotehandsService.cancelBySnowId(TestConfiguration.getRemoteHandsCancelReq(), TestConfiguration.TICKET_ID);
		});
		assertThat(exception.getMessage()).contains("REQUEST_ID_INVALID");
	}
	
	@Test
	void cancelBySnowIdTestForInvalidState() {
		SnowResult snowResult = TestConfiguration.getFetchServiceNowResponse().getResult().get(0);
		snowResult.setState("Cancelled");
		when(accountService.getCompanyName()).thenReturn(TestConfiguration.ACCOUNT_NEAME);
		when(snowService.getBySnowId(Mockito.anyString(), Mockito.anyString())).thenReturn(FetchServiceNowResponse.builder().result(List.of(snowResult)).build());
		when(snowMappingConfig.getApiStatus()).thenReturn(Map.of("Cancelled", List.of("Cancelled","Cancelled Complete"), "New", List.of("New","Draft"), "In Progress", List.of("In Progress")));
		
		Exception exception =  assertThrows(CommonException.class, () -> {
			remotehandsService.cancelBySnowId(TestConfiguration.getRemoteHandsCancelReq(), TestConfiguration.TICKET_ID);
		});
		assertThat(exception.getMessage()).contains("CANCEL_NOT_ALLOWED");
	}
	
	@Test
	void getCategoriesTest() {
		when(snowMappingConfig.getPlannedCategory()).thenReturn(List.of("test 1","test 2"));
		when(snowMappingConfig.getUrgentCategory()).thenReturn(List.of("test 3","test 4"));
		
		CategoriesRemoteHandsResponse response = remotehandsService.getCategories(null);
		String workType = response.getResult().get(0).getRequestType().getName();
		assertThat(workType.equalsIgnoreCase(WorkType.PLANNED_WORK.getWorkType()) 
				|| workType.equalsIgnoreCase(WorkType.URGENT_WORK.getWorkType()));
	}

}
