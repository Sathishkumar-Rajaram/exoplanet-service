package com.digitalrealty.gapi.remotehands.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.spy;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;
import com.digitalrealty.gapi.remotehands.enums.ApiStatus;
import com.digitalrealty.gapi.remotehands.model.RemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.SearchRemoteHandsResponse;

@ExtendWith(MockitoExtension.class)
public class ServiceNowRespMapperTest {

	@Mock
	SnowMappingConfig SnowMappingConfig;
	
	@InjectMocks
	ServiceNowRespMapper serviceNowRespMapper = Mappers.getMapper(ServiceNowRespMapper.class);
	
	@Test
	void remotehandsRespMapTest() {
		RemoteHandsResponse response = serviceNowRespMapper.remotehandsRespMap(TestConfiguration.getCreateServiceNowResponse().getResult(), null, TestConfiguration.MASTER_SITE, SnowMappingConfig);
		assertThat(response.getSite()).isEqualTo(TestConfiguration.MASTER_SITE);
		assertThat(response.getComments()).isNull();
	}
	
	@Test
	void remotehandsSearchRespMapTest() {
		SearchRemoteHandsResponse response = serviceNowRespMapper.remotehandsSearchRespMap(TestConfiguration.getCreateServiceNowResponse().getResult(), TestConfiguration.MASTER_SITE, SnowMappingConfig);
		assertThat(response.getSite()).isEqualTo(TestConfiguration.MASTER_SITE);
	}
	
	@Test
	void mapByValueTest() {
		String testVal = serviceNowRespMapper.mapByValue(Map.of("test category", "test mapped category"), "test mapped category");
		assertThat(testVal).isEqualTo("test category");
	}
	
	@Test
	void getApiStatusForState(){
		String testVal = serviceNowRespMapper.getApiStatus(Map.of("test status", List.of("test mapped status")), "test mapped status", null);
		assertThat(testVal).isEqualTo("test status");
	}
	
	@Test
	void getApiStatusForSubState(){
		String testVal = serviceNowRespMapper.getApiStatus(Map.of("test status", List.of("test mapped status")), null, "test mapped status");
		assertThat(testVal).isEqualTo("test status");
	}
}
