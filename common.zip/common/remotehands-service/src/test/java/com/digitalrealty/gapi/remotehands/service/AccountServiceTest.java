package com.digitalrealty.gapi.remotehands.service;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.net.URI;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.config.URLConfig;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class AccountServiceTest {

	@Mock
	private WebClient webClient;

	@Mock
	WebClient.RequestBodyUriSpec requestBodyUriSpecMock;

	@Mock
	WebClient.RequestBodySpec requestBodySpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersMock;

	@Mock
	WebClient.ResponseSpec responseSpecMock;

	@Mock
	URLConfig urlConfig;

	@Mock
	RedisCacheService redisCacheService;

	@Mock
	JwtConfig jwtConfig;
	
	@InjectMocks
	AccountService accountService;
	
	@Test
	void getCompanyNameTest() {

		when(urlConfig.getAccountServiceUrl()).thenReturn("http://test.com");
		when(urlConfig.getAccountServiceCompanyNamePath()).thenReturn("/accounts/name");
		when(redisCacheService.getObjectFromCache(Mockito.anyString())).thenReturn("test token");
		when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
		when(requestHeadersUriSpecMock.uri(Mockito.any(URI.class))).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.headers(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.header(Mockito.any(),Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.accept(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
        when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(Mockito.eq(String.class))).thenReturn(Mono.just(TestConfiguration.ACCOUNT_NEAME));
		
		accountService.getCompanyName();

		verify(webClient, atLeastOnce()).get();
	}
}
