package com.digitalrealty.gapi.remotehands.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.common.context.PermissionService;
import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.config.Actions;
import com.digitalrealty.gapi.remotehands.service.RemotehandsService;

@ExtendWith(MockitoExtension.class)
public class RemoteHandsControllerTest {
	
	@Mock
	Actions actions;

	@Mock
	PermissionService permissionService;

	@Mock
	RemotehandsService remoteHandsService;
	
	@InjectMocks
	RemoteHandsController remoteHandsController;
	
	@Test
	void createRemotehandsTicketTest() {
		when(permissionService.validateAction(Mockito.any())).thenReturn(TestConfiguration.getActionValidationResponse());
		remoteHandsController.createRemotehandsTicket(TestConfiguration.getRemoteHandsPostReq(), null);
		
		verify(remoteHandsService, times(1)).createServiceNow(TestConfiguration.getRemoteHandsPostReq(), null);
	}
	
	@Test
	void getRequestDetailsByServicenowIdTest() {
		when(permissionService.validateAction(Mockito.any())).thenReturn(TestConfiguration.getActionValidationResponse());
		remoteHandsController.getRequestDetailsByServicenowId(TestConfiguration.TICKET_ID);
		
		verify(remoteHandsService, times(1)).getBySnowId(TestConfiguration.TICKET_ID);
	}
	
	@Test
	void getAllRemoteHandsWithFilterTest(){
		when(permissionService.validateAction(Mockito.any())).thenReturn(TestConfiguration.getActionValidationResponse());
		remoteHandsController.getAllRemoteHandsWithFilter(null, null, null, null, null, null, null);
		
		verify(remoteHandsService, times(1)).getByCustomSearchParams(null, null, null, null, null, null, null);
	}
	
	@Test
	void updateEditedFieldsBySnowIdTest() {
		when(permissionService.validateAction(Mockito.any())).thenReturn(TestConfiguration.getActionValidationResponse());
		remoteHandsController.updateEditedFieldsBySnowId(TestConfiguration.getUpdateRemoteHandsRequest(), TestConfiguration.TICKET_ID);
		
		verify(remoteHandsService, times(1)).updateBySnowId(TestConfiguration.getUpdateRemoteHandsRequest(), TestConfiguration.TICKET_ID);	
	}
	
	@Test
	void cancelRemotehandsTicketTest() {
		when(permissionService.validateAction(Mockito.any())).thenReturn(TestConfiguration.getActionValidationResponse());
		remoteHandsController.cancelRemotehandsTicket(TestConfiguration.getRemoteHandsCancelReq(), TestConfiguration.TICKET_ID);
		
		verify(remoteHandsService, times(1)).cancelBySnowId(TestConfiguration.getRemoteHandsCancelReq(), TestConfiguration.TICKET_ID);	
	}
	
	@Test
	void remotehandsTicketCategoriesTest() {
		when(permissionService.validateAction(Mockito.any())).thenReturn(TestConfiguration.getActionValidationResponse());
		remoteHandsController.remotehandsTicketCategories(null);
		
		verify(remoteHandsService, times(1)).getCategories(null);	
	}

}
