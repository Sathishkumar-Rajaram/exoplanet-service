package com.digitalrealty.gapi.remotehands.service;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.config.URLConfig;
import com.digitalrealty.gapi.remotehands.model.Comment;
import com.digitalrealty.gapi.remotehands.model.SiteCodeResponse;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class CommentServiceTest {

	@Mock
	private WebClient webClient;

	@Mock
	WebClient.RequestBodyUriSpec requestBodyUriSpecMock;

	@Mock
	WebClient.RequestBodySpec requestBodySpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersMock;

	@Mock
	WebClient.ResponseSpec responseSpecMock;

	@Mock
	URLConfig urlConfig;

	@Mock
	RedisCacheService redisCacheService;

	@Mock
	JwtConfig jwtConfig;
	
	@InjectMocks
	CommentService commentService;
	
	@Test
	void getCommentTest() {

		when(urlConfig.getCommentServiceUrl()).thenReturn("http://test.com");
		when(urlConfig.getCommentServicePath()).thenReturn("/comments/");
		when(redisCacheService.getObjectFromCache(Mockito.anyString())).thenReturn("test token");
		when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
		when(requestHeadersUriSpecMock.uri(Mockito.any(URI.class))).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.headers(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.header(Mockito.any(),Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.accept(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
        when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(Mockito.eq(new ParameterizedTypeReference<List<Comment>>(){}))).thenReturn(Mono.just(List.of(TestConfiguration.getComment())));
		
		commentService.getComment(TestConfiguration.TICKET_ID);

		verify(webClient, atLeastOnce()).get();
	}
}
