package com.digitalrealty.gapi.remotehands.model;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.groups.Default;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.model.UpdateRemoteHandsRequest;


@ExtendWith(MockitoExtension.class)
class UpdateRemoteHandsRequestTest {

	Validator validator;
	
	@BeforeEach
    public void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }
	
	@Test
	void updateRemoteHandsRequestTest() {
		UpdateRemoteHandsRequest updateRemoteHandsRequest= TestConfiguration.getUpdateRemoteHandsRequest();
		Set<ConstraintViolation<UpdateRemoteHandsRequest>> violations = validator.validateProperty(updateRemoteHandsRequest, "notificationRecipients", Default.class);
		assertTrue(violations.isEmpty());
		
		updateRemoteHandsRequest.setNotificationRecipients("test1@forvisitor.com,test2@forvisitor.com,test3@forvisitorcom");
		violations = validator.validateProperty(updateRemoteHandsRequest, "notificationRecipients", Default.class);
		assertFalse(violations.isEmpty());
	}
}
