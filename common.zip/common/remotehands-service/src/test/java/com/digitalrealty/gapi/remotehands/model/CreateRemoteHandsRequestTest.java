package com.digitalrealty.gapi.remotehands.model;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.groups.Default;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.model.CreateRemoteHandsRequest;


@ExtendWith(MockitoExtension.class)
class CreateRemoteHandsRequestTest {

	Validator validator;
	
	@BeforeEach
    public void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }
	
	@Test
	void createRemoteHandsRequestTest() {
		CreateRemoteHandsRequest createRemoteHandsRequest= TestConfiguration.getRemoteHandsPostReq();
		Set<ConstraintViolation<CreateRemoteHandsRequest>> violations = validator.validateProperty(createRemoteHandsRequest, "notificationRecipients", Default.class);
		assertTrue(violations.isEmpty());
		
		createRemoteHandsRequest.setNotificationRecipients("test1@forvisitor.com,test2@forvisitor.com,test3@forvisitorcom");
		violations = validator.validateProperty(createRemoteHandsRequest, "notificationRecipients", Default.class);
		assertFalse(violations.isEmpty());
	}
}
