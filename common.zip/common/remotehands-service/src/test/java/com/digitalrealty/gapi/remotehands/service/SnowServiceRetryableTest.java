package com.digitalrealty.gapi.remotehands.service;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.util.List;
import java.util.function.Function;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.support.ClientResponseWrapper;

import com.digitalrealty.gapi.common.auth.service.SnowAuthService;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;
import com.digitalrealty.gapi.remotehands.config.URLConfig;
import com.digitalrealty.gapi.remotehands.model.CancelServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.Comment;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowRequest;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.FetchServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.SiteCodeRequest;
import com.digitalrealty.gapi.remotehands.model.SiteCodeResponse;
import com.digitalrealty.gapi.remotehands.model.UpdateServiceNowRequest;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class SnowServiceRetryableTest {

	@Mock
	private WebClient webClient;

	@Mock
	SnowMappingConfig snowMappingConfig;
	
	@Mock
	SnowAuthService snowAuthService;
	
	@Mock
	WebClient.RequestBodyUriSpec requestBodyUriSpecMock;

	@Mock
	WebClient.RequestBodySpec requestBodySpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersMock;

	@Mock
	WebClient.ResponseSpec responseSpecMock;

	@Mock
	URLConfig urlConfig;

	@Mock
	RedisCacheService redisCacheService;

	@Mock
	JwtConfig jwtConfig;
	
	@InjectMocks
	SnowServiceRetryable snowServiceRetryable;
	
	@Test
	void createServiceNowTest() {

		when(urlConfig.getSnowHost()).thenReturn("http://test.com");
		when(urlConfig.getSnowFacilityApiPath()).thenReturn("/test/path");
		when(urlConfig.getSnowDefaultParams()).thenReturn("test=test");
		when(webClient.post()).thenReturn(requestBodyUriSpecMock);
		when(requestBodyUriSpecMock.uri(Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.headers(Mockito.any())).thenReturn(requestBodySpecMock);
        when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
        when(requestBodySpecMock.body(Mockito.any(), Mockito.eq(CreateServiceNowRequest.class))).thenReturn(requestHeadersSpecMock);
        when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
        when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(Mockito.eq(CreateServiceNowResponse.class))).thenReturn(Mono.just(TestConfiguration.getCreateServiceNowResponse()));
		
		snowServiceRetryable.createServiceNow(TestConfiguration.getCreateServiceNowRequest());

		verify(webClient, atLeastOnce()).post();
	}
	
	@Test
	void getBySnowIdTest() {
		
		when(urlConfig.getSnowHost()).thenReturn("http://test.com");
		when(urlConfig.getSnowFacilityApiPath()).thenReturn("/test/path");
		when(urlConfig.getSnowDefaultParams()).thenReturn("test=test");
		when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
		when(requestHeadersUriSpecMock.uri(Mockito.any(URI.class))).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.headers(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.accept(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
        when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(Mockito.eq(FetchServiceNowResponse.class))).thenReturn(Mono.just(TestConfiguration.getFetchServiceNowResponse()));
		
		snowServiceRetryable.getBySnowId(TestConfiguration.TICKET_ID, TestConfiguration.ACCOUNT_NEAME);
		
		verify(webClient, atLeastOnce()).get();
	}
	
	@Test
	void getByCustomSearchParamsTest() {
		
		when(urlConfig.getSnowHost()).thenReturn("http://test.com");
		when(urlConfig.getSnowFacilityApiPath()).thenReturn("/test/path");
		when(urlConfig.getSnowDefaultParams()).thenReturn("test=test");
		when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
		when(requestHeadersUriSpecMock.uri(Mockito.any(URI.class))).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.headers(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.accept(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.exchangeToMono(Mockito.any(Function.class))).thenReturn(Mono.just(TestConfiguration.getFetchServiceNowResponse()));
		
		snowServiceRetryable.getByCustomSearchParams(TestConfiguration.ACCOUNT_NEAME, "DMW10",  null, "Amenities", "Planned Work", null, 1, 0);
		
		verify(webClient, atLeastOnce()).get();				
	}
	
	@Test
	void updateServiceNowTest() {
		when(urlConfig.getSnowHost()).thenReturn("http://test.com");
		when(urlConfig.getSnowFacilityApiPath()).thenReturn("/test/path");
		when(urlConfig.getSnowDefaultParams()).thenReturn("test=test");
		when(webClient.put()).thenReturn(requestBodyUriSpecMock);
		when(requestBodyUriSpecMock.uri(Mockito.any(URI.class))).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.headers(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.body(Mockito.any(),Mockito.eq(UpdateServiceNowRequest.class))).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
        when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(Mockito.eq(CreateServiceNowResponse.class))).thenReturn(Mono.just(TestConfiguration.getCreateServiceNowResponse()));
		
		snowServiceRetryable.updateServiceNow(TestConfiguration.getUpdateServiceNowRequest(), "test sys id");
		
		verify(webClient, atLeastOnce()).put();
	}
	
	@Test
	void cancelServiceNowTest() {
		when(urlConfig.getSnowHost()).thenReturn("http://test.com");
		when(urlConfig.getSnowCancelworkorderApiPath()).thenReturn("/test/path");
		when(webClient.post()).thenReturn(requestBodyUriSpecMock);
		when(requestBodyUriSpecMock.uri(Mockito.any(URI.class))).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.headers(Mockito.any())).thenReturn(requestBodySpecMock);
        when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
        when(requestBodySpecMock.retrieve()).thenReturn(responseSpecMock);
        when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(Mockito.eq(CancelServiceNowResponse.class))).thenReturn(Mono.just(TestConfiguration.getCancelServiceNowResponse()));
		
		snowServiceRetryable.cancelServiceNow("test cancel reason", TestConfiguration.ACCOUNT_NEAME, TestConfiguration.TICKET_ID);

		verify(webClient, atLeastOnce()).post();
	}
}
