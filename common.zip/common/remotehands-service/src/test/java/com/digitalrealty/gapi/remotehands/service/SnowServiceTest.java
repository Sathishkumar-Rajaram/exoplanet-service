package com.digitalrealty.gapi.remotehands.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.common.auth.service.SnowAuthService;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.common.exceptions.IErrorCode;
import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.model.CancelServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.FetchServiceNowResponse;

@ExtendWith(MockitoExtension.class)
public class SnowServiceTest {

	@Mock
	SnowServiceRetryable snowServiceRetryable;

	@Mock
	SnowAuthService snowAuthService;
	
	@InjectMocks
	SnowService snowService;
	
	@Test
	void createServiceNowTest() {
		when(snowServiceRetryable.createServiceNow(Mockito.any())).thenReturn(TestConfiguration.getCreateServiceNowResponse());
		
		CreateServiceNowResponse response = snowService.createServiceNow(TestConfiguration.getCreateServiceNowRequest());
		assertThat(response.getResult()).isNotNull();
		verify(snowServiceRetryable, times(1)).createServiceNow(TestConfiguration.getCreateServiceNowRequest());
	}
	
	@Test
	void createServiceNowTestForUnauthorizedException() {
		when(snowServiceRetryable.createServiceNow(Mockito.any())).thenThrow(new CommonException(ErrorCode.UNAUTHORIZED));
		
		Exception exception = assertThrows(CommonException.class, () -> {
			snowService.createServiceNow(TestConfiguration.getCreateServiceNowRequest());
	    });
		assertThat(exception.getMessage()).contains("UNAUTHORIZED");
	}
	
	@Test
	void getBySnowIdTest() {
		when(snowServiceRetryable.getBySnowId(Mockito.any(), Mockito.any())).thenReturn(TestConfiguration.getFetchServiceNowResponse());
		
		FetchServiceNowResponse response = snowService.getBySnowId(TestConfiguration.TICKET_ID, TestConfiguration.ACCOUNT_NEAME);
		assertThat(response.getResult()).isNotNull();
		verify(snowServiceRetryable, times(1)).getBySnowId(TestConfiguration.TICKET_ID, TestConfiguration.ACCOUNT_NEAME);
	}
	
	@Test
	void getBySnowIdTestForUnauthorizedException() {
		when(snowServiceRetryable.getBySnowId(Mockito.any(), Mockito.any())).thenThrow(new CommonException(ErrorCode.UNAUTHORIZED));
		
		Exception exception = assertThrows(CommonException.class, () -> {
			snowService.getBySnowId(TestConfiguration.TICKET_ID, TestConfiguration.ACCOUNT_NEAME);
	    });
		assertThat(exception.getMessage()).contains("UNAUTHORIZED");
	}
	
	@Test
	void getByCustomSearchParamsTest() {
		when(snowServiceRetryable.getByCustomSearchParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(Collections.emptyMap());
		
		Map<String, Object> response = snowService.getByCustomSearchParams(TestConfiguration.ACCOUNT_NEAME, "test site", "New", "test category", "test reqyest type", "test@test,com", 10, 1);
		assertThat(response).isNotNull();
		verify(snowServiceRetryable, times(1)).getByCustomSearchParams(TestConfiguration.ACCOUNT_NEAME, "test site", "New", "test category", "test reqyest type", "test@test,com", 10, 1);
	}
	
	@Test
	void getByCustomSearchParamsTestForUnauthorizedException() {
		when(snowServiceRetryable.getByCustomSearchParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.any())).thenThrow(new CommonException(ErrorCode.UNAUTHORIZED));
		
		Exception exception = assertThrows(CommonException.class, () -> {
			snowService.getByCustomSearchParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.any());
	    });
		assertThat(exception.getMessage()).contains("UNAUTHORIZED");
	}
	
	@Test
	void updateServiceNowTest() {
		when(snowServiceRetryable.updateServiceNow(Mockito.any(), Mockito.anyString())).thenReturn(TestConfiguration.getCreateServiceNowResponse());
		
		CreateServiceNowResponse response = snowService.updateServiceNow(TestConfiguration.getUpdateServiceNowRequest(), "test sys id");
		
		assertThat(response.getResult()).isNotNull();
		verify(snowServiceRetryable, times(1)).updateServiceNow(TestConfiguration.getUpdateServiceNowRequest(), "test sys id");
	}
	
	@Test
	void updateServiceNowTestForUnauthorizedException() {
		when(snowServiceRetryable.updateServiceNow(Mockito.any(), Mockito.anyString())).thenThrow(new CommonException(ErrorCode.UNAUTHORIZED));
		
		Exception exception = assertThrows(CommonException.class, () -> {
			snowService.updateServiceNow(Mockito.any(), Mockito.anyString());
	    });
		assertThat(exception.getMessage()).contains("UNAUTHORIZED");
	}
	
	@Test
	void cancelServiceNowTest() {
		when(snowServiceRetryable.cancelServiceNow(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(TestConfiguration.getCancelServiceNowResponse());
		
		CancelServiceNowResponse response = snowService.cancelServiceNow("Duplicate Request", TestConfiguration.ACCOUNT_NEAME, TestConfiguration.TICKET_ID);
		
		assertThat(response.getResult()).isNotNull();
		verify(snowServiceRetryable, times(1)).cancelServiceNow("Duplicate Request", TestConfiguration.ACCOUNT_NEAME, TestConfiguration.TICKET_ID);
	}
	
	@Test
	void cancelServiceNowTestForUnauthorizedException() {
		when(snowServiceRetryable.cancelServiceNow(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenThrow(new CommonException(ErrorCode.UNAUTHORIZED));
		
		Exception exception = assertThrows(CommonException.class, () -> {
			snowService.cancelServiceNow("Duplicate Request", TestConfiguration.ACCOUNT_NEAME, TestConfiguration.TICKET_ID);
	    });
		assertThat(exception.getMessage()).contains("UNAUTHORIZED");
	}
}
