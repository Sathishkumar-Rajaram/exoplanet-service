package com.digitalrealty.gapi.remotehands;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import com.digitalrealty.gapi.common.context.ActionValidationResponse;
import com.digitalrealty.gapi.remotehands.enums.WorkType;
import com.digitalrealty.gapi.remotehands.model.CancelRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.CancelRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.CancelResult;
import com.digitalrealty.gapi.remotehands.model.CancelServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.Comment;
import com.digitalrealty.gapi.remotehands.model.CreateRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowRequest;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.FetchServiceNowResponse;
import com.digitalrealty.gapi.remotehands.model.RemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.SearchRemoteHandsResponse;
import com.digitalrealty.gapi.remotehands.model.SiteCodeRequest;
import com.digitalrealty.gapi.remotehands.model.SiteCodeResponse;
import com.digitalrealty.gapi.remotehands.model.SnowResult;
import com.digitalrealty.gapi.remotehands.model.UpdateRemoteHandsRequest;
import com.digitalrealty.gapi.remotehands.model.UpdateServiceNowRequest;

public class TestConfiguration {

	public static final UUID USERID = UUID.fromString("6ed86839-1925-490f-a1d2-fcd35e38f59b");
	
	public static final String ACCOUNT_NEAME = "TelX pvt co.us";
	
	public static final String OP_SITE = "IDW10";
	
	public static final String MASTER_SITE = "IDW010";

	public static final String TICKET_ID = "WO1234568";
	
	public static ActionValidationResponse getActionValidationResponse(){
	    return ActionValidationResponse.builder().userId(USERID).build();
	}
	
	public static UpdateRemoteHandsRequest getUpdateRemoteHandsRequest() {
		return UpdateRemoteHandsRequest.builder().notificationRecipients("test@test.com,example@test.com").build();
	}
	public static CreateRemoteHandsRequest getRemoteHandsPostReq() {
		return CreateRemoteHandsRequest.builder().category("Customer premise cabling")
				.requestType(WorkType.PLANNED_WORK.getWorkType()).customerReference("TESTREF123")
				.detailedInstruction("just detailed instruction").location("Telx Rack 01").site(MASTER_SITE)
				.notificationRecipients("test@test.com,example@test.com").referenceTicket("REF12345")
				.title("Sample Title").build();
	}
	
	
	public static RemoteHandsResponse getRemoteHandsResp() {
		return RemoteHandsResponse.builder().category("Customer premise cabling")
				.requestType(WorkType.PLANNED_WORK.getWorkType()).customerReference("TESTREF123")
				.detailedInstruction("just detailed instruction").location("Telx Rack 01")
				.notificationRecipients("test@test.com,example@test.com").referenceTicket("REF12345").site(MASTER_SITE)
				.title("Sample Title").cancelReason(null).closedOn("2022-06-14 14:07:40").createdOn("2022-06-14 14:07:40")
				.createdBy("Neil Blend").id("WO12345678").status("New").updatedOn("2022-06-15 14:07:40").build();
	}
	
	public static SearchRemoteHandsResponse getRemoteHandsSearchResp() {
		return SearchRemoteHandsResponse.builder().category("Customer premise cabling")
				.requestType(WorkType.PLANNED_WORK.getWorkType()).location("Telx Rack 01").site(MASTER_SITE)
				.title("Sample Title").closedOn("2022-06-14 14:07:40").createdOn("2022-06-14 14:07:40")
				.createdBy("Neil Blend").id("WO12345678").status("New").updatedOn("2022-06-15 14:07:40").build();
	}
	
	public static CancelRemoteHandsRequest getRemoteHandsCancelReq() {
		String cancelReason = "Duplicate request";
		return CancelRemoteHandsRequest.builder().cancelReason(cancelReason).build();
	}
	
	public static CancelRemoteHandsResponse getRemoteHandsCancelResp() {
		return CancelRemoteHandsResponse.builder().message("test message").build();
	}
	
	public static List<String> getPlannedCategories() {
		List<String> list = new ArrayList<>();
		list.add("Customer premise cabling");
		return list;
	}
	
	public static SiteCodeRequest getSiteCodeRequest() {
		return SiteCodeRequest.builder().operationalSiteCodes(Arrays.asList(OP_SITE)).build();
	}

	public static SiteCodeResponse getSiteCodeResponse() {
		return SiteCodeResponse.builder().masterSiteCode(MASTER_SITE).operationalSiteCode(OP_SITE).build();
	}

	public static Comment getComment() {
		return Comment.builder().comment("test comment").commentedBy("Aaron walter").commentedOn("2022-04-04 00:00:00").build();
	}

	public static CreateServiceNowRequest getCreateServiceNowRequest() {
		return CreateServiceNowRequest.builder().category("Remotehands services").subcategory("Customer premise cabling").cmdbCi("TelX Rack 1")
				.company(ACCOUNT_NEAME).description("test description").location("DMW10").type("Planned Work").uExternalReferenceNumber("Test123")
				.shortDescription("short description").uCcNotificationsList("test@test.com").uShippingTrackingNumber("Tracking no 123").build();
	}
	
	public static CreateServiceNowResponse getCreateServiceNowResponse() {
		SnowResult snowResult = SnowResult.builder().number(TICKET_ID).category("Remotehands services").subcategory("Customer premise cabling").cmdbCi("TelX Rack 1")
				.company(ACCOUNT_NEAME).description("test description").location("DMW10").type("Planned Work").uExternalReferenceNumber("Test123")
				.shortDescription("short description").uCcNotificationsList("test@test.com").uShippingTrackingNumber("Tracking no 123").state("New").build();
		return CreateServiceNowResponse.builder().result(snowResult).build();
	}

	public static FetchServiceNowResponse getFetchServiceNowResponse() {
		SnowResult snowResult = SnowResult.builder().number(TICKET_ID).category("Remotehands services").subcategory("Customer premise cabling").cmdbCi("TelX Rack 1")
				.company(ACCOUNT_NEAME).description("test description").location(OP_SITE).type("Planned Work").uExternalReferenceNumber("Test123")
				.shortDescription("short description").uCcNotificationsList("test@test.com").uShippingTrackingNumber("Tracking no 123").state("New").build();
		return FetchServiceNowResponse.builder().result(List.of(snowResult)).build();
	}

	public static UpdateServiceNowRequest getUpdateServiceNowRequest() {
		return UpdateServiceNowRequest.builder().uCcNotificationsList("test@test.com").uExternalReferenceNumber("test12345External").build();
	}

	public static CancelServiceNowResponse getCancelServiceNowResponse() {
		return CancelServiceNowResponse.builder().result(CancelResult.builder().status("cancelled").build()).build();
	}
	
}
