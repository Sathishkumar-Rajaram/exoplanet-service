package com.digitalrealty.gapi.remotehands.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.spy;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.config.SnowMappingConfig;
import com.digitalrealty.gapi.remotehands.model.CreateServiceNowRequest;
import com.digitalrealty.gapi.remotehands.model.UpdateServiceNowRequest;

@ExtendWith(MockitoExtension.class)
public class ServiceNowReqMapperTest {

	@Mock
	SnowMappingConfig SnowMappingConfig;
	
	@InjectMocks
	ServiceNowReqMapper serviceNowReqMapper = Mappers.getMapper(ServiceNowReqMapper.class);
	
	@Test
	void createServiceNowReqMapTest() {
		CreateServiceNowRequest request =  serviceNowReqMapper.createServiceNowReqMap(TestConfiguration.getRemoteHandsPostReq(), TestConfiguration.ACCOUNT_NEAME, null, null, null, SnowMappingConfig);
		assertThat(request.getCompany()).isEqualTo(TestConfiguration.ACCOUNT_NEAME);
	}
	
	@Test
	void updateServiceNowReqMapTest() {
		UpdateServiceNowRequest request =  serviceNowReqMapper.updateServiceNowReqMap(TestConfiguration.getUpdateRemoteHandsRequest());
		assertThat(request.getUExternalReferenceNumber()).isEqualTo(null);
	}
	
}
