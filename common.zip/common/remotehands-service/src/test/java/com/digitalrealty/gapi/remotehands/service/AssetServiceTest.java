package com.digitalrealty.gapi.remotehands.service;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.digitalrealty.gapi.remotehands.TestConfiguration;
import com.digitalrealty.gapi.remotehands.config.URLConfig;
import com.digitalrealty.gapi.remotehands.model.SiteCodeRequest;
import com.digitalrealty.gapi.remotehands.model.SiteCodeResponse;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class AssetServiceTest {

	@Mock
	private WebClient webClient;

	@Mock
	WebClient.RequestBodyUriSpec requestBodyUriSpecMock;

	@Mock
	WebClient.RequestBodySpec requestBodySpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersMock;

	@Mock
	WebClient.ResponseSpec responseSpecMock;

	@Mock
	URLConfig urlConfig;

	@Mock
	RedisCacheService redisCacheService;

	@Mock
	JwtConfig jwtConfig;
	
	@InjectMocks
	AssetService assetService;
	
	@Test
	void getSiteCodesTest() {

		when(urlConfig.getAssetServiceUrl()).thenReturn("http://test.com");
		when(urlConfig.getAssetServiceSiteCodesPath()).thenReturn("/assets/sites");
		when(redisCacheService.getObjectFromCache(Mockito.anyString())).thenReturn("test token");
		when(webClient.post()).thenReturn(requestBodyUriSpecMock);
		when(requestBodyUriSpecMock.uri(Mockito.any(URI.class))).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.headers(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.header(Mockito.any(), Mockito.any())).thenReturn(requestBodySpecMock);
        when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
        when(requestBodySpecMock.body(Mockito.any(), Mockito.eq(SiteCodeRequest.class))).thenReturn(requestHeadersSpecMock);
        when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
        when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(Mockito.eq(new ParameterizedTypeReference<List<SiteCodeResponse>>(){}))).thenReturn(Mono.just(List.of(TestConfiguration.getSiteCodeResponse())));
		
		assetService.getSiteCodes(TestConfiguration.getSiteCodeRequest());

		verify(webClient, atLeastOnce()).post();
	}
}
