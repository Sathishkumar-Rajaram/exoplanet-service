package com.digitalrealty.feigndemo.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalrealty.feigndemo.client.RootServiceClient;
import com.digitalrealty.feigndemo.client.UserServiceClient;
import com.digitalrealty.feigndemo.model.Root;
import com.digitalrealty.feigndemo.model.User;

@Service
public class UserPermissionService {

	@Autowired
	private RootServiceClient rootServiceClient;
	@Autowired
	private UserServiceClient userServiceClient;

	public List<Root> getUserPermission(){
		List<Root> rootList = rootServiceClient.getRoots();
		List<User> userList = userServiceClient.getUsers();
		Set<String> allowedUsr = userList.stream().filter(u-> Boolean.TRUE.equals(u.getIsPermit())).map(u-> u.getUserId()).collect(Collectors.toSet());
		
		rootList.stream().filter(r -> allowedUsr.contains(String.valueOf(r.getId()))).forEach(r -> r.setIsPermit(Boolean.TRUE));
		
		return rootList;
	}

	public Root getUserPermissionById(String id) {
		List<Root> rootList = rootServiceClient.getRoots();
		User usr = userServiceClient.getUserByUserID(id);
		Root root = rootList.stream().filter(r-> r.getId().equals(Integer.valueOf(usr.getUserId()))).findFirst().get();
		root.setIsPermit(usr.getIsPermit());
		
		return root;
	}
	
	
}
