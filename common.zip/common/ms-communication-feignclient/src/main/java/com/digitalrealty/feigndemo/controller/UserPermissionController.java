package com.digitalrealty.feigndemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.digitalrealty.feigndemo.model.Root;
import com.digitalrealty.feigndemo.service.UserPermissionService;

@RestController
public class UserPermissionController {

	@Autowired
	private UserPermissionService userPermissionService;

	@GetMapping(value = "/users/getpermission")
	public List<Root> getUsers() {
		return userPermissionService.getUserPermission();
	}

	@GetMapping(value = "/users/getpermission/{userid}")
	public Root getUserByUserID(@PathVariable("userid") String id) {
		return userPermissionService.getUserPermissionById(id);
	}

}