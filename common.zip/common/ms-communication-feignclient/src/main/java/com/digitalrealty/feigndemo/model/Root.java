package com.digitalrealty.feigndemo.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Root{
	
	private int postId;
	private Integer id;
	private String name;
	private String email;
	private String body;
	private Boolean isPermit=false;
}