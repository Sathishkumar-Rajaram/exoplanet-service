package com.digitalrealty.feigndemo.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.digitalrealty.feigndemo.model.Root;

@FeignClient(name="root-service", url="${mock-service.url}")
public interface RootServiceClient {
	
	@GetMapping(value = "/getRoots")
	List<Root> getRoots();
	
	@GetMapping(value = "/getRoot/{id}")
	Root getRootByPostID(@PathVariable("id") Long postId);

}
