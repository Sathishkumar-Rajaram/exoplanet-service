package com.digitalrealty.feigndemo.model;

import lombok.Getter;
@Getter
public class UserPermission{
	
	private int postId;
	private Integer id;
	private String name;
	private String email;
	private String body;
	private String isPermit;
}