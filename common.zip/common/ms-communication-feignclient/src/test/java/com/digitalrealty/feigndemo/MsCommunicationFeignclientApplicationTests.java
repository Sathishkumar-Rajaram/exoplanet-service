package com.digitalrealty.feigndemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCommunicationFeignclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
